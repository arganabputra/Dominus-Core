# Panduan Integrasi Profil Image

## 📋 Overview

Fitur profil image telah ditambahkan dengan sistem penyimpanan terdesentralisasi yang memungkinkan user untuk:
- ✅ Mengganti foto profil dari galeri atau kamera
- ✅ Menyimpan foto profil secara otomatis
- ✅ Menampilkan foto di profil page, dashboard, dan control panel
- ✅ Menghapus foto profil

## 📁 File-file Baru

### 1. `profile_utils.dart`
Utility class yang menangani semua operasi profil image:
- `saveProfileImage(File)` - Simpan foto profil
- `getProfileImageBase64()` - Ambil foto sebagai base64
- `getProfileImageFile()` - Ambil foto sebagai File
- `getProfileImageMemory()` - Ambil foto sebagai MemoryImage
- `pickProfileImage()` - Pilih foto dari galeri/kamera
- `deleteProfileImage()` - Hapus foto profil
- `hasProfileImage()` - Cek apakah ada foto profil

### 2. `profile_image_widget.dart`
Widget components untuk menampilkan profil image:

#### `ProfileImageWidget`
Widget sederhana untuk menampilkan foto profil:
```dart
ProfileImageWidget(
  size: 80,
  onTap: () => print('Tapped!'),
)
```

#### `ProfileAvatarWidget`
Widget avatar bulat dengan style khusus:
```dart
ProfileAvatarWidget(
  size: 100,
  username: 'username',
  role: 'owner',
  onTap: () => print('Tapped!'),
)
```

### 3. `profile_page.dart` (Modified)
Profile page telah diupdate dengan:
- Import `profile_utils.dart` dan `image_picker`
- State variables untuk profil image management
- Method `_loadProfileImage()` - Load foto saat init
- Method `_showChangeProfileImageDialog()` - Dialog untuk memilih sumber foto
- Method `_pickAndSaveProfileImage()` - Pick dan simpan foto
- Method `_deleteProfileImage()` - Hapus foto profil
- Avatar yang clickable dengan edit button

## 🔧 Cara Integrasi ke Dashboard dan Control Panel

### Option 1: Menampilkan di bagian header/top

#### di `dashboard_page.dart`:
```dart
// Tambahkan import
import 'profile_image_widget.dart';
import 'profile_utils.dart';

// Di widget yang menampilkan profil, ubah dari Image.asset ke:
ProfileImageWidget(
  size: 60,
  assetFallback: 'assets/images/logo.png',
  borderColor: Colors.white.withOpacity(0.2),
)
```

### Option 2: Menampilkan profile card dengan foto

```dart
// Di dashboard, ganti avatar display dengan:
ProfileAvatarWidget(
  size: 100,
  username: widget.username,
  role: widget.role,
)
```

## 📱 Integrasi Detail untuk Dashboard

### Langkah 1: Tambah Import
```dart
import 'profile_image_widget.dart';
```

### Langkah 2: Cari Bagian yang Menampilkan Avatar
Cari kode yang menggunakan `Image.asset('assets/images/logo.png')` untuk profil.

### Langkah 3: Ganti dengan ProfileImageWidget
**Sebelum:**
```dart
Image.asset(
  'assets/images/logo.png',
  fit: BoxFit.cover,
)
```

**Sesudah:**
```dart
ProfileImageWidget(
  size: 80,
  assetFallback: 'assets/images/logo.png',
  borderColor: Colors.white.withOpacity(0.2),
)
```

## 🎨 Customization

### Mengubah ukuran foto
```dart
ProfileImageWidget(
  size: 120, // width dan height dalam pixels
)
```

### Mengubah fallback image
```dart
ProfileImageWidget(
  assetFallback: 'assets/images/custom_avatar.png',
)
```

### Styling border
```dart
ProfileImageWidget(
  borderColor: Color(0xFF00D9FF),
  borderWidth: 3,
)
```

### Shape (circle atau square)
```dart
ProfileImageWidget(
  shape: BoxShape.rectangle, // atau BoxShape.circle (default)
)
```

## 💾 Data Storage

Foto profil disimpan di:
1. **Local File**: `{appDocDir}/profile/profile_image.jpg`
2. **SharedPreferences**: 
   - Key `user_profile_image_base64` - Base64 encoded image
   - Key `user_profile_image_path` - Path ke file

## 🔐 Security Notes

- Foto disimpan secara lokal di app documents directory (secure)
- Base64 disimpan di SharedPreferences
- Tidak ada upload ke server (privacy-first)
- User bisa kapan saja menghapus foto

## 🐛 Troubleshooting

### Foto tidak tampil di dashboard
1. Pastikan ProfileImageWidget sudah di-import
2. Check logcat untuk error messages
3. Verifikasi foto tersimpan dengan check `hasProfileImage()`

### Foto tidak tersimpan
1. Check permission untuk read/write storage (check AndroidManifest.xml)
2. Pastikan `path_provider` dan `image_picker` dependencies sudah installed
3. Check file system permissions

### Foto terus reset
1. Pastikan SharedPreferences tidak di-clear saat logout
2. Jika ingin clear foto saat logout, panggil `ProfileImageUtils.deleteProfileImage()`

## 📝 Dependencies Required

Semua dependencies sudah ada di pubspec.yaml:
- ✅ `shared_preferences: ^2.2.2`
- ✅ `image_picker: ^1.0.5`
- ✅ `path_provider: ^2.1.1`

## 🚀 Next Steps

1. Update dashboard_page.dart untuk menampilkan ProfileImageWidget
2. Update control_panel.dart untuk menampilkan ProfileImageWidget
3. Test pick image dari galeri
4. Test pick image dari kamera
5. Test delete image
6. Verify foto persist setelah app restart

## 📋 Checklist Integrasi

- [ ] Copy profile_utils.dart ke lib folder
- [ ] Copy profile_image_widget.dart ke lib folder
- [ ] Update profile_page.dart (sudah dilakukan)
- [ ] Add import ke dashboard_page.dart
- [ ] Replace avatar widgets di dashboard dengan ProfileImageWidget
- [ ] Add import ke control_panel.dart
- [ ] Replace avatar widgets di control_panel dengan ProfileImageWidget
- [ ] Test pick image functionality
- [ ] Test delete image functionality
- [ ] Test persistence setelah restart app
- [ ] Test di device/emulator dengan storage permissions
