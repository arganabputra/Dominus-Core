// chat_page.dart - FULL GRAYSCALE EDITION
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:video_player/video_player.dart';
import 'background_notifier.dart';
import 'app_theme.dart';

// ==================== KONSTANTA SERVER ====================
const String BASE_URL = 'http://rizqy.smasnug.web.id:10003';
const String WS_URL = 'ws://privatesrvrenn.sano.biz.id:10831';

// ==================== TEMA WARNA (DYNAMIC - ikut AppColors) ====================
class ChatTheme {
  static Color get bg            => AppColors.bg;
  static Color get surface       => AppColors.surface;
  static Color get surface2      => AppColors.surfaceLight;
  static Color get surface3      => AppColors.surface2;
  static Color get surface4      => AppColors.cardDark;
  static Color get accent1       => AppColors.accent1;
  static Color get accent2       => AppColors.accent2;
  static Color get accent3       => AppColors.accent3;
  static Color get success       => AppColors.success;
  static Color get warning       => AppColors.warning;
  static Color get error         => AppColors.error;
  static Color get textPrimary   => AppColors.textPrimary;
  static Color get textSecondary => AppColors.textSec;
  static Color get textMuted     => AppColors.textMuted;
  static Color get shadowHeavy   => AppColors.shadowHeavy;
}

// ==================== HALAMAN CHAT UTAMA ====================
class ChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  WebSocketChannel? _channel;

  // Global chat
  List<dynamic> _globalMessages = [];
  bool _globalLoading = true;
  final TextEditingController _globalInputCtrl = TextEditingController();
  final ScrollController _globalScrollCtrl = ScrollController();
  Map<String, dynamic>? _globalReplyTo;

  // Private chat
  List<dynamic> _privateChats = [];
  List<dynamic> _privateMessages = [];
  String? _selectedUser;
  bool _privateLoading = true;
  final TextEditingController _privateInputCtrl = TextEditingController();
  final ScrollController _privateScrollCtrl = ScrollController();
  Map<String, dynamic>? _privateReplyTo;

  // Profile
  Map<String, dynamic> _myProfile = {};

  // Search
  final TextEditingController _searchCtrl = TextEditingController();
  List<dynamic> _searchResults = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initialize();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _channel?.sink.close();
    _globalInputCtrl.dispose();
    _globalScrollCtrl.dispose();
    _privateInputCtrl.dispose();
    _privateScrollCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  // ==================== INISIALISASI ====================
  void _initialize() {
    _loadProfile();
    _connectWebSocket();
    _loadGlobalMessages();
    _loadPrivateChats();
  }

  Future<void> _loadProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse('$BASE_URL/chat/profile?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _myProfile = data['profile']);
        }
      }
    } catch (e) {}
  }

  void _connectWebSocket() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      _channel = WebSocketChannel.connect(Uri.parse(WS_URL));
      _channel!.stream.listen(_handleWebSocketMessage, onError: (e) {});
      _channel!.sink.add(jsonEncode({ 'type': 'auth', 'key': sessionKey }));
    } catch (e) {}
  }

  void _handleWebSocketMessage(dynamic data) {
    try {
      final msg = jsonDecode(data);
      if (msg['type'] == 'global_message') {
        _addGlobalMessage(msg['message']);
      } else if (msg['type'] == 'private_message') {
        _addPrivateMessage(msg['message']);
      } else if (msg['type'] == 'refresh_chat_list') {
        _loadPrivateChats();
      }
    } catch (e) {}
  }

  // ==================== GLOBAL CHAT ====================

  Future<void> _loadGlobalMessages() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse('$BASE_URL/chat/global/messages?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _globalMessages = data['messages'];
            _globalLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_globalScrollCtrl);
          });
        }
      }
    } catch (e) { if (mounted) setState(() => _globalLoading = false); }
  }

  void _addGlobalMessage(dynamic msg) {
    setState(() => _globalMessages.add(msg));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom(_globalScrollCtrl);
    });
  }

  void _scrollToBottom(ScrollController controller) {
    if (controller.hasClients) {
      controller.animateTo(
        controller.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendGlobalMessage() async {
    String text = _globalInputCtrl.text.trim();
    if (text.isEmpty && _globalReplyTo == null) return;

    String finalText = text;
    if (_globalReplyTo != null) {
      finalText = '@${_globalReplyTo!['sender']} ${text}';
    }

    setState(() => _globalInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _globalReplyTo?['id']
      });

      final res = await http.post(
        Uri.parse('$BASE_URL/chat/global/send?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _globalReplyTo = null);
          _loadGlobalMessages();
        }
      }
    } catch (e) {}
  }

  // ==================== PRIVATE CHAT ====================

  Future<void> _loadPrivateChats() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse('$BASE_URL/chat/private/users?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateChats = data['users'];
            _privateLoading = false;
          });
        }
      }
    } catch (e) { if (mounted) setState(() => _privateLoading = false); }
  }

  Future<void> _loadPrivateMessages(String withUser) async {
    setState(() => _privateLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse('$BASE_URL/chat/private/messages/$withUser?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateMessages = data['messages'];
            _privateLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_privateScrollCtrl);
          });

          await http.post(Uri.parse('$BASE_URL/chat/private/mark-read/$withUser?key=$sessionKey'));
        }
      }
    } catch (e) { setState(() => _privateLoading = false); }
  }

  void _addPrivateMessage(dynamic msg) {
    final isCurrentChat = _selectedUser == msg['sender'] || _selectedUser == msg['receiver'];
    if (isCurrentChat) {
      setState(() => _privateMessages.add(msg));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom(_privateScrollCtrl);
      });
    }
    _loadPrivateChats();
  }

  Future<void> _sendPrivateMessage() async {
    String text = _privateInputCtrl.text.trim();
    if (text.isEmpty || _selectedUser == null) return;

    String finalText = text;
    if (_privateReplyTo != null) {
      finalText = '@${_privateReplyTo!['sender']} ${text}';
    }

    setState(() => _privateInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _privateReplyTo?['id']
      });

      final res = await http.post(
        Uri.parse('$BASE_URL/chat/private/send/${_selectedUser}?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _privateReplyTo = null);
          _loadPrivateMessages(_selectedUser!);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['error'] ?? 'Gagal mengirim pesan')),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _searchAndStartChat() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _SearchUserSheet(
        sessionKey: widget.sessionKey,
        currentUsername: widget.username,
        onSelectUser: (user) {
          Navigator.pop(ctx);
          setState(() {
            _selectedUser = user['username'];
            _privateReplyTo = null;
          });
          _loadPrivateMessages(user['username']);
          _tabController.animateTo(1);
        },
      ),
    );
  }

  String _formatTime(String? timestamp) {
    if (timestamp == null) return '';
    try {
      final time = DateTime.parse(timestamp);
      final now = DateTime.now();
      final diff = now.difference(time);
      if (diff.inSeconds < 60) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) { return ''; }
  }

  // ==================== BUILD ====================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // === DARK OVERLAY ===
          Container(color: Colors.black.withOpacity(0.55)),
          // === KONTEN ===
          Column(
        children: [
          // Tab Bar
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            height: 48,
            decoration: BoxDecoration(
              color: ChatTheme.surface2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: ChatTheme.accent1.withOpacity(0.2)),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [ChatTheme.accent1, ChatTheme.accent2],
                ),
              ),
              labelColor: Colors.white,
              unselectedLabelColor: ChatTheme.textMuted,
              dividerColor: Colors.transparent,
              labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              unselectedLabelStyle: const TextStyle(fontSize: 13),
              indicatorSize: TabBarIndicatorSize.tab,
              tabs: const [
                Tab(icon: Icon(Icons.public_rounded, size: 18), text: 'GLOBAL'),
                Tab(icon: Icon(Icons.lock_rounded, size: 18), text: 'PRIVATE'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildGlobalChat(),
                _buildPrivateChat(),
              ],
            ),
          ),
          // INPUT BAR dipindah ke sini supaya selalu anchor di bawah TabBarView
          AnimatedBuilder(
            animation: _tabController,
            builder: (context, _) {
              final isGlobal = _tabController.index == 0;
              // Sembunyikan input bar saat di private tab tapi belum pilih user
              if (!isGlobal && _selectedUser == null) return const SizedBox.shrink();
              return _buildInputBar(
                controller: isGlobal ? _globalInputCtrl : _privateInputCtrl,
                onSend: isGlobal ? _sendGlobalMessage : _sendPrivateMessage,
                hint: isGlobal ? 'Type a message...' : 'End-to-End Encrypted message...',
                isGlobal: isGlobal,
              );
            },
          ),
        ],
      ),
        ],
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: ChatTheme.surface,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_rounded, color: ChatTheme.textPrimary),
        onPressed: () => Navigator.pop(context),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CHAT',
            style: TextStyle(
              color: ChatTheme.accent1,
              fontSize: 10,
              letterSpacing: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            '@${widget.username}',
            style: TextStyle(color: ChatTheme.textSecondary, fontSize: 11),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.refresh_rounded, color: ChatTheme.accent1),
          onPressed: () {
            _loadGlobalMessages();
            _loadPrivateChats();
            if (_selectedUser != null) _loadPrivateMessages(_selectedUser!);
          },
        ),
      ],
    );
  }

  // ==================== GLOBAL CHAT TAB ====================

  Widget _buildGlobalChat() {
    return Column(
      children: [
        if (_globalReplyTo != null) _buildReplyPreviewBar(isGlobal: true),
        Expanded(
          child: _globalLoading
              ? Center(child: CircularProgressIndicator(color: ChatTheme.accent1))
              : _globalMessages.isEmpty
                  ? _buildEmptyState('Belum ada pesan', 'Jadilah yang pertama mengirim pesan!')
                  : ListView.builder(
                      controller: _globalScrollCtrl,
                      padding: const EdgeInsets.only(bottom: 20),
                      itemCount: _globalMessages.length,
                      itemBuilder: (ctx, i) => _buildGlobalMessageBubble(_globalMessages[i]),
                    ),
        ),
      ],
    );
  }

  Widget _buildGlobalMessageBubble(dynamic msg) {
    final isMe = msg['sender'] == widget.username;
    final profile = msg['senderProfile'] ?? {};
    final name = profile['name'] ?? msg['sender'];
    final replyTo = msg['replyTo'];

    return GestureDetector(
      onLongPress: () {
        setState(() {
          _globalReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 60 : 12,
          right: isMe ? 12 : 60,
          top: 8,
          bottom: 8,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isMe) ...[
              GestureDetector(
                onTap: () {
                  if (msg['sender'] != widget.username) {
                    setState(() {
                      _selectedUser = msg['sender'];
                      _privateReplyTo = null;
                    });
                    _loadPrivateMessages(msg['sender']);
                    _tabController.animateTo(1);
                  }
                },
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: ChatTheme.surface3,
                  child: Text(name[0].toUpperCase(), style: TextStyle(color: ChatTheme.accent1)),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                      child: Text(name, style: TextStyle(color: ChatTheme.textSecondary, fontSize: 11)),
                    ),
                  if (replyTo != null)
                    Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: ChatTheme.surface3,
                        borderRadius: BorderRadius.circular(8),
                        border: Border(left: BorderSide(color: isMe ? ChatTheme.accent2 : ChatTheme.accent1, width: 3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Replying to @${replyTo['sender']}',
                            style: TextStyle(color: isMe ? ChatTheme.accent2 : ChatTheme.accent1, fontSize: 10),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            replyTo['message'] ?? '',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: ChatTheme.textMuted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isMe ? ChatTheme.accent2.withOpacity(0.2) : ChatTheme.surface2,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: isMe ? ChatTheme.accent2.withOpacity(0.3) : ChatTheme.accent1.withOpacity(0.2)),
                    ),
                    child: Text(
                      msg['message'] ?? '',
                      style: TextStyle(
                        color: isMe ? ChatTheme.accent1 : ChatTheme.textPrimary,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8, right: 8, top: 4),
                    child: Text(
                      _formatTime(msg['timestamp']),
                      style: TextStyle(color: ChatTheme.textMuted, fontSize: 9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== PRIVATE CHAT TAB ====================

  Widget _buildPrivateChat() {
    return _selectedUser == null
        ? _buildChatList()
        : Column(
            children: [
              _buildChatHeader(),
              if (_privateReplyTo != null) _buildReplyPreviewBar(isGlobal: false),
              Expanded(
                child: _privateLoading
                    ? Center(child: CircularProgressIndicator(color: ChatTheme.accent1))
                    : _privateMessages.isEmpty
                        ? _buildEmptyState('Belum ada pesan', 'Kirim pesan pertama untuk memulai!')
                        : ListView.builder(
                            controller: _privateScrollCtrl,
                            padding: const EdgeInsets.only(bottom: 20),
                            itemCount: _privateMessages.length,
                            itemBuilder: (ctx, i) => _buildPrivateMessageBubble(_privateMessages[i]),
                          ),
              ),
              ],
          );
  }

  Widget _buildChatList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: GestureDetector(
            onTap: _searchAndStartChat,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: ChatTheme.surface2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ChatTheme.accent1.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(Icons.search_rounded, color: ChatTheme.textMuted),
                  const SizedBox(width: 12),
                  Text('Cari user baru...', style: TextStyle(color: ChatTheme.textMuted)),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: _privateChats.isEmpty
              ? _buildEmptyState('Belum ada chat', 'Cari user untuk memulai percakapan private!')
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _privateChats.length,
                  itemBuilder: (ctx, i) => _buildChatListItem(_privateChats[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildChatListItem(dynamic chat) {
    final profile = chat['profile'] ?? {};
    final lastMsg = chat['lastMessage'];
    final isUnread = lastMsg != null && lastMsg['sender'] != widget.username && lastMsg['read'] != true;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedUser = chat['username'];
          _privateReplyTo = null;
        });
        _loadPrivateMessages(chat['username']);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isUnread ? ChatTheme.accent1.withOpacity(0.1) : ChatTheme.surface2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isUnread ? ChatTheme.accent1.withOpacity(0.3) : ChatTheme.accent1.withOpacity(0.1)),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: ChatTheme.surface3,
              child: Text(chat['username'][0].toUpperCase(),
                  style: TextStyle(color: ChatTheme.accent1, fontSize: 18)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        profile['name'] ?? chat['username'],
                        style: TextStyle(
                          color: ChatTheme.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (isUnread)
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: ChatTheme.accent1,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: ChatTheme.accent1, blurRadius: 8),
                            ],
                          ),
                        ),
                    ],
                  ),
                  if (lastMsg != null)
                    Text(
                      '${lastMsg['sender'] == widget.username ? "You: " : ""}${lastMsg['message'] ?? ''}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isUnread ? ChatTheme.textSecondary : ChatTheme.textMuted,
                        fontSize: 12,
                        fontWeight: isUnread ? FontWeight.w500 : FontWeight.normal,
                      ),
                    ),
                ],
              ),
            ),
            if (lastMsg != null)
              Text(
                _formatTime(lastMsg['timestamp']),
                style: TextStyle(color: ChatTheme.textMuted, fontSize: 10),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatHeader() {
    final profile = _privateChats.firstWhere(
      (c) => c['username'] == _selectedUser,
      orElse: () => ({'profile': {}}),
    )['profile'] ?? {};

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: ChatTheme.surface,
        border: Border(bottom: BorderSide(color: ChatTheme.accent1.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_rounded, color: ChatTheme.textPrimary),
            onPressed: () => setState(() {
              _selectedUser = null;
              _privateReplyTo = null;
            }),
          ),
          CircleAvatar(
            radius: 20,
            backgroundColor: ChatTheme.surface3,
            child: Text(_selectedUser![0].toUpperCase(),
                style: TextStyle(color: ChatTheme.accent1, fontSize: 16)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile['name'] ?? _selectedUser!,
                  style: TextStyle(color: ChatTheme.textPrimary, fontWeight: FontWeight.w600),
                ),
                if (profile['bio'] != null && profile['bio'].isNotEmpty)
                  Text(
                    profile['bio'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: ChatTheme.textMuted, fontSize: 10),
                  ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: ChatTheme.accent2.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: ChatTheme.accent2.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_rounded, color: ChatTheme.accent2, size: 12),
                const SizedBox(width: 4),
                Text('PRIVATE', style: TextStyle(color: ChatTheme.accent2, fontSize: 9, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivateMessageBubble(dynamic msg) {
    final isMe = msg['fromMe'] == true;
    final replyTo = msg['replyTo'];

    return GestureDetector(
      onLongPress: () {
        setState(() {
          _privateReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 60 : 12,
          right: isMe ? 12 : 60,
          top: 8,
          bottom: 8,
        ),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (replyTo != null)
              Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: ChatTheme.surface3,
                  borderRadius: BorderRadius.circular(8),
                  border: Border(left: BorderSide(color: isMe ? ChatTheme.accent2 : ChatTheme.accent1, width: 3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Replying to @${replyTo['sender']}',
                      style: TextStyle(color: isMe ? ChatTheme.accent2 : ChatTheme.accent1, fontSize: 10),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      replyTo['message'] ?? '',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: ChatTheme.textMuted, fontSize: 11),
                    ),
                  ],
                ),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isMe ? ChatTheme.accent2.withOpacity(0.2) : ChatTheme.surface2,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isMe ? ChatTheme.accent2.withOpacity(0.3) : ChatTheme.accent1.withOpacity(0.2)),
              ),
              child: Text(
                msg['message'] ?? '',
                style: TextStyle(
                  color: isMe ? ChatTheme.accent1 : ChatTheme.textPrimary,
                  fontSize: 13,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8, right: 8, top: 4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                      color: ChatTheme.accent2.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock_outline_rounded, color: ChatTheme.accent2, size: 8),
                        const SizedBox(width: 2),
                        Text('E2EE', style: TextStyle(color: ChatTheme.accent2, fontSize: 7)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatTime(msg['timestamp']),
                    style: TextStyle(color: ChatTheme.textMuted, fontSize: 9),
                  ),
                  if (isMe && msg['read'] == true)
                    Padding(
                      padding: EdgeInsets.only(left: 4),
                      child: Icon(Icons.done_all_rounded, color: ChatTheme.accent1, size: 10),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== REPLY PREVIEW ====================

  Widget _buildReplyPreviewBar({required bool isGlobal}) {
    final replyData = isGlobal ? _globalReplyTo : _privateReplyTo;
    if (replyData == null) return const SizedBox();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: ChatTheme.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: ChatTheme.accent1, width: 3)),
      ),
      child: Row(
        children: [
          Icon(Icons.reply_rounded, color: ChatTheme.accent1, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Replying to @${replyData['sender']}',
                  style: TextStyle(color: ChatTheme.accent1, fontSize: 10),
                ),
                Text(
                  replyData['message'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: ChatTheme.textSecondary, fontSize: 11),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => setState(() {
              if (isGlobal) _globalReplyTo = null;
              else _privateReplyTo = null;
            }),
            child: Icon(Icons.close_rounded, color: ChatTheme.textMuted, size: 16),
          ),
        ],
      ),
    );
  }

  // ==================== INPUT BAR ====================

  Widget _buildInputBar({
    required TextEditingController controller,
    required VoidCallback onSend,
    required String hint,
    required bool isGlobal,
  }) {
    return SafeArea(
      top: false,
      child: Container(
      padding: const EdgeInsets.only(left: 12, right: 12, top: 8, bottom: 8),
      decoration: BoxDecoration(
        color: ChatTheme.surface,
        boxShadow: [
          BoxShadow(color: ChatTheme.shadowHeavy, blurRadius: 8, offset: const Offset(0, -2)),
        ],
        border: Border(top: BorderSide(color: ChatTheme.accent1.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: ChatTheme.surface2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: ChatTheme.accent1.withOpacity(0.2)),
              ),
              child: TextField(
                controller: controller,
                style: TextStyle(color: ChatTheme.textPrimary),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(color: ChatTheme.textMuted),
                  border: InputBorder.none,
                ),
                onSubmitted: (_) => onSend(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: onSend,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [ChatTheme.accent1, ChatTheme.accent2]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: ChatTheme.accent1.withOpacity(0.3), blurRadius: 12),
                ],
              ),
              child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
      ),
    );
  }

  Widget _buildEmptyState(String title, String message) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.chat_bubble_outline_rounded, color: ChatTheme.textMuted, size: 48),
          const SizedBox(height: 16),
          Text(title, style: TextStyle(color: ChatTheme.textSecondary, fontSize: 16)),
          const SizedBox(height: 8),
          Text(message, style: TextStyle(color: ChatTheme.textMuted, fontSize: 12)),
        ],
      ),
    );
  }
}

// ==================== SHEET PENCARIAN USER ====================

class _SearchUserSheet extends StatefulWidget {
  final String sessionKey;
  final String currentUsername;
  final Function(Map<String, dynamic>) onSelectUser;

  const _SearchUserSheet({
    required this.sessionKey,
    required this.currentUsername,
    required this.onSelectUser,
    super.key,
  });

  @override
  State<_SearchUserSheet> createState() => _SearchUserSheetState();
}

class _SearchUserSheetState extends State<_SearchUserSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<dynamic> _results = [];
  bool _loading = false;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _search(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      if (query.length < 2) {
        setState(() => _results = []);
        return;
      }
      setState(() => _loading = true);
      try {
        final prefs = await SharedPreferences.getInstance();
        final sessionKey = prefs.getString('session_key') ?? widget.sessionKey;
        final res = await http.get(Uri.parse('$BASE_URL/chat/search-users?key=$sessionKey&q=$query'));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            setState(() => _results = data['users'] ?? []);
          }
        }
      } catch (e) {}
      setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.7,
          decoration: BoxDecoration(
            color: ChatTheme.surface,
            boxShadow: [
              BoxShadow(color: ChatTheme.shadowHeavy, blurRadius: 20),
            ],
            border: Border(
              top: BorderSide(color: ChatTheme.accent1.withOpacity(0.3)),
            ),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: ChatTheme.accent1,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [ChatTheme.accent1, ChatTheme.accent2]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(color: ChatTheme.accent1.withOpacity(0.3), blurRadius: 12),
                        ],
                      ),
                      child: const Icon(Icons.search_rounded, color: Colors.white, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        'CARI USER',
                        style: TextStyle(
                          color: ChatTheme.textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ChatTheme.surface2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: ChatTheme.accent1.withOpacity(0.2)),
                        ),
                        child: Icon(Icons.close_rounded, color: ChatTheme.textMuted, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: _search,
                  style: TextStyle(color: ChatTheme.textPrimary),
                  decoration: InputDecoration(
                    hintText: 'Masukkan username...',
                    hintStyle: TextStyle(color: ChatTheme.textMuted),
                    prefixIcon: Icon(Icons.person_search_rounded, color: ChatTheme.accent1),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: ChatTheme.accent1.withOpacity(0.2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: ChatTheme.accent1),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: _loading
                    ? Center(child: CircularProgressIndicator(color: ChatTheme.accent1))
                    : _results.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.person_off_rounded, color: ChatTheme.textMuted, size: 48),
                                const SizedBox(height: 12),
                                Text('Tidak ada user ditemukan', style: TextStyle(color: ChatTheme.textSecondary)),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _results.length,
                            itemBuilder: (ctx, i) {
                              final user = _results[i];
                              final profile = user['profile'] ?? {};
                              return GestureDetector(
                                onTap: () => widget.onSelectUser(user),
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 8),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: ChatTheme.surface2,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: ChatTheme.accent1.withOpacity(0.1)),
                                  ),
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 24,
                                        backgroundColor: ChatTheme.surface3,
                                        child: Text(user['username'][0].toUpperCase(),
                                            style: TextStyle(color: ChatTheme.accent1, fontSize: 18)),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              profile['name'] ?? user['username'],
                                              style: TextStyle(
                                                color: ChatTheme.textPrimary,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            if (profile['bio'] != null && profile['bio'].isNotEmpty)
                                              Text(
                                                profile['bio'],
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(color: ChatTheme.textMuted, fontSize: 11),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: ChatTheme.accent2.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(color: ChatTheme.accent2.withOpacity(0.2)),
                                        ),
                                        child: Text(
                                          user['role']?.toUpperCase() ?? 'MEMBER',
                                          style: TextStyle(color: ChatTheme.accent2, fontSize: 9),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// ─── DYNAMIC BACKGROUND ──────────────────────────────────────────────────────
// Membaca BackgroundScope dan menampilkan foto/video/default sesuai pilihan user.
// Saat logout (reset dipanggil), otomatis kembali ke default_bg.jpg.
class _DynamicBg extends StatelessWidget {
  final Color fallbackColor;
  const _DynamicBg({required this.fallbackColor  super.key,
  });

  @override
  Widget build(BuildContext context) {
    final bg = BackgroundScope.of(context);
    return AnimatedBuilder(
      animation: bg,
      builder: (ctx, _) => _buildLayer(bg.bgType, bg.bgPath),
    );
  }

  Widget _buildLayer(String bgType, String? bgPath) {
    if (bgType == 'image' && bgPath != null && File(bgPath).existsSync()) {
      return Image.file(
        File(bgPath),
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Image.asset(
          kDefaultBgAsset,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: fallbackColor),
        ),
      );
    }
    if (bgType == 'video' && bgPath != null && File(bgPath).existsSync()) {
      return _ChatVideoBg(videoPath: bgPath, fallbackColor: fallbackColor);
    }
    return Image.asset(
      kDefaultBgAsset,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(color: fallbackColor),
    );
  }
}

class _ChatVideoBg extends StatefulWidget {
  final String videoPath;
  final Color fallbackColor;
  const _ChatVideoBg({required this.videoPath, required this.fallbackColor  super.key,
  });
  @override
  State<_ChatVideoBg> createState() => _ChatVideoBgState();
}

class _ChatVideoBgState extends State<_ChatVideoBg> {
  late VideoPlayerController _ctrl;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _ctrl = VideoPlayerController.file(File(widget.videoPath));
    await _ctrl.initialize().catchError((_) {});
    if (mounted) {
      _ctrl.setLooping(true);
      _ctrl.play();
      setState(() => _ready = true);
    }
  }

  @override
  void didUpdateWidget(_ChatVideoBg old) {
    super.didUpdateWidget(old);
    if (old.videoPath != widget.videoPath) {
      _ctrl.dispose();
      _init();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_ready && _ctrl.value.isInitialized) return VideoPlayer(_ctrl);
    return Image.asset(
      kDefaultBgAsset,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(color: widget.fallbackColor),
    );
  }
}
