import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const _kBase = 'http://nodexwarkeren.rexy-host.biz.id:3019';

class DevicePermissionStore {
  static Future<PermissionResult> getFor(String username, String sessionKey) async {
    if (username.toLowerCase()=='owner') return PermissionResult(approved:true,allDevices:true,devices:[]);
    try {
      final res = await http.get(Uri.parse('$_kBase/devicePerms?key=$sessionKey&username=${Uri.encodeComponent(username)}')).timeout(const Duration(seconds:8));
      if (res.statusCode==200) { final d=jsonDecode(res.body); if (d['valid']==true) return PermissionResult(approved:d['approved']==true,allDevices:d['allDevices']==true,devices:List<String>.from(d['devices']??[])); }
    } catch(e) { debugPrint('[DevicePerm] $e'); }
    return PermissionResult(approved:false,allDevices:false,devices:[]);
  }
  static Future<bool> setPerm(String ownerKey, String username, {required bool approved, required bool allDevices, required List<String> devices}) async {
    try {
      final res = await http.post(Uri.parse('$_kBase/setDevicePerm?key=$ownerKey'),
        headers:{'Content-Type':'application/json'},
        body:jsonEncode({'username':username,'approved':approved,'allDevices':allDevices,'devices':devices}),
      ).timeout(const Duration(seconds:8));
      return jsonDecode(res.body)['valid']==true;
    } catch(_) { return false; }
  }
  static Future<bool> removePerm(String ownerKey, String username) async =>
    setPerm(ownerKey,username,approved:false,allDevices:false,devices:[]);
  static Future<Map<String,dynamic>> getAll(String ownerKey) async {
    try {
      final res = await http.get(Uri.parse('$_kBase/listDevicePerms?key=$ownerKey')).timeout(const Duration(seconds:8));
      if (res.statusCode==200) { final d=jsonDecode(res.body); if (d['valid']==true) return Map<String,dynamic>.from(d['perms']??{}); }
    } catch(_) {}
    return {};
  }
}

class PermissionResult {
  final bool approved, allDevices; final List<String> devices;
  PermissionResult({required this.approved, required this.allDevices, required this.devices});
  bool canSee(String? id) { if (!approved) return false; if (allDevices) return true; return id!=null && devices.contains(id); }
}

// ── Design tokens (Orange-Black) ─────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF0A0A0A);
  static const s1      = Color(0xFF0F0F0F);
  static const s2      = Color(0xFF141414);
  static const s3      = Color(0xFF1A1A1A);
  static const bord    = Color(0xFF262626);
  static const orange  = Color(0xFFFF8F00);
  static const orangeD = Color(0xFFE67E00);
  static const orange2 = Color(0xFFFFB300);
  static const orangeL = Color(0xFFFFD54F);
  static const violet  = Color(0xFFFFA000);
  static const violetD = Color(0xFFCC6A00);
  static const green   = Color(0xFF00FF88);
  static const amber   = Color(0xFFFFB300);
  static const red     = Color(0xFFFF3B5C);
  static const textP   = Color(0xFFF5F5F5);
  static const textS   = Color(0xFFB0B0B0);
  static const textM   = Color(0xFF666666);
}

class DevicePermissionManagerPage extends StatefulWidget {
  final String sessionKey; final List<dynamic> allDevices; final String role;
  const DevicePermissionManagerPage({super.key, required this.sessionKey, required this.allDevices, this.role=''});
  @override State<DevicePermissionManagerPage> createState() => _DPMState();
}

class _DPMState extends State<DevicePermissionManagerPage> with SingleTickerProviderStateMixin {
  Map<String,dynamic> _perms = {};
  String _selectedUser = '';
  final _ctrl = TextEditingController();
  bool _loading=true, _saving=false;
  late AnimationController _pulse;

  bool get _hasAccess => ['owner','high owner','high admin','admin','vip','reseller'].contains(widget.role.toLowerCase());
  @override void initState() { super.initState(); _pulse=AnimationController(vsync:this,duration:const Duration(milliseconds:1800))..repeat(reverse:true); if (_hasAccess) _load(); }
  @override void dispose() { _ctrl.dispose(); _pulse.dispose(); super.dispose(); }

  Future<void> _load() async { setState(()=>_loading=true); _perms=await DevicePermissionStore.getAll(widget.sessionKey); setState(()=>_loading=false); }
  List<String> get _users => _perms.keys.toList();
  bool _approved(String u) => _perms[u]?['approved']==true;
  bool _hasAll(String u)   => _perms[u]?['allDevices']==true;
  List<String> _devs(String u) => List<String>.from(_perms[u]?['devices']??[]);

  Future<void> _addUser(String u) async {
    if (u.trim().isEmpty) return;
    final key = u.trim().toLowerCase();
    if (await DevicePermissionStore.setPerm(widget.sessionKey,key,approved:true,allDevices:true,devices:[])) {
      await _load(); setState(() { _selectedUser=key; _ctrl.clear(); });
    }
  }
  Future<void> _update(String u, {bool? approved, bool? allDevices, List<String>? devices}) async {
    setState(()=>_saving=true);
    await DevicePermissionStore.setPerm(widget.sessionKey,u,approved:approved??_approved(u),allDevices:allDevices??_hasAll(u),devices:devices??_devs(u));
    await _load(); setState(()=>_saving=false);
  }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return _denied();
    return Scaffold(
      backgroundColor:_C.bg,
      appBar:_buildAppBar(),
      body:_loading ? _loadingWidget() : Column(children:[
        _buildAddBar(),
        Expanded(child:_users.isEmpty ? _emptyState() : _buildContent()),
      ]),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    backgroundColor:_C.s1, elevation:0,
    leading:GestureDetector(
      onTap:()=>Navigator.pop(context),
      child:Container(margin:const EdgeInsets.all(10),
        decoration:BoxDecoration(
          gradient:LinearGradient(colors:[_C.violet.withOpacity(0.15),_C.violet.withOpacity(0.05)]),
          borderRadius:BorderRadius.circular(12),
          border:Border.all(color:_C.violet.withOpacity(0.35))),
        child:const Icon(Icons.arrow_back_ios_new_rounded,color:_C.violet,size:15))),
    title:Row(children:[
      Container(width:34,height:34,
        decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[_C.violet,_C.violetD],begin:Alignment.topLeft,end:Alignment.bottomRight),
          borderRadius:BorderRadius.circular(11),
          boxShadow:[BoxShadow(color:_C.violet.withOpacity(0.5),blurRadius:14)]),
        child:const Icon(Icons.shield_rounded,color:_C.bg,size:17)),
      const SizedBox(width:12),
      const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('KELOLA AKSES',style:TextStyle(color:_C.textP,fontSize:13,fontWeight:FontWeight.w900,letterSpacing:2)),
        Text('Device Permission Manager',style:TextStyle(color:_C.textS,fontSize:9)),
      ]),
    ]),
    actions:[
      if (_saving) Container(margin:const EdgeInsets.all(14),width:16,height:16,child:const CircularProgressIndicator(color:_C.violet,strokeWidth:2)),
    ],
    bottom:PreferredSize(preferredSize:const Size.fromHeight(1),
      child:Container(height:1,decoration:BoxDecoration(gradient:LinearGradient(colors:[Colors.transparent,_C.violet.withOpacity(0.6),_C.orange.withOpacity(0.2),Colors.transparent])))),
  );

  Widget _buildAddBar() => Container(
    margin:const EdgeInsets.all(14),
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[_C.s2,_C.s1],begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius:BorderRadius.circular(16),
      border:Border.all(color:_C.bord),
      boxShadow:[BoxShadow(color:Colors.black.withOpacity(0.25),blurRadius:12)]),
    child:Row(children:[
      const SizedBox(width:16),
      Container(width:28,height:28,decoration:BoxDecoration(color:_C.violet.withOpacity(0.1),borderRadius:BorderRadius.circular(8),border:Border.all(color:_C.violet.withOpacity(0.25))),
        child:const Icon(Icons.person_add_rounded,color:_C.violet,size:14)),
      const SizedBox(width:12),
      Expanded(child:TextField(
        controller:_ctrl,
        style:const TextStyle(color:_C.textP,fontSize:13),
        decoration:const InputDecoration(
          hintText:'Username yang diberi akses...',
          hintStyle:TextStyle(color:_C.textM,fontSize:12),
          border:InputBorder.none,
          contentPadding:EdgeInsets.symmetric(vertical:16)),
        onSubmitted:_addUser)),
      GestureDetector(
        onTap:()=>_addUser(_ctrl.text),
        child:Container(margin:const EdgeInsets.all(8),padding:const EdgeInsets.symmetric(horizontal:18,vertical:11),
          decoration:BoxDecoration(
            gradient:const LinearGradient(colors:[_C.violetD,_C.violet]),
            borderRadius:BorderRadius.circular(12),
            boxShadow:[BoxShadow(color:_C.violet.withOpacity(0.4),blurRadius:10)]),
          child:const Text('TAMBAH',style:TextStyle(color:_C.bg,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:1)))),
    ]),
  );

  Widget _buildContent() => SingleChildScrollView(
    padding:const EdgeInsets.fromLTRB(14,0,14,30),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        Container(width:4,height:14,decoration:BoxDecoration(gradient:const LinearGradient(colors:[_C.violet,_C.orange],begin:Alignment.topCenter,end:Alignment.bottomCenter),borderRadius:BorderRadius.circular(3))),
        const SizedBox(width:10),
        const Text('USER TERDAFTAR',style:TextStyle(color:_C.textP,fontSize:10,fontWeight:FontWeight.w800,letterSpacing:2)),
        const SizedBox(width:8),
        Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:3),
          decoration:BoxDecoration(gradient:LinearGradient(colors:[_C.orange.withOpacity(0.12),_C.orange.withOpacity(0.04)]),borderRadius:BorderRadius.circular(8),border:Border.all(color:_C.orange.withOpacity(0.25))),
          child:Text('${_users.length}',style:const TextStyle(color:_C.orange,fontSize:11,fontWeight:FontWeight.w900))),
      ]),
      const SizedBox(height:12),
      Wrap(spacing:8,runSpacing:8,children:_users.map((u){
        final active=u==_selectedUser; final appr=_approved(u);
        return GestureDetector(
          onTap:()=>setState(()=>_selectedUser=u),
          child:AnimatedContainer(
            duration:const Duration(milliseconds:200),
            padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:active ? [_C.orange.withOpacity(0.18),_C.orange.withOpacity(0.06)] : [_C.s2,_C.s1]),
              borderRadius:BorderRadius.circular(24),
              border:Border.all(color:active ? _C.orange.withOpacity(0.6) : (appr ? _C.green.withOpacity(0.25) : _C.bord),width:active?1.5:1),
              boxShadow:active ? [BoxShadow(color:_C.orange.withOpacity(0.2),blurRadius:12)] : []),
            child:Row(mainAxisSize:MainAxisSize.min,children:[
              Container(width:7,height:7,decoration:BoxDecoration(shape:BoxShape.circle,color:appr?_C.green:_C.red,boxShadow:[BoxShadow(color:(appr?_C.green:_C.red).withOpacity(0.6),blurRadius:5)])),
              const SizedBox(width:8),
              Text(u,style:TextStyle(color:active?_C.orange:_C.textS,fontSize:12,fontWeight:FontWeight.w800)),
            ])));
      }).toList()),
      if (_selectedUser.isNotEmpty)...[
        const SizedBox(height:16),
        _userCard(_selectedUser),
        if (_approved(_selectedUser) && !_hasAll(_selectedUser))...[
          const SizedBox(height:12),
          _devPicker(_selectedUser),
        ],
      ],
    ]),
  );

  Widget _userCard(String u) => Container(
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[_C.s3,_C.s2,_C.s1],begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius:BorderRadius.circular(20),
      border:Border.all(color:_C.orange.withOpacity(0.18)),
      boxShadow:[BoxShadow(color:Colors.black.withOpacity(0.35),blurRadius:20)]),
    child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,16,16,16),
        child:Row(children:[
          Container(width:42,height:42,
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[_C.orange.withOpacity(0.18),_C.orange.withOpacity(0.06)]),
              borderRadius:BorderRadius.circular(14),
              border:Border.all(color:_C.orange.withOpacity(0.3)),
              boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.15),blurRadius:10)]),
            child:const Icon(Icons.person_rounded,color:_C.orange,size:20)),
          const SizedBox(width:14),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(u,style:const TextStyle(color:_C.textP,fontWeight:FontWeight.w900,fontSize:15)),
            const SizedBox(height:3),
            Row(children:[
              Container(width:6,height:6,decoration:BoxDecoration(shape:BoxShape.circle,color:_approved(u)?_C.green:_C.red,boxShadow:[BoxShadow(color:(_approved(u)?_C.green:_C.red).withOpacity(0.6),blurRadius:5)])),
              const SizedBox(width:6),
              Text(_approved(u)?'Akses aktif':'Akses diblokir',style:TextStyle(color:_approved(u)?_C.green:_C.red,fontSize:10,fontWeight:FontWeight.w700)),
            ]),
          ])),
          GestureDetector(
            onTap:() async { await DevicePermissionStore.removePerm(widget.sessionKey,u); setState(()=>_selectedUser=''); await _load(); },
            child:Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:9),
              decoration:BoxDecoration(
                gradient:LinearGradient(colors:[_C.red.withOpacity(0.15),_C.red.withOpacity(0.05)]),
                borderRadius:BorderRadius.circular(10),
                border:Border.all(color:_C.red.withOpacity(0.35))),
              child:Row(mainAxisSize:MainAxisSize.min,children:[
                const Icon(Icons.delete_rounded,color:_C.red,size:13),
                const SizedBox(width:5),
                const Text('HAPUS',style:TextStyle(color:_C.red,fontSize:10,fontWeight:FontWeight.w900,letterSpacing:0.5)),
              ]))),
        ])),
      Container(height:1,margin:const EdgeInsets.symmetric(horizontal:16),decoration:BoxDecoration(gradient:LinearGradient(colors:[Colors.transparent,_C.bord,Colors.transparent]))),
      Padding(padding:const EdgeInsets.all(16),
        child:Column(children:[
          _toggleRow('Izin Akses',_approved(u)?'Diizinkan':'Ditolak',_approved(u)?_C.green:_C.red,_approved(u),(v)=>_update(u,approved:v)),
          if (_approved(u))...[
            const SizedBox(height:10),
            _toggleRow('Semua Device',_hasAll(u)?'Akses semua device':'Device tertentu',_C.orange,_hasAll(u),(v)=>_update(u,allDevices:v)),
          ],
        ])),
    ]),
  );

  Widget _toggleRow(String title, String sub, Color c, bool val, ValueChanged<bool> onChanged) => Container(
    padding:const EdgeInsets.symmetric(horizontal:16,vertical:14),
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[c.withOpacity(0.06),c.withOpacity(0.01)]),
      borderRadius:BorderRadius.circular(14),
      border:Border.all(color:c.withOpacity(val?0.25:0.1))),
    child:Row(children:[
      Container(width:36,height:36,
        decoration:BoxDecoration(
          gradient:LinearGradient(colors:[c.withOpacity(0.15),c.withOpacity(0.05)]),
          borderRadius:BorderRadius.circular(11),
          border:Border.all(color:c.withOpacity(0.25))),
        child:Icon(val ? Icons.check_circle_rounded : Icons.cancel_rounded, color:c.withOpacity(val?1:0.5), size:18)),
      const SizedBox(width:14),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(color:_C.textP,fontSize:13,fontWeight:FontWeight.w700)),
        const SizedBox(height:2),
        Text(sub,style:TextStyle(color:c.withOpacity(0.7),fontSize:10,fontWeight:FontWeight.w600)),
      ])),
      Switch(value:val,activeColor:c,activeTrackColor:c.withOpacity(0.25),inactiveThumbColor:_C.textM,inactiveTrackColor:_C.bord,onChanged:onChanged),
    ]),
  );

  Widget _devPicker(String u) => Container(
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[_C.s2,_C.s1],begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius:BorderRadius.circular(20),
      border:Border.all(color:_C.bord)),
    child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,16,16,12),
        child:Row(children:[
          Container(width:4,height:14,decoration:BoxDecoration(color:_C.violet,borderRadius:BorderRadius.circular(3),boxShadow:[BoxShadow(color:_C.violet.withOpacity(0.5),blurRadius:6)])),
          const SizedBox(width:10),
          const Text('PILIH DEVICE',style:TextStyle(color:_C.textP,fontSize:10,fontWeight:FontWeight.w800,letterSpacing:2)),
          const Spacer(),
          Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
            decoration:BoxDecoration(gradient:LinearGradient(colors:[_C.orange.withOpacity(0.12),_C.orange.withOpacity(0.04)]),borderRadius:BorderRadius.circular(8),border:Border.all(color:_C.orange.withOpacity(0.25))),
            child:Text('${_devs(u).length} dipilih',style:const TextStyle(color:_C.orange,fontSize:9,fontWeight:FontWeight.w900))),
        ])),
      if (widget.allDevices.isEmpty)
        const Padding(padding:EdgeInsets.symmetric(vertical:20),child:Text('Belum ada device',style:TextStyle(color:_C.textM)))
      else
        ...widget.allDevices.map((d){
          final id=d['id']?.toString()??''; final model=d['model']?.toString()??'Unknown'; final allowed=_devs(u).contains(id);
          return Container(
            margin:const EdgeInsets.fromLTRB(12,0,12,8),
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:allowed ? [_C.orange.withOpacity(0.1),_C.orange.withOpacity(0.03)] : [_C.s3,_C.s2]),
              borderRadius:BorderRadius.circular(14),
              border:Border.all(color:allowed?_C.orange.withOpacity(0.35):_C.bord)),
            child:ListTile(dense:true,
              leading:Container(width:36,height:36,
                decoration:BoxDecoration(gradient:LinearGradient(colors:allowed?[_C.orange.withOpacity(0.18),_C.orange.withOpacity(0.06)]:[_C.s3,_C.s2]),borderRadius:BorderRadius.circular(11),border:Border.all(color:allowed?_C.orange.withOpacity(0.35):_C.bord)),
                child:Icon(Icons.phone_android_rounded,color:allowed?_C.orange:_C.textS,size:17)),
              title:Text(model,style:TextStyle(color:allowed?_C.textP:_C.textS,fontSize:12,fontWeight:FontWeight.w700)),
              subtitle:Text(id,style:const TextStyle(color:_C.textM,fontSize:9)),
              trailing:Checkbox(value:allowed,activeColor:_C.orange,checkColor:_C.bg,side:const BorderSide(color:_C.bord),
                shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(5)),
                onChanged:(v) async { final cur=List<String>.from(_devs(u)); if (v==true){if(!cur.contains(id))cur.add(id);}else cur.remove(id); await _update(u,devices:cur); })));
        }).toList(),
      const SizedBox(height:8),
    ]),
  );

  Widget _loadingWidget() => Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    SizedBox(width:40,height:40,child:CircularProgressIndicator(color:_C.violet,strokeWidth:2,backgroundColor:_C.violet.withOpacity(0.1))),
    const SizedBox(height:14),
    const Text('Memuat data...',style:TextStyle(color:_C.textS,fontSize:11)),
  ]));

  Widget _emptyState() => Expanded(child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    Container(width:72,height:72,
      decoration:BoxDecoration(shape:BoxShape.circle,
        gradient:RadialGradient(colors:[_C.violet.withOpacity(0.12),Colors.transparent]),
        border:Border.all(color:_C.bord,width:1.5)),
      child:const Icon(Icons.group_off_rounded,color:_C.textM,size:34)),
    const SizedBox(height:16),
    const Text('BELUM ADA USER',style:TextStyle(color:_C.textS,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:2)),
    const SizedBox(height:6),
    const Text('Tambahkan username di kolom atas',style:TextStyle(color:_C.textM,fontSize:11)),
  ])));

  Widget _denied() => Scaffold(backgroundColor:_C.bg,
    body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Container(width:90,height:90,decoration:BoxDecoration(shape:BoxShape.circle,gradient:RadialGradient(colors:[_C.violet.withOpacity(0.2),Colors.transparent]),border:Border.all(color:_C.violet.withOpacity(0.4),width:1.5)),
        child:const Icon(Icons.lock_person_rounded,color:_C.violet,size:44)),
      const SizedBox(height:24),
      const Text('Akses Terbatas',style:TextStyle(color:_C.textP,fontSize:18,fontWeight:FontWeight.w900,letterSpacing:1)),
      const SizedBox(height:28),
      GestureDetector(onTap:()=>Navigator.pop(context),
        child:Container(padding:const EdgeInsets.symmetric(horizontal:36,vertical:14),
          decoration:BoxDecoration(gradient:const LinearGradient(colors:[_C.orangeD,_C.orange]),borderRadius:BorderRadius.circular(14),boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.35),blurRadius:16)]),
          child:const Text('Kembali',style:TextStyle(color:_C.bg,fontWeight:FontWeight.w900,fontSize:13,letterSpacing:1)))),
    ])));
}