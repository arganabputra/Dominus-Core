import 'package:otax/core/anime/providers/providerDetails.dart';
import 'package:otax/core/anime/providers/types.dart';
import 'package:otax/core/app/logging.dart';
import 'package:otax/core/app/runtimeDatas.dart';
import 'package:otax/core/commons/enums.dart';
import 'package:otax/core/commons/utils.dart';
import 'package:otax/core/data/animeSpecificPreference.dart';
import 'package:otax/core/data/preferences.dart';
import 'package:otax/core/data/types.dart';
import 'package:otax/core/data/watching.dart';
import 'package:otax/core/database/anilist/login.dart';
import 'package:otax/core/database/database.dart';
import 'package:otax/core/database/handler/handler.dart';
import 'package:otax/core/database/types.dart';
import 'package:otax/ui/models/snackBar.dart';
import 'package:otax/ui/models/sources.dart';
import 'package:flutter/material.dart';

class InfoProvider extends ChangeNotifier {
  int id;
  InfoProvider(int id) : this.id = id;

  late DatabaseInfo _data;

  final sourceManager = SourceManager.instance;

  // Will be set in _init()
  late ProviderDetails _selectedSource;

  String? _foundName;
  String? _manualSearchQuery;

  MediaStatus? _mediaListStatus;

  List<EpisodeDetails> _epLinks = [];
  List<VideoStream> _streamSources = [];
  List<Map<String, String>> _qualities = [];
  List<List<Map<String, dynamic>>> _visibleEpList = [];
  List<AlternateDatabaseId> _altDatabases = [];

  int _currentPageIndex = 0;
  int _watched = 0;
  int _viewMode = 0;

  // Index of episode selected
  int? _selectedEpisodeToLoadStreams;

  Map? _lastWatchedDurationMap = {};

  bool _started = false;
  bool _epSearcherror = false;
  bool _loggedIn = false;
  bool _dataLoaded = false;
  bool _infoPage = true;
  bool _infoLoadError = false;
  bool _preferDubs = false;

  // Getters
  bool get infoLoadError => _infoLoadError;
  bool get started => _started;
  bool get epSearcherror => _epSearcherror;
  bool get loggedIn => _loggedIn;
  bool get dataLoaded => _dataLoaded;
  bool get infoPage => _infoPage;
  bool get preferDubs => _preferDubs;

  Map? get lastWatchedDurationMap => _lastWatchedDurationMap;

  int get watched => _watched;
  int get viewMode => _viewMode;
  int get currentPageIndex => _currentPageIndex;
  int get viewModeIndexLength => 3;
  int? get selectedEpisodeToLoadStreams => _selectedEpisodeToLoadStreams;

  List<VideoStream> get streamSources => _streamSources;
  List<Map<String, String>> get qualities => _qualities;
  List<List<Map<String, dynamic>>> get visibleEpList => _visibleEpList;
  List<AlternateDatabaseId> get altDatabases => _altDatabases;
  List<EpisodeDetails> get epLinks => _epLinks;

  /// Current [MediaStatus] in the user's list
  MediaStatus? get mediaListStatus => _mediaListStatus;

  /// The name found from the search in the source
  String? get foundName => _foundName;

  /// Currently selected source
  ProviderDetails get selectedSource => _selectedSource;

  /// The Anime info
  DatabaseInfo get data => _data;

  bool _initCalled = false;

  String? aspProvider;

  set selectedSource(ProviderDetails val) {
    _selectedSource = val;
    if (aspProvider != val.identifier) {
      saveAnimeSpecificPreference(id.toString(), AnimeSpecificPreference(preferredProvider: val.identifier));
    }
    // we just using this condition for validation (too lazy to add a field for it)
    sourceManager.useInbuiltProviders = selectedSource.version == "0.0.0.0";
    notifyListeners();
  }

  set viewMode(int newIndex) {
    _viewMode = newIndex;
    UserPreferences.saveUserPreferences(
      UserPreferencesModal(
        episodesViewMode: UserPreferencesModal.getViewModeEnum(newIndex),
      ),
    );
    notifyListeners();
  }

  set foundName(String? val) {
    _foundName = val;
    notifyListeners();
  }

  set epSearcherror(bool val) {
    _epSearcherror = val;
    notifyListeners();
  }

  set currentPageIndex(int val) {
    _currentPageIndex = val;
    notifyListeners();
  }

  set selectedEpisodeToLoadStreams(int? newIndex) {
    _selectedEpisodeToLoadStreams = newIndex;
    notifyListeners();
  }

  set preferDubs(bool val) {
    _preferDubs = val;
    UserPreferences.saveUserPreferences(
      UserPreferencesModal(
        preferDubs: val,
      ),
    );
    paginate(epLinks);
    notifyListeners();
  }

  /// Called in the init state
  void init() async {
    if (_initCalled) throw Exception("The initialization was already done");
    _initCalled = true;

    // Load manualsearch query and last watch
    final asp = await getAnimeSpecificPreference(id.toString());
    _lastWatchedDurationMap = asp?.lastWatchDuration ?? {};
    _manualSearchQuery = asp?.manualSearchQuery;

    aspProvider = asp?.preferredProvider;

    // Set up sources.
    final sources = sourceManager.sources;
    final matchedSource = sources
        .where((e) => e.identifier == (asp?.preferredProvider ?? currentUserSettings?.preferredProvider))
        .firstOrNull; // pick provider from last selected provider or default one
    selectedSource =
        matchedSource != null ? matchedSource : (sources.isEmpty ? sourceManager.inbuiltSources[0] : sources[0]);

    await _getInfo(id);

    await loadPreferences();

    // load em concurrently (fixes the delay in loading the progress)
    getWatched();
    getEpisodes();
  }

  /// Fetch preferences
  Future<void> loadPreferences() async {
    final preferences = await UserPreferences.getUserPreferences();
    _viewMode = UserPreferencesModal.getViewModeIndex(preferences.episodesViewMode ?? EpisodeViewModes.tile);
    _preferDubs = preferences.preferDubs ?? false;

    //load TV stuff
    if (await isTv()) {
      // _watchInfoButtonFocusNode.requestFocus();
    }
    notifyListeners();
  }

  Future<void> getWatched({bool refreshLastWatchDuration = false}) async {
    try {
      if (await AniListLogin().isAnilistLoggedIn()) if (_mediaListStatus == null) {
        _watched = 0;
        _started = false;
      }
      final item = await getAnimeWatchProgress(id, _mediaListStatus);
      _watched = item == 0 ? 0 : item;
      _started = item != 0;

      final supposedPageIndex = watched ~/ 25; //index increases when the episodes are >24

      _currentPageIndex = supposedPageIndex >= visibleEpList.length ? visibleEpList.length - 1 : supposedPageIndex;

      if (refreshLastWatchDuration) {
        _lastWatchedDurationMap = (await getAnimeSpecificPreference(id.toString()))?.lastWatchDuration;
      }
    } catch (err) {
      floatingSnackBar("Couldn't fetch watch progress.");
      Logs.app.log(err.toString());
      if (currentUserSettings?.showErrors ?? false) {
        floatingSnackBar(err.toString(), waitForPreviousToFinish: true);
      }
    }

    notifyListeners();
  }

  Future<void> _getInfo(int id) async {
    final s = _altDatabases.toSet();
    Future<List<AlternateDatabaseId>>? simklFuture;

    try {
      if (currentUserSettings?.database == Databases.anilist && await AniListLogin().isAnilistLoggedIn()) {
        _loggedIn = true;
        //fetch ids from simkl and save em
        simklFuture = () async {
          try {
            final res = await DatabaseHandler(database: Databases.simkl).search("https://anilist.co/anime/$id");
            if (res.isEmpty) return <AlternateDatabaseId>[];
            final info = await DatabaseHandler(database: Databases.simkl).getAnimeInfo(res[0].id);
            return info.alternateDatabases;
          } catch (err) {
            Logs.app.log("[INFO] couldnt fetch simkl data. ${err.toString()}");
            if (currentUserSettings?.showErrors ?? false) {
              floatingSnackBar("Couldnt fetch simkl data");
            }
            return <AlternateDatabaseId>[];
          }
        }();
      }

      final futures = await Future.wait([DatabaseHandler().getAnimeInfo(id), if (simklFuture != null) simklFuture]);

      final info = futures[0] as DatabaseInfo;
      s.addAll(info.alternateDatabases);
      s.addAll(futures.length > 1 ? futures[1] as List<AlternateDatabaseId> : <AlternateDatabaseId>[]);
      _altDatabases = s.toList();
      _dataLoaded = true;
      _data = info;
      _mediaListStatus = assignItemEnum(data.mediaListStatus);
      notifyListeners();
    } catch (err) {
      Logs.app.log(err.toString());
      if (currentUserSettings!.showErrors != null && currentUserSettings!.showErrors!) floatingSnackBar(err.toString());
      _infoLoadError = true;
      notifyListeners();
      rethrow;
    }
  }

  // cleaned, refactored and pretty good ig
  void paginate(List<EpisodeDetails> links) {
    _epLinks = links;
    _visibleEpList.clear();

    final filteredList = <Map<String, dynamic>>[];
    int? watchedProgressIndex; // js a variable to track the last watched episode in filtered list

    // filter the list if dubs are available and user needs dubs (works for subs too)
    for (int i = 0; i < _epLinks.length; i++) {
      final hasDub = links[i].hasDub ?? false;
      if (!_preferDubs || hasDub) {
        if (watched == i) watchedProgressIndex = filteredList.length;
        filteredList.add({'realIndex': i, 'epLink': links[i]});
      }
    }

    // Paginate to sections of 24 stuff
    for (int i = 0; i < filteredList.length; i += 24) {
      int end = (i + 24 < filteredList.length) ? i + 24 : filteredList.length;
      _visibleEpList.add(filteredList.sublist(i, end));
    }

    if (_visibleEpList.isEmpty) {
      // to avoid errors ofcourse
      _visibleEpList.add([]);
      _currentPageIndex = 0;
    } else {
      _currentPageIndex = watchedProgressIndex != null ? (watchedProgressIndex ~/ 24) : 0;
    }

    // _currentPageIndex = _currentPageIndex >= _visibleEpList.length ? _visibleEpList.length-1 : _currentPageIndex;
  }

  Future<void> _search(String query) async {
    final sr = await sourceManager.searchInSource(selectedSource.identifier, query);
    //to find a exact match
    List<Map<String, String?>> match = sr
        .where(
          (e) => e['name'] == query,
        )
        .toList();
    if (match.isEmpty) match = sr;
    final links = await sourceManager.getAnimeEpisodes(selectedSource.identifier, match[0]['alias']!);
    paginate(links);
    _foundName = match[0]['name'];
    notifyListeners();
  }

  Future<void> getEpisodes() async {
    _foundName = null;
    _epSearcherror = false;
    try {
      String searchTitle = data.title['english'] ?? data.title['romaji'] ?? '';
      if (_manualSearchQuery != null) {
        searchTitle = _manualSearchQuery!;
      }
      await _search(searchTitle);
      notifyListeners();
    } catch (err) {
      Logs.app.log(err.toString());

      // try again with romaji title if english title failed

      final hasEnglishTitle = data.title['english'] != null;
      final didUseManualQuery = _manualSearchQuery != null;

      if (hasEnglishTitle && !didUseManualQuery) {
        // try once more with romaji title if english title failed
        try {
          await _search(data.title['romaji'] ?? '');
          notifyListeners();
          return;
        } catch (e) {
          Logs.app.log(e.toString());
        }
      }

      _epSearcherror = true;
      notifyListeners();
      if (currentUserSettings!.showErrors != null && currentUserSettings!.showErrors!) {
        floatingSnackBar(err.toString());
      }
    }
  }

  void clearLastWatchDuration() async {
    _lastWatchedDurationMap = {};
    await saveAnimeSpecificPreference(
        id.toString(), AnimeSpecificPreference(lastWatchDuration: _lastWatchedDurationMap));
    notifyListeners();
  }

  static IconData getTrackerIcon(MediaStatus? mediaListStatus) {
    switch (mediaListStatus?.name) {
      case "CURRENT":
        return Icons.movie_outlined;
      case "PLANNING":
        return Icons.calendar_month_outlined;
      case "COMPLETED":
        return Icons.done_all_rounded;
      case "DROPPED":
        return Icons.close_rounded;
      default:
        return Icons.add_rounded;
    }
  }

  void refreshListStatus(String? status, int progress) {
    _mediaListStatus = assignItemEnum(status);
    _watched = progress;
    notifyListeners();
  }
}
