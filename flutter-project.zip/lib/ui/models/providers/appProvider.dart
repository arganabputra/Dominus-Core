import 'dart:io';

import 'package:otax/core/app/runtimeDatas.dart';
import 'package:otax/core/data/theme.dart';
import 'package:otax/ui/theme/themes.dart';
import 'package:otax/ui/theme/types.dart';
import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

// Handles app wide settings (themes, plugin sources etc..)
class AppProvider with ChangeNotifier {
  AnimeStreamTheme _theme = appTheme;

  bool _isDark = currentUserSettings?.darkMode ?? false;

  AnimeStreamTheme get theme => _theme;

  bool get isDark => _isDark;

  bool _isFullScreen = false;

  bool get isFullScreen => _isFullScreen;

  String _windowTitle = "animestream";

  String get windowTitle => _windowTitle;

  Color? _titleBarColor = null;

  Color? get titleBarColor => _titleBarColor;

  // For desktops
  bool _showTitleBar = false;

  bool get showTitleBar => _showTitleBar;

  set showTitleBar(bool pip) {
    _showTitleBar = pip;
    notifyListeners();
  }

  set windowTitle(String newTitle) {
    _windowTitle = newTitle;
    notifyListeners();
  }

  set isFullScreen(bool fs) {
    _isFullScreen = fs;
    notifyListeners();
  }

  set theme(AnimeStreamTheme selectedTheme) {
    _theme = selectedTheme;

    final dark = currentUserSettings?.darkMode ?? true;

    appTheme = AnimeStreamTheme(
      accentColor: selectedTheme.accentColor,
      //set background color only if dark theme and amoled bg are true, otherwise set respective theme's default bg
      backgroundColor:
          ((currentUserSettings?.amoledBackground ?? false) && dark) ? Colors.black : selectedTheme.backgroundColor,
      backgroundSubColor: selectedTheme.backgroundSubColor,
      textMainColor: selectedTheme.textMainColor,
      textSubColor: selectedTheme.textSubColor,
      modalSheetBackgroundColor: selectedTheme.modalSheetBackgroundColor,
      onAccent: selectedTheme.onAccent,
    );

    notifyListeners();
  }

  set isDark(bool dark) {
    _isDark = dark;
  }

  /// Set the title bar color (only works on windows)
  /// If null, default system color is used
  void setTitlebarColor(Color? color) {
    _titleBarColor = color;
    notifyListeners();
  }

  void applyTheme(AnimeStreamTheme t) {
    theme = t;
  }

  Future<void> applyThemeMode(bool dark) async {
    isDark = dark;
    final themeId = await getTheme();
    final theme = availableThemes.firstWhere((thm) => thm.id == themeId, orElse: () => availableThemes[0]);

    if (dark) {
      appTheme = AnimeStreamTheme(
        accentColor: theme.theme.accentColor,
        backgroundColor: (currentUserSettings?.amoledBackground ?? false) ? Colors.black : theme.theme.backgroundColor,
        backgroundSubColor: theme.theme.backgroundSubColor,
        textMainColor: theme.theme.textMainColor,
        textSubColor: theme.theme.textSubColor,
        modalSheetBackgroundColor: theme.theme.modalSheetBackgroundColor,
        onAccent: theme.theme.onAccent,
      );
    } else {
      appTheme = AnimeStreamTheme(
        accentColor: theme.lightVariant.accentColor,
        backgroundColor: theme.lightVariant.backgroundColor,
        backgroundSubColor: theme.lightVariant.backgroundSubColor,
        textMainColor: theme.lightVariant.textMainColor,
        textSubColor: theme.lightVariant.textSubColor,
        modalSheetBackgroundColor: theme.lightVariant.modalSheetBackgroundColor,
        onAccent: theme.lightVariant.onAccent,
      );
    }

    notifyListeners();
  }

  /// Refresh the root Widget tree
  void justRefresh() {
    notifyListeners();
  }

  /// Set the window mode to fullscreen or windowed
  Future<void> setFullScreen(bool fs) async {
    if (Platform.isAndroid) return;
    await windowManager.setFullScreen(fs);
    isFullScreen = fs;
  }
}
