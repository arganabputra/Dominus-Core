import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ULAR TANGGA PAGE — Snakes and Ladders
// ─────────────────────────────────────────────────────────────────────────────

class UlarTanggaPage extends StatefulWidget {
  const UlarTanggaPage({super.key});
  @override
  State<UlarTanggaPage> createState() => _UlarTanggaPageState();
}

class _UlarTanggaPageState extends State<UlarTanggaPage>
    with SingleTickerProviderStateMixin {

  // Snakes: head -> tail (move backward)
  final Map<int, int> snakes = {
    16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78,
  };
  // Ladders: bottom -> top (move forward)
  final Map<int, int> ladders = {
    1: 38, 4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91,
  };

  int playerPos = 0;
  int aiPos = 0;
  int diceVal = 0;
  bool playerTurn = true;
  bool rolling = false;
  bool gameOver = false;
  String message = 'Lempar dadu untuk mulai!';
  String lastEvent = '';
  final rng = Random();

  late AnimationController _diceCtrl;
  late Animation<double> _diceAnim;
  Timer? _aiTimer;

  @override
  void initState() {
    super.initState();
    _diceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _diceAnim = CurvedAnimation(parent: _diceCtrl, curve: Curves.elasticOut);
  }

  @override
  void dispose() {
    _diceCtrl.dispose();
    _aiTimer?.cancel();
    super.dispose();
  }

  void _rollDice() {
    if (rolling || gameOver || !playerTurn) return;
    setState(() { rolling = true; lastEvent = ''; });
    _diceCtrl.forward(from: 0);

    // Animate dice rolling
    Timer.periodic(const Duration(milliseconds: 80), (t) {
      if (t.tick >= 7) {
        t.cancel();
        final val = rng.nextInt(6) + 1;
        setState(() {
          diceVal = val;
          rolling = false;
        });
        _movePlayer(playerPos, val, true);
      } else {
        setState(() => diceVal = rng.nextInt(6) + 1);
      }
    });
  }

  void _movePlayer(int pos, int dice, bool isPlayer) {
    int newPos = pos + dice;
    String event = '';

    if (newPos >= 100) {
      setState(() {
        if (isPlayer) playerPos = 100;
        else aiPos = 100;
        gameOver = true;
        message = isPlayer ? '🎉 KAMU MENANG!' : '🤖 AI MENANG!';
      });
      return;
    }

    if (snakes.containsKey(newPos)) {
      event = isPlayer
          ? '🐍 Kena ular! Turun ke ${snakes[newPos]}'
          : '🐍 AI kena ular!';
      newPos = snakes[newPos]!;
    } else if (ladders.containsKey(newPos)) {
      event = isPlayer
          ? '🪜 Naik tangga ke ${ladders[newPos]}!'
          : '🪜 AI naik tangga!';
      newPos = ladders[newPos]!;
    }

    setState(() {
      if (isPlayer) {
        playerPos = newPos;
        message = 'Dadu: $dice. ${event.isNotEmpty ? event : 'Posisi kamu: $newPos'}';
        lastEvent = event;
        playerTurn = false;
      } else {
        aiPos = newPos;
        message = 'AI dapat $dice. ${event.isNotEmpty ? event : 'Posisi AI: $newPos'}';
        lastEvent = event;
        playerTurn = true;
      }
    });

    if (!isPlayer) return;
    // AI turn
    _aiTimer = Timer(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      final aiDice = rng.nextInt(6) + 1;
      setState(() { diceVal = aiDice; });
      _movePlayer(aiPos, aiDice, false);
    });
  }

  void _reset() {
    _aiTimer?.cancel();
    setState(() {
      playerPos = 0; aiPos = 0; diceVal = 0;
      playerTurn = true; rolling = false; gameOver = false;
      message = 'Lempar dadu untuk mulai!'; lastEvent = '';
    });
  }

  // Convert position (1-100) to grid row/col
  Offset _posToOffset(int pos, double cellSize) {
    if (pos == 0) return Offset(-100, -100); // off screen
    final idx = pos - 1;
    final row = idx ~/ 10;
    final col = idx % 10;
    // Zigzag: even rows left-to-right, odd rows right-to-left
    final gridRow = 9 - row;
    final gridCol = row.isEven ? col : 9 - col;
    return Offset(gridCol * cellSize + cellSize / 2, gridRow * cellSize + cellSize / 2);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🎲 Ular Tangga', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _reset),
        ],
      ),
      body: Column(children: [
        // Message
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
          color: Color(0xFF131929),
          child: Column(children: [
            Text(message, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
            if (lastEvent.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(lastEvent, textAlign: TextAlign.center,
                  style: const TextStyle(color: const Color(0xFFFFAB00), fontSize: 12)),
            ],
          ]),
        ),
        // Score row
        Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
          color: Color(0xFF0C0F1E),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _scoreChip('👤 Kamu', playerPos, Color(0xFF00E676)),
            // Dice
            ScaleTransition(
              scale: _diceAnim,
              child: Container(
                width: 50, height: 50,
                decoration: BoxDecoration(
                  color: rolling ? const Color(0xFF1E88E5) : const Color(0xFF1565C0),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: const Color(0xFF1E88E5).withOpacity(0.5), blurRadius: 12)],
                ),
                child: Center(
                  child: Text(
                    diceVal == 0 ? '🎲' : _diceEmoji(diceVal),
                    style: const TextStyle(fontSize: 26),
                  ),
                ),
              ),
            ),
            _scoreChip('🤖 AI', aiPos, Color(0xFFFF1744)),
          ]),
        ),
        // Board
        Expanded(
          child: LayoutBuilder(builder: (_, constraints) {
            final size = min(constraints.maxWidth, constraints.maxHeight) - 16;
            final cellSize = size / 10;
            return Center(
              child: Stack(children: [
                // Grid
                SizedBox(
                  width: size, height: size,
                  child: CustomPaint(painter: _BoardPainter(snakes, ladders, cellSize)),
                ),
                // Player token
                if (playerPos > 0)
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 400),
                    left: _posToOffset(playerPos, cellSize).dx - 12,
                    top: _posToOffset(playerPos, cellSize).dy - 12,
                    child: Container(
                      width: 24, height: 24,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF00E676),
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [BoxShadow(color: Color(0xFF00E676).withOpacity(0.8), blurRadius: 8)],
                      ),
                      child: const Center(child: Text('👤', style: TextStyle(fontSize: 12))),
                    ),
                  ),
                // AI token
                if (aiPos > 0)
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 400),
                    left: _posToOffset(aiPos, cellSize).dx - 8,
                    top: _posToOffset(aiPos, cellSize).dy - 8,
                    child: Container(
                      width: 24, height: 24,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFFF1744),
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [BoxShadow(color: Color(0xFFFF1744).withOpacity(0.8), blurRadius: 8)],
                      ),
                      child: const Center(child: Text('🤖', style: TextStyle(fontSize: 12))),
                    ),
                  ),
              ]),
            );
          }),
        ),
        // Roll button
        Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: playerTurn && !gameOver ? const Color(0xFF1E88E5) : Colors.grey.shade800,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 52),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 4,
            ),
            icon: const Icon(Icons.casino_rounded),
            label: Text(
              gameOver ? 'Main Lagi' : (playerTurn ? 'Lempar Dadu!' : 'Tunggu AI...'),
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
            onPressed: gameOver ? _reset : _rollDice,
          ),
        ),
      ]),
    );
  }

  Widget _scoreChip(String label, int pos, Color color) {
    return Column(children: [
      Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
      Text('Kotak $pos', style: const TextStyle(color: Colors.white70, fontSize: 11)),
    ]);
  }

  String _diceEmoji(int val) {
    const emojis = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
    return emojis[val];
  }
}

class _BoardPainter extends CustomPainter {
  final Map<int, int> snakes;
  final Map<int, int> ladders;
  final double cellSize;
  _BoardPainter(this.snakes, this.ladders, this.cellSize);

  Offset _posToCenter(int pos) {
    final idx = pos - 1;
    final row = idx ~/ 10;
    final col = idx % 10;
    final gridRow = 9 - row;
    final gridCol = row.isEven ? col : 9 - col;
    return Offset(gridCol * cellSize + cellSize / 2, gridRow * cellSize + cellSize / 2);
  }

  @override
  void paint(Canvas canvas, Size size) {
    // Draw cells
    for (int i = 1; i <= 100; i++) {
      final idx = i - 1;
      final row = idx ~/ 10;
      final col = idx % 10;
      final gridRow = 9 - row;
      final gridCol = row.isEven ? col : 9 - col;
      final rect = Rect.fromLTWH(gridCol * cellSize, gridRow * cellSize, cellSize, cellSize);

      final isSnakeHead = snakes.containsKey(i);
      final isLadderBottom = ladders.containsKey(i);
      Color cellColor;
      if (isSnakeHead) cellColor = const Color(0xFF2A1A1A);
      else if (isLadderBottom) cellColor = const Color(0xFF1A2A1A);
      else cellColor = (gridRow + gridCol) % 2 == 0
          ? Color(0xFF131929)
          : const Color(0xFF1A2354);

      canvas.drawRect(rect, Paint()..color = cellColor);
      canvas.drawRect(rect, Paint()..color = Color(0xFF1C2540)..style = PaintingStyle.stroke..strokeWidth = 0.5);

      // Number
      final tp = TextPainter(
        text: TextSpan(text: '$i', style: const TextStyle(color: Colors.white38, fontSize: 7)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(gridCol * cellSize + 2, gridRow * cellSize + 2));
    }

    // Draw snakes
    for (final e in snakes.entries) {
      final from = _posToCenter(e.key);
      final to = _posToCenter(e.value);
      canvas.drawLine(from, to, Paint()
        ..color = Color(0xFFFF1744).withOpacity(0.8)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round);
      canvas.drawCircle(from, 6, Paint()..color = Color(0xFFFF1744));
    }

    // Draw ladders
    for (final e in ladders.entries) {
      final from = _posToCenter(e.key);
      final to = _posToCenter(e.value);
      canvas.drawLine(from, to, Paint()
        ..color = Color(0xFF00E676).withOpacity(0.8)
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round);
      canvas.drawCircle(from, 6, Paint()..color = Color(0xFF00E676));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
