import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// UNO GAME — Full playable UNO vs AI
// ─────────────────────────────────────────────────────────────────────────────

enum UnoColor { red, green, blue, yellow, wild }
enum UnoType { number, skip, reverse, drawTwo, wild, wildDrawFour }

class UnoCard {
  final UnoColor color;
  final UnoType type;
  final int? number;
  UnoColor? chosenColor; // for wild cards

  UnoCard({required this.color, required this.type, this.number});

  String get label {
    if (type == UnoType.number) return '${number!}';
    if (type == UnoType.skip) return '⊘';
    if (type == UnoType.reverse) return '⇄';
    if (type == UnoType.drawTwo) return '+2';
    if (type == UnoType.wild) return '★';
    if (type == UnoType.wildDrawFour) return '+4';
    return '';
  }

  Color get displayColor {
    final c = chosenColor ?? color;
    switch (c) {
      case UnoColor.red: return Color(0xFFFF1744);
      case UnoColor.green: return Color(0xFF00E676);
      case UnoColor.blue: return const Color(0xFF3B82F6);
      case UnoColor.yellow: return Color(0xFFFFAB00);
      case UnoColor.wild: return const Color(0xFF8B5CF6);
    }
  }

  bool canPlayOn(UnoCard top) {
    final effectiveColor = top.chosenColor ?? top.color;
    if (color == UnoColor.wild) return true;
    if (color == effectiveColor) return true;
    if (type == top.type && type != UnoType.number) return true;
    if (type == UnoType.number && top.type == UnoType.number && number == top.number) return true;
    return false;
  }

  UnoCard copy() {
    final c = UnoCard(color: color, type: type, number: number);
    c.chosenColor = chosenColor;
    return c;
  }
}

List<UnoCard> _buildDeck() {
  final deck = <UnoCard>[];
  final colors = [UnoColor.red, UnoColor.green, UnoColor.blue, UnoColor.yellow];
  for (final col in colors) {
    deck.add(UnoCard(color: col, type: UnoType.number, number: 0));
    for (int i = 1; i <= 9; i++) {
      deck.add(UnoCard(color: col, type: UnoType.number, number: i));
      deck.add(UnoCard(color: col, type: UnoType.number, number: i));
    }
    for (int i = 0; i < 2; i++) {
      deck.add(UnoCard(color: col, type: UnoType.skip));
      deck.add(UnoCard(color: col, type: UnoType.reverse));
      deck.add(UnoCard(color: col, type: UnoType.drawTwo));
    }
  }
  for (int i = 0; i < 4; i++) {
    deck.add(UnoCard(color: UnoColor.wild, type: UnoType.wild));
    deck.add(UnoCard(color: UnoColor.wild, type: UnoType.wildDrawFour));
  }
  deck.shuffle(Random());
  return deck;
}

class UnoGamePage extends StatefulWidget {
  const UnoGamePage({super.key});
  @override
  State<UnoGamePage> createState() => _UnoGamePageState();
}

class _UnoGamePageState extends State<UnoGamePage>
    with TickerProviderStateMixin {
  late List<UnoCard> _deck;
  late List<UnoCard> _playerHand;
  late List<UnoCard> _aiHand;
  late List<UnoCard> _discardPile;

  bool _playerTurn = true;
  bool _gameOver = false;
  String _winner = '';
  String _message = '';
  bool _unoShout = false;
  int _selectedCard = -1;
  bool _aiThinking = false;

  late AnimationController _dealAnim;
  late AnimationController _cardAnim;

  @override
  void initState() {
    super.initState();
    _dealAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _cardAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _startGame();
  }

  @override
  void dispose() {
    _dealAnim.dispose();
    _cardAnim.dispose();
    super.dispose();
  }

  void _startGame() {
    _deck = _buildDeck();
    _playerHand = [];
    _aiHand = [];
    _discardPile = [];
    for (int i = 0; i < 7; i++) {
      _playerHand.add(_deck.removeLast());
      _aiHand.add(_deck.removeLast());
    }
    // First card must not be wild
    UnoCard first;
    do {
      first = _deck.removeLast();
    } while (first.color == UnoColor.wild);
    _discardPile.add(first);
    _playerTurn = true;
    _gameOver = false;
    _winner = '';
    _message = 'Giliran kamu! Kartu: ${first.label}';
    _unoShout = false;
    _selectedCard = -1;
    _aiThinking = false;
    setState(() {});
  }

  UnoCard get _topCard => _discardPile.last;

  void _drawCard() {
    if (!_playerTurn || _gameOver || _aiThinking) return;
    if (_deck.isEmpty) {
      _deck = _discardPile.sublist(0, _discardPile.length - 1);
      _deck.shuffle(Random());
      _discardPile.removeRange(0, _discardPile.length - 1);
    }
    if (_deck.isNotEmpty) {
      setState(() {
        _playerHand.add(_deck.removeLast());
        _message = 'Kamu ambil kartu. Giliran AI...';
        _selectedCard = -1;
      });
      Future.delayed(const Duration(milliseconds: 800), _aiTurn);
      _playerTurn = false;
    }
  }

  void _playCard(int idx) {
    if (!_playerTurn || _gameOver || _aiThinking) return;
    final card = _playerHand[idx];
    if (!card.canPlayOn(_topCard)) {
      setState(() => _message = '❌ Kartu tidak valid!');
      return;
    }

    if (card.color == UnoColor.wild) {
      _showColorPicker(card, idx);
      return;
    }

    setState(() {
      _playerHand.removeAt(idx);
      _discardPile.add(card);
      _selectedCard = -1;
    });

    _applyCardEffect(card, isPlayer: true);
  }

  void _showColorPicker(UnoCard card, int idx) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Text('Pilih Warna', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _colorBtn(UnoColor.red, card, idx),
            _colorBtn(UnoColor.green, card, idx),
            _colorBtn(UnoColor.blue, card, idx),
            _colorBtn(UnoColor.yellow, card, idx),
          ],
        ),
      ),
    );
  }

  Widget _colorBtn(UnoColor color, UnoCard card, int idx) {
    final colors = {
      UnoColor.red: Color(0xFFFF1744),
      UnoColor.green: Color(0xFF00E676),
      UnoColor.blue: const Color(0xFF3B82F6),
      UnoColor.yellow: Color(0xFFFFAB00),
    };
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        card.chosenColor = color;
        setState(() {
          _playerHand.removeAt(idx);
          _discardPile.add(card);
          _selectedCard = -1;
        });
        _applyCardEffect(card, isPlayer: true);
      },
      child: Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          color: colors[color],
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: colors[color]!.withOpacity(0.6), blurRadius: 12)],
        ),
      ),
    );
  }

  void _applyCardEffect(UnoCard card, {required bool isPlayer}) {
    bool skipNext = false;

    if (card.type == UnoType.skip) {
      skipNext = true;
      setState(() => _message = isPlayer ? '⊘ AI dilewati!' : '⊘ Kamu dilewati!');
    } else if (card.type == UnoType.drawTwo) {
      if (isPlayer) {
        for (int i = 0; i < 2; i++) {
          if (_deck.isNotEmpty) _aiHand.add(_deck.removeLast());
        }
        setState(() => _message = 'AI ambil 2 kartu!');
      } else {
        for (int i = 0; i < 2; i++) {
          if (_deck.isNotEmpty) _playerHand.add(_deck.removeLast());
        }
        setState(() => _message = 'Kamu ambil 2 kartu!');
        skipNext = true;
      }
    } else if (card.type == UnoType.wildDrawFour) {
      if (isPlayer) {
        for (int i = 0; i < 4; i++) {
          if (_deck.isNotEmpty) _aiHand.add(_deck.removeLast());
        }
        setState(() => _message = 'AI ambil 4 kartu! 🔥');
      } else {
        for (int i = 0; i < 4; i++) {
          if (_deck.isNotEmpty) _playerHand.add(_deck.removeLast());
        }
        setState(() => _message = 'Kamu ambil 4 kartu! 😱');
        skipNext = true;
      }
    }

    // Check win
    if (isPlayer && _playerHand.isEmpty) {
      setState(() { _gameOver = true; _winner = 'player'; });
      return;
    }
    if (!isPlayer && _aiHand.isEmpty) {
      setState(() { _gameOver = true; _winner = 'ai'; });
      return;
    }

    // UNO shout check
    if (isPlayer && _playerHand.length == 1) {
      setState(() { _unoShout = true; _message = '🎉 UNO! Satu kartu tersisa!'; });
    }

    if (isPlayer) {
      if (skipNext) {
        setState(() => _message += '\nGiliran kamu lagi!');
      } else {
        _playerTurn = false;
        Future.delayed(const Duration(milliseconds: 900), _aiTurn);
      }
    } else {
      if (!skipNext) {
        setState(() { _playerTurn = true; _message = 'Giliran kamu!'; });
      } else {
        Future.delayed(const Duration(milliseconds: 600), _aiTurn);
      }
    }
  }

  void _aiTurn() {
    if (!mounted || _gameOver) return;
    setState(() { _aiThinking = true; _message = '🤖 AI sedang berpikir...'; });

    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      // Find playable card
      int playIdx = -1;
      // Prefer action cards
      for (int i = 0; i < _aiHand.length; i++) {
        if (_aiHand[i].canPlayOn(_topCard) && _aiHand[i].type != UnoType.number) {
          playIdx = i;
          break;
        }
      }
      if (playIdx == -1) {
        for (int i = 0; i < _aiHand.length; i++) {
          if (_aiHand[i].canPlayOn(_topCard)) { playIdx = i; break; }
        }
      }

      setState(() { _aiThinking = false; });

      if (playIdx == -1) {
        // Draw
        if (_deck.isNotEmpty) {
          _aiHand.add(_deck.removeLast());
          setState(() => _message = 'AI ambil kartu.');
        }
        setState(() { _playerTurn = true; _message = 'Giliran kamu!'; });
      } else {
        final card = _aiHand[playIdx];
        if (card.color == UnoColor.wild) {
          // Pick most common color
          final freq = <UnoColor, int>{};
          for (final c in _aiHand) {
            if (c.color != UnoColor.wild) freq[c.color] = (freq[c.color] ?? 0) + 1;
          }
          final best = freq.isEmpty ? UnoColor.red :
              freq.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
          card.chosenColor = best;
        }
        setState(() {
          _aiHand.removeAt(playIdx);
          _discardPile.add(card);
          _message = 'AI main: ${card.label}';
        });
        _applyCardEffect(card, isPlayer: false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        backgroundColor: const Color(0xFF161B22),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('🃏 UNO', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22)),
        actions: [
          TextButton(
            onPressed: () => setState(_startGame),
            child: const Text('New Game', style: TextStyle(color: Color(0xFF58A6FF), fontWeight: FontWeight.w700)),
          ),
        ],
      ),
      body: _gameOver ? _buildGameOver() : _buildGame(),
    );
  }

  Widget _buildGame() {
    return Column(children: [
      // AI hand
      Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: _playerTurn ? const Color(0xFF161B22) : const Color(0xFF1F2937).withOpacity(0.8),
          border: Border(bottom: BorderSide(
            color: _playerTurn ? Colors.transparent : Color(0xFFFFAB00),
            width: 2,
          )),
        ),
        child: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF8B5CF6).withOpacity(0.2),
              border: Border.all(color: const Color(0xFF8B5CF6), width: 2),
            ),
            child: const Center(child: Text('🤖', style: TextStyle(fontSize: 18))),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: SizedBox(
              height: 70,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _aiHand.length,
                itemBuilder: (_, i) => Container(
                  width: 44, height: 62,
                  margin: const EdgeInsets.only(right: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1E3A5F), Color(0xFF0D2137)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: const Color(0xFF30363D), width: 1),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4, offset: const Offset(1, 2))],
                  ),
                  child: const Center(
                    child: Text('🔒', style: TextStyle(fontSize: 20)),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF8B5CF6).withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.4)),
            ),
            child: Text('${_aiHand.length} kartu',
              style: const TextStyle(color: Color(0xFF8B5CF6), fontWeight: FontWeight.w700, fontSize: 12)),
          ),
        ]),
      ),
      // Message
      AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        color: const Color(0xFF0D1117),
        child: Row(children: [
          Expanded(
            child: Text(_message,
              style: const TextStyle(color: Colors.white70, fontSize: 13),
              maxLines: 2,
            ),
          ),
          if (_aiThinking)
            const SizedBox(width: 20, height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF8B5CF6))),
        ]),
      ),
      // Play area
      Expanded(
        child: Center(
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            // Deck
            GestureDetector(
              onTap: _playerTurn ? _drawCard : null,
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  width: 72, height: 104,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1E3A8A), Color(0xFF1E40AF)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: const Color(0xFF3B82F6), width: 2),
                    boxShadow: [BoxShadow(color: const Color(0xFF3B82F6).withOpacity(0.4), blurRadius: 16)],
                  ),
                  child: const Center(child: Text('UNO', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))),
                ),
                const SizedBox(height: 6),
                Text('${_deck.length}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                const Text('Ambil', style: TextStyle(color: Color(0xFF3B82F6), fontSize: 11, fontWeight: FontWeight.w600)),
              ]),
            ),
            const SizedBox(width: 30),
            // Discard pile
            Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _buildUnoCard(_topCard, size: 1.2, selectable: false, selected: false),
              const SizedBox(height: 6),
              const Text('Kartu Atas', style: TextStyle(color: Colors.white54, fontSize: 11)),
            ]),
          ]),
        ),
      ),
      // Player hand
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _playerTurn ? const Color(0xFF161B22) : const Color(0xFF0D1117),
          border: Border(top: BorderSide(
            color: _playerTurn ? Color(0xFF00E676) : Colors.transparent,
            width: 2,
          )),
        ),
        child: Column(children: [
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF00E676).withOpacity(0.2),
                border: Border.all(color: Color(0xFF00E676), width: 2),
              ),
              child: const Center(child: Text('😎', style: TextStyle(fontSize: 18))),
            ),
            const SizedBox(width: 8),
            const Text('Kartumu', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 13)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Color(0xFF00E676).withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Color(0xFF00E676).withOpacity(0.4)),
              ),
              child: Text('${_playerHand.length} kartu',
                style: const TextStyle(color: const Color(0xFF00E676), fontWeight: FontWeight.w700, fontSize: 12)),
            ),
          ]),
          const SizedBox(height: 10),
          SizedBox(
            height: 110,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _playerHand.length,
              itemBuilder: (_, i) {
                final playable = _playerTurn && _playerHand[i].canPlayOn(_topCard);
                return GestureDetector(
                  onTap: () {
                    if (_selectedCard == i) {
                      _playCard(i);
                    } else {
                      setState(() => _selectedCard = i);
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    transform: Matrix4.translationValues(0, _selectedCard == i ? -16 : 0, 0),
                    child: Opacity(
                      opacity: _playerTurn ? 1.0 : 0.5,
                      child: _buildUnoCard(_playerHand[i],
                        size: 1.0, selectable: playable, selected: _selectedCard == i),
                    ),
                  ),
                );
              },
            ),
          ),
          if (_selectedCard >= 0 && _selectedCard < _playerHand.length)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('Tap lagi untuk mainkan kartu',
                style: const TextStyle(color: const Color(0xFFFFAB00), fontSize: 12, fontWeight: FontWeight.w600)),
            ),
        ]),
      ),
    ]);
  }

  Widget _buildUnoCard(UnoCard card, {double size = 1.0, bool selectable = true, bool selected = false}) {
    final w = 60.0 * size;
    final h = 88.0 * size;
    return Container(
      width: w, height: h,
      margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10 * size),
        color: card.displayColor,
        border: Border.all(
          color: selected ? Colors.white : (selectable ? Colors.white.withOpacity(0.5) : Colors.transparent),
          width: selected ? 3 : 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: card.displayColor.withOpacity(selected ? 0.8 : 0.3),
            blurRadius: selected ? 20 : 8,
            spreadRadius: selected ? 2 : 0,
          ),
        ],
      ),
      child: Stack(children: [
        // Oval center
        Center(
          child: Container(
            width: w * 0.65,
            height: h * 0.75,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(999),
            ),
          ),
        ),
        Center(
          child: Text(card.label,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: card.type == UnoType.number ? 22 * size : 18 * size,
              shadows: [Shadow(color: Colors.black38, blurRadius: 4)],
            ),
          ),
        ),
        // Corner labels
        Positioned(
          top: 4, left: 5,
          child: Text(card.label, style: TextStyle(color: Colors.white, fontSize: 9 * size, fontWeight: FontWeight.w900)),
        ),
        Positioned(
          bottom: 4, right: 5,
          child: RotatedBox(quarterTurns: 2,
            child: Text(card.label, style: TextStyle(color: Colors.white, fontSize: 9 * size, fontWeight: FontWeight.w900))),
        ),
      ]),
    );
  }

  Widget _buildGameOver() {
    final playerWon = _winner == 'player';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(playerWon ? '🏆' : '😢', style: const TextStyle(fontSize: 80)),
          const SizedBox(height: 16),
          Text(playerWon ? 'KAMU MENANG!' : 'AI MENANG!',
            style: TextStyle(
              color: playerWon ? Color(0xFF00E676) : Color(0xFFFF1744),
              fontSize: 32, fontWeight: FontWeight.w900,
            )),
          const SizedBox(height: 12),
          Text(playerWon ? 'Selamat! Kamu menghabiskan semua kartu!' : 'AI menghabiskan semua kartu duluan!',
            style: const TextStyle(color: Colors.white60, fontSize: 14),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 40),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B82F6),
              foregroundColor: Colors.white,
              minimumSize: const Size(220, 54),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Main Lagi', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            onPressed: () => setState(_startGame),
          ),
        ]),
      ),
    );
  }
}
