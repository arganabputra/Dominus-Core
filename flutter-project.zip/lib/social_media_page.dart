// ============================================================
// FILE: social_media_page.dart
// VERSION: XOWV1 EDITION 🔥
// DEWA: XENOW + XOWV1 😈
// STATUS: FULLY FIXED + OPTIMIZED!
// ============================================================

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── API CONFIG ──────────────────────────────────────────────────────
const String API_BASE_URL = 'http://manis.banditflow.my.id:2172/api'; // GANTI DENGAN API LU!

class SocialMediaPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const SocialMediaPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<SocialMediaPage> createState() => _SocialMediaPageState();
}

// ─── MODEL DATA ──────────────────────────────────────────────────────

class ApiUser {
  String id;
  String name;
  String username;
  String? profilePic;
  List<String> followers;
  List<String> following;

  ApiUser({
    required this.id,
    required this.name,
    required this.username,
    this.profilePic,
    this.followers = const [],
    this.following = const [],
  });

  factory ApiUser.fromJson(Map<String, dynamic> json) => ApiUser(
    id: json['id']?.toString() ?? '',
    name: json['name']?.toString() ?? '',
    username: json['username']?.toString() ?? '',
    profilePic: json['profilePic']?.toString(),
    followers: List<String>.from(json['followers'] ?? []),
    following: List<String>.from(json['following'] ?? []),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'username': username,
    'profilePic': profilePic,
    'followers': followers,
    'following': following,
  };
}

class ApiPost {
  String id;
  String userId;
  String username;
  String? caption;
  String? videoUrl;
  String? thumbnail;
  DateTime createdAt;
  int likes;
  List<Map<String, dynamic>> comments;

  ApiPost({
    required this.id,
    required this.userId,
    required this.username,
    this.caption,
    this.videoUrl,
    this.thumbnail,
    required this.createdAt,
    this.likes = 0,
    this.comments = const [],
  });

  factory ApiPost.fromJson(Map<String, dynamic> json) => ApiPost(
    id: json['id']?.toString() ?? '',
    userId: json['userId']?.toString() ?? '',
    username: json['username']?.toString() ?? '',
    caption: json['caption']?.toString(),
    videoUrl: json['videoUrl']?.toString(),
    thumbnail: json['thumbnail']?.toString(),
    createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
    likes: json['likes'] ?? 0,
    comments: List<Map<String, dynamic>>.from(json['comments'] ?? []),
  );
}

// ─── SOCIAL MEDIA PAGE STATE ────────────────────────────────────────

class _SocialMediaPageState extends State<SocialMediaPage>
    with SingleTickerProviderStateMixin {
  
  // ─── VARIABLE ──────────────────────────────────────────────────────
  List<ApiPost> _posts = [];
  List<ApiUser> _users = [];
  List<ApiUser> _searchResults = [];
  String? _selectedVideoPath;
  String _postCaption = '';
  bool _isUploading = false;
  bool _isLoading = true;
  bool _isRefreshing = false;
  int _currentTab = 0;
  String _searchQuery = '';
  TextEditingController _commentController = TextEditingController();
  String? _commentingPostId;
  File? _profileImage;
  late TabController _tabController;
  
  // ─── STATE MANAGEMENT ─────────────────────────────────────────────
  Map<String, bool> _followState = {};
  Map<String, bool> _likeState = {};
  Map<String, VideoPlayerController> _videoControllers = {};
  Map<String, bool> _videoInitialized = {};

  // ─── INIT ──────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() => _currentTab = _tabController.index);
    });
    _loadProfileImage();
    _fetchAllData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _commentController.dispose();
    for (var controller in _videoControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  // ─── HEADERS ───────────────────────────────────────────────────────
  Map<String, String> _getHeaders() {
    return {
      'Authorization': 'Bearer ${widget.sessionKey}',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  // ─── SNACKBAR HELPER ──────────────────────────────────────────────
  void _showSnackbar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: isError ? Colors.red.shade900 : Colors.black.withOpacity(0.9),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isError ? Colors.red : const Color(0xFFFF0800),
            width: 1,
          ),
        ),
      ),
    );
  }

  // ─── LOAD PROFILE IMAGE ───────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_${widget.username}');
    if (path != null && path.isNotEmpty && File(path).existsSync()) {
      setState(() => _profileImage = File(path));
    }
  }

  // ─── FETCH ALL DATA ──────────────────────────────────────────────
  Future<void> _fetchAllData() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    await Future.wait([
      _fetchPosts(),
      _fetchUsers(),
    ]);
    if (mounted) setState(() => _isLoading = false);
  }

  // ─── FETCH POSTS FROM API ─────────────────────────────────────────
  Future<void> _fetchPosts() async {
    try {
      final response = await http.get(
        Uri.parse('$API_BASE_URL/posts'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            _posts = data.map((e) => ApiPost.fromJson(e)).toList();
            _initVideoControllers();
          });
        } else if (data is Map && data['data'] is List) {
          setState(() {
            _posts = (data['data'] as List).map((e) => ApiPost.fromJson(e)).toList();
            _initVideoControllers();
          });
        }
      } else {
        _fetchPostsFromLocal();
      }
    } catch (e) {
      _fetchPostsFromLocal();
    }
  }

  // ─── FETCH USERS FROM API ─────────────────────────────────────────
  Future<void> _fetchUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$API_BASE_URL/users'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            _users = data.map((e) => ApiUser.fromJson(e)).toList();
            _searchResults = _users;
            _initFollowState();
          });
        } else if (data is Map && data['data'] is List) {
          setState(() {
            _users = (data['data'] as List).map((e) => ApiUser.fromJson(e)).toList();
            _searchResults = _users;
            _initFollowState();
          });
        }
      } else {
        _fetchUsersFromLocal();
      }
    } catch (e) {
      _fetchUsersFromLocal();
    }
  }

  // ─── FETCH USER POSTS ─────────────────────────────────────────────
  Future<void> _fetchUserPosts(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$API_BASE_URL/posts/user/$userId'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            _posts = data.map((e) => ApiPost.fromJson(e)).toList();
            _initVideoControllers();
          });
        } else if (data is Map && data['data'] is List) {
          setState(() {
            _posts = (data['data'] as List).map((e) => ApiPost.fromJson(e)).toList();
            _initVideoControllers();
          });
        }
      }
    } catch (e) {
      // SKIP
    }
  }

  // ─── INIT VIDEO CONTROLLERS ───────────────────────────────────────
  void _initVideoControllers() {
    for (var post in _posts) {
      if (post.videoUrl != null && 
          post.videoUrl!.isNotEmpty && 
          !_videoControllers.containsKey(post.id)) {
        _initializeVideo(post.id, post.videoUrl!);
      }
    }
  }

  Future<void> _initializeVideo(String postId, String url) async {
    try {
      final controller = VideoPlayerController.networkUrl(
        Uri.parse(url),
        httpHeaders: {
          'Cache-Control': 'max-age=86400',
          'Accept-Ranges': 'bytes',
        },
      );
      
      await controller.initialize();
      controller.setVolume(0.0);
      controller.setLooping(true);
      
      if (mounted) {
        setState(() {
          _videoControllers[postId] = controller;
          _videoInitialized[postId] = true;
        });
      }
    } catch (e) {
      debugPrint('VIDEO INIT ERROR: $e');
      if (mounted) {
        setState(() {
          _videoInitialized[postId] = false;
        });
      }
    }
  }

  // ─── INIT FOLLOW STATE ────────────────────────────────────────────
  void _initFollowState() {
    for (var user in _users) {
      if (user.id != widget.username) {
        final isFollowing = user.followers.contains(widget.username);
        _followState[user.id] = isFollowing;
      }
    }
  }

  // ─── LOCAL FALLBACK ───────────────────────────────────────────────
  void _fetchPostsFromLocal() {
    setState(() {
      _posts = _getDummyPosts();
      _initVideoControllers();
    });
  }

  void _fetchUsersFromLocal() {
    setState(() {
      _users = _getDummyUsers();
      _searchResults = _users;
      _initFollowState();
    });
  }

  // ─── FOLLOW/UNFOLLOW ──────────────────────────────────────────────
  Future<void> _toggleFollow(String targetId) async {
    if (targetId == widget.username) {
      _showSnackbar('GA BISA FOLLOW DIRI SENDIRI GOBLOK! 😈');
      return;
    }

    setState(() {
      _followState[targetId] = !(_followState[targetId] ?? false);
    });

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/follow'),
        headers: _getHeaders(),
        body: jsonEncode({
          'userId': widget.username,
          'targetId': targetId,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201) {
        await _fetchUsers();
        await _fetchPosts();
        _showSnackbar('BERHASIL FOLLOW! 🔥😈');
      } else {
        _toggleFollowLocal(targetId);
      }
    } catch (e) {
      _toggleFollowLocal(targetId);
    }
  }

  void _toggleFollowLocal(String targetId) {
    setState(() {
      final currentUserIndex = _users.indexWhere((u) => u.id == widget.username);
      final targetIndex = _users.indexWhere((u) => u.id == targetId);
      
      if (currentUserIndex != -1 && targetIndex != -1) {
        final current = _users[currentUserIndex];
        final target = _users[targetIndex];
        
        if (current.following.contains(targetId)) {
          current.following.remove(targetId);
          target.followers.remove(widget.username);
        } else {
          current.following.add(targetId);
          target.followers.add(widget.username);
        }
        _users[currentUserIndex] = current;
        _users[targetIndex] = target;
        _searchResults = _users;
      }
    });
  }

  // ─── LIKE/UNLIKE ──────────────────────────────────────────────────
  Future<void> _toggleLike(String postId) async {
    setState(() {
      _likeState[postId] = !(_likeState[postId] ?? false);
      final index = _posts.indexWhere((p) => p.id == postId);
      if (index != -1) {
        final post = _posts[index];
        if (_likeState[postId] ?? false) {
          post.likes++;
        } else {
          post.likes--;
        }
        _posts[index] = post;
      }
    });

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/like'),
        headers: _getHeaders(),
        body: jsonEncode({
          'postId': postId,
          'userId': widget.username,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200 && response.statusCode != 201) {
        _toggleLikeLocal(postId);
      }
    } catch (e) {
      _toggleLikeLocal(postId);
    }
  }

  void _toggleLikeLocal(String postId) {
    setState(() {
      final index = _posts.indexWhere((p) => p.id == postId);
      if (index != -1) {
        final post = _posts[index];
        final isLiked = _likeState[postId] ?? false;
        if (isLiked) {
          post.likes--;
        } else {
          post.likes++;
        }
        _posts[index] = post;
      }
    });
  }

  // ─── ADD COMMENT ──────────────────────────────────────────────────
  Future<void> _addComment(String postId, String comment) async {
    if (comment.trim().isEmpty) {
      _showSnackbar('KOMENTAR KOSONG GOBLOK! 🤪');
      return;
    }

    final tempComment = {
      'userId': widget.username,
      'username': widget.username,
      'text': comment,
      'createdAt': DateTime.now().toIso8601String(),
    };

    setState(() {
      final index = _posts.indexWhere((p) => p.id == postId);
      if (index != -1) {
        _posts[index].comments.add(tempComment);
      }
    });

    try {
      final response = await http.post(
        Uri.parse('$API_BASE_URL/comment'),
        headers: _getHeaders(),
        body: jsonEncode({
          'postId': postId,
          'userId': widget.username,
          'text': comment,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201) {
        await _fetchPosts();
        _commentController.clear();
        setState(() => _commentingPostId = null);
        _showSnackbar('KOMENTAR BERHASIL! 😈');
      } else {
        _addCommentLocal(postId, comment);
      }
    } catch (e) {
      _addCommentLocal(postId, comment);
    }
  }

  void _addCommentLocal(String postId, String comment) {
    setState(() {
      final index = _posts.indexWhere((p) => p.id == postId);
      if (index != -1) {
        final post = _posts[index];
        post.comments.add({
          'userId': widget.username,
          'username': widget.username,
          'text': comment,
          'createdAt': DateTime.now().toIso8601String(),
        });
        _posts[index] = post;
      }
    });
    _commentController.clear();
    setState(() => _commentingPostId = null);
  }

  // ─── UPLOAD VIDEO ─────────────────────────────────────────────────
  Future<void> _uploadVideo() async {
    if (_selectedVideoPath == null) {
      _showSnackbar('AMBIL VIDEO DULU GOBLOK! 🫵😈');
      return;
    }

    setState(() => _isUploading = true);

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$API_BASE_URL/upload-video'),
      );

      request.headers['Authorization'] = 'Bearer ${widget.sessionKey}';
      request.fields['userId'] = widget.username;
      request.fields['caption'] = _postCaption;

      request.files.add(await http.MultipartFile.fromPath(
        'video',
        _selectedVideoPath!,
      ));

      final response = await request.send();

      if (response.statusCode == 200 || response.statusCode == 201) {
        setState(() {
          _selectedVideoPath = null;
          _postCaption = '';
          _isUploading = false;
        });
        await _fetchPosts();
        _showSnackbar('VIDEO UPLOAD BERHASIL! 🔥😈');
      } else {
        setState(() => _isUploading = false);
        _showSnackbar('UPLOAD GAGAL GOBLOK! ☠️', isError: true);
      }
    } catch (e) {
      setState(() => _isUploading = false);
      _showSnackbar('ERROR: $e 💀', isError: true);
    }
  }

  // ─── PICK VIDEO ───────────────────────────────────────────────────
  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (file != null) {
      setState(() => _selectedVideoPath = file.path);
    }
  }

  // ─── UPLOAD PROFILE PIC ───────────────────────────────────────────
  Future<void> _pickAndUploadImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      await _uploadProfilePic(file.path);
    }
  }

  Future<void> _uploadProfilePic(String path) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$API_BASE_URL/upload-pp'),
      );

      request.headers['Authorization'] = 'Bearer ${widget.sessionKey}';
      request.fields['userId'] = widget.username;

      request.files.add(await http.MultipartFile.fromPath(
        'profilePic',
        path,
      ));

      final response = await request.send();

      if (response.statusCode == 200 || response.statusCode == 201) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', path);
        setState(() => _profileImage = File(path));
        await _fetchUsers();
        _showSnackbar('PP BERUBAH! GANTENG BANGET! 😈');
      }
    } catch (e) {
      // SKIP
    }
  }

  // ─── SEARCH USERS ──────────────────────────────────────────────────
  void _searchUsers(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _searchResults = _users;
      } else {
        _searchResults = _users.where((user) {
          final username = user.username.toLowerCase();
          final name = user.name.toLowerCase();
          final q = query.toLowerCase();
          return username.contains(q) || name.contains(q);
        }).toList();
      }
    });
  }

  // ─── CHECK FOLLOWING ──────────────────────────────────────────────
  bool _isFollowing(String userId) {
    return _followState[userId] ?? false;
  }

  // ─── GET CURRENT USER ─────────────────────────────────────────────
  ApiUser? _getCurrentUser() {
    try {
      return _users.firstWhere((u) => u.id == widget.username);
    } catch (_) {
      return null;
    }
  }

  // ─── FORMAT TIME ──────────────────────────────────────────────────
  String _formatTime(String? isoString) {
    if (isoString == null || isoString.isEmpty) return 'Baru saja';
    try {
      final date = DateTime.parse(isoString);
      final diff = DateTime.now().difference(date);
      if (diff.inDays > 7) return '${diff.inDays} hari lalu';
      if (diff.inDays > 0) return '${diff.inDays} hari lalu';
      if (diff.inHours > 0) return '${diff.inHours} jam lalu';
      if (diff.inMinutes > 0) return '${diff.inMinutes} menit lalu';
      return 'Baru saja';
    } catch (_) {
      return 'Baru saja';
    }
  }

  // ─── DUMMY DATA (FALLBACK) ────────────────────────────────────────
  List<ApiPost> _getDummyPosts() {
    return [
      ApiPost(
        id: 'p1',
        userId: 'u1',
        username: '@zamzzz_dewa',
        caption: 'EMPIK ENAK BANGET GOBLOK! 😈🔥',
        videoUrl: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
        createdAt: DateTime.now().subtract(const Duration(hours: 1)),
        likes: 5,
        comments: [
          {'userId': 'u2', 'username': '@goblock_keren', 'text': 'EMPING!', 'createdAt': DateTime.now().subtract(const Duration(minutes: 30)).toIso8601String()},
          {'userId': 'u3', 'username': '@empik_mania', 'text': 'GUA MAU!', 'createdAt': DateTime.now().subtract(const Duration(minutes: 15)).toIso8601String()},
        ],
      ),
      ApiPost(
        id: 'p2',
        userId: 'u2',
        username: '@goblock_keren',
        caption: 'SIAPA YANG MAU FOLLOW? 🫵😈',
        videoUrl: '',
        createdAt: DateTime.now().subtract(const Duration(hours: 3)),
        likes: 2,
        comments: [
          {'userId': 'u1', 'username': '@zamzzz_dewa', 'text': 'GUA!', 'createdAt': DateTime.now().subtract(const Duration(hours: 2)).toIso8601String()},
        ],
      ),
    ];
  }

  List<ApiUser> _getDummyUsers() {
    return [
      ApiUser(id: 'u1', name: 'ZAMZZZ DEWA', username: '@zamzzz_dewa', followers: ['u2', 'u3'], following: ['u2']),
      ApiUser(id: 'u2', name: 'SI GOBLOK KEREN', username: '@goblock_keren', followers: ['u1'], following: ['u3']),
      ApiUser(id: 'u3', name: 'EMPIK MANIA', username: '@empik_mania', followers: [], following: ['u1', 'u2']),
    ];
  }

  // ─── VIDEO PLAYER WIDGET ──────────────────────────────────────────
  Widget _buildVideoPlayer(String url, String postId) {
    final controller = _videoControllers[postId];
    final isInitialized = _videoInitialized[postId] ?? false;

    if (controller == null || !isInitialized) {
      return Container(
        height: 250,
        color: Colors.black,
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                color: Color(0xFFFF0800),
                strokeWidth: 3,
              ),
              SizedBox(height: 12),
              Text(
                'MEMUAT VIDEO... 😈',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      height: 250,
      color: Colors.black,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AspectRatio(
            aspectRatio: controller.value.aspectRatio,
            child: VideoPlayer(controller),
          ),
          GestureDetector(
            onTap: () {
              if (controller.value.isPlaying) {
                controller.pause();
              } else {
                controller.play();
              }
              setState(() {});
            },
            child: Container(
              color: Colors.transparent,
              width: double.infinity,
              height: double.infinity,
              child: Center(
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    controller.value.isPlaying
                        ? Icons.pause_rounded
                        : Icons.play_arrow_rounded,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
              ),
            ),
          ),
          if (controller.value.isBuffering)
            const Center(
              child: SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              ),
            ),
          Positioned(
            bottom: 8,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                _formatDuration(controller.value.position),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    return duration.inHours > 0
        ? '$hours:$minutes:$seconds'
        : '$minutes:$seconds';
  }

  // ─── WIDGET: POST CARD ────────────────────────────────────────────
  Widget _buildPostCard(ApiPost post) {
    final isLiked = _likeState[post.id] ?? false;
    final isOwner = post.userId == widget.username;
    final isFollowing = _isFollowing(post.userId);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFFF0800),
        borderRadius: BorderRadius.circular(16),
        border: Border.fromBorderSide(
          const BorderSide(color: Color(0xFFFF0800), width: 0.5),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF0800).withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── HEADER ────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: const Color(0xFFFF0800).withOpacity(0.2),
                  child: Text(
                    post.username.isNotEmpty ? post.username.substring(1, 2).toUpperCase() : 'U',
                    style: const TextStyle(
                      color: Color(0xFFFF0800),
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        post.username,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        _formatTime(post.createdAt.toIso8601String()),
                        style: const TextStyle(color: Colors.white54, fontSize: 10),
                      ),
                    ],
                  ),
                ),
                if (!isOwner)
                  GestureDetector(
                    onTap: () => _toggleFollow(post.userId),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: isFollowing
                            ? null
                            : const LinearGradient(
                                colors: [Color(0xFFFF0800), Color(0xFFCC0000)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                        color: isFollowing ? Colors.white24 : null,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isFollowing ? Colors.white54 : Colors.transparent,
                          width: 0.5,
                        ),
                      ),
                      child: Text(
                        isFollowing ? 'Unfollow' : 'Follow',
                        style: TextStyle(
                          color: isFollowing ? Colors.white54 : Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // ─── VIDEO ─────────────────────────────────────────────
          if (post.videoUrl != null && post.videoUrl!.isNotEmpty)
            _buildVideoPlayer(post.videoUrl!, post.id),

          // ─── CAPTION ───────────────────────────────────────────
          if (post.caption != null && post.caption!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Text(
                post.caption!,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),

          // ─── ACTION BUTTONS ────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => _toggleLike(post.id),
                  child: Row(
                    children: [
                      Icon(
                        isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        color: isLiked ? Colors.red : Colors.white,
                        size: 24,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        post.likes.toString(),
                        style: TextStyle(
                          color: isLiked ? Colors.red : Colors.white54,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                GestureDetector(
                  onTap: () => _showCommentDialog(post.id, post.comments),
                  child: Row(
                    children: [
                      const Icon(Icons.comment_rounded, color: Colors.white, size: 22),
                      const SizedBox(width: 4),
                      Text(
                        post.comments.length.toString(),
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                const Icon(Icons.send_rounded, color: Colors.white, size: 22),
                const Spacer(),
                const Icon(Icons.bookmark_border_rounded, color: Colors.white, size: 22),
              ],
            ),
          ),

          // ─── COMMENTS PREVIEW ──────────────────────────────────
          if (post.comments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: GestureDetector(
                onTap: () => _showCommentDialog(post.id, post.comments),
                child: Text(
                  'Lihat ${post.comments.length} komentar',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ),
            ),

          // ─── COMMENT INPUT ─────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentingPostId == post.id ? _commentController : TextEditingController(),
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    decoration: InputDecoration(
                      hintText: 'Tulis komentar...',
                      hintStyle: TextStyle(color: Colors.white54, fontSize: 12),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.05),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      suffixIcon: _commentingPostId == post.id && _commentController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.send_rounded, color: Color(0xFFFF0800), size: 18),
                              onPressed: () {
                                _addComment(post.id, _commentController.text);
                              },
                            )
                          : null,
                    ),
                    onChanged: (value) {
                      if (_commentingPostId != post.id) {
                        setState(() => _commentingPostId = post.id);
                      }
                      setState(() {});
                    },
                    onSubmitted: (value) {
                      if (_commentingPostId != post.id) {
                        setState(() => _commentingPostId = post.id);
                      }
                      _addComment(post.id, value);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    final ctrl = _commentingPostId == post.id
                        ? _commentController
                        : TextEditingController();
                    if (ctrl.text.isNotEmpty) {
                      _addComment(post.id, ctrl.text);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF0800), Color(0xFFCC0000)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── COMMENT DIALOG ───────────────────────────────────────────────
  void _showCommentDialog(String postId, List<Map<String, dynamic>> comments) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xEC0A0F1D),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.7,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Komentar',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.white54),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const Divider(color: Colors.white24),
              Expanded(
                child: comments.isEmpty
                    ? const Center(
                        child: Text('Belum ada komentar', style: TextStyle(color: Colors.white54)),
                      )
                    : ListView.builder(
                        itemCount: comments.length,
                        itemBuilder: (context, index) {
                          final comment = comments[index];
                          final username = comment['username']?.toString() ?? 'Unknown';
                          final text = comment['text']?.toString() ?? '';
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: '$username ',
                                    style: const TextStyle(
                                      color: Color(0xFFFF0800),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                  TextSpan(
                                    text: text,
                                    style: const TextStyle(color: Colors.white, fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              const Divider(color: Colors.white24),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: ctrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Tulis komentar...',
                        hintStyle: TextStyle(color: Colors.white54),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.05),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      if (ctrl.text.isNotEmpty) {
                        _addComment(postId, ctrl.text);
                        Navigator.pop(context);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF0800), Color(0xFFCC0000)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0F1D),
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.8),
        elevation: 0,
        title: const Text(
          'SOSIAL MEDIA 😈',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFFF0800),
          labelColor: const Color(0xFFFF0800),
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(icon: Icon(Icons.home_rounded), text: 'Feed'),
            Tab(icon: Icon(Icons.search_rounded), text: 'Cari'),
            Tab(icon: Icon(Icons.add_circle_rounded), text: 'Upload'),
            Tab(icon: Icon(Icons.person_rounded), text: 'Profil'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF0800)),
            )
          : TabBarView(
              controller: _tabController,
              children: [
                _buildFeedTab(),
                _buildSearchTab(),
                _buildUploadTab(),
                _buildProfileTab(),
              ],
            ),
    );
  }

  // ─── FEED TAB ──────────────────────────────────────────────────────
  Widget _buildFeedTab() {
    if (_posts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.video_library_rounded, color: Colors.white24, size: 60),
            const SizedBox(height: 12),
            const Text('BELUM ADA POSTINGAN!', style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 8),
            Text('Upload video pertama lu!', style: TextStyle(color: Colors.white24, fontSize: 12)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchAllData,
      color: const Color(0xFFFF0800),
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        physics: const BouncingScrollPhysics(),
        itemCount: _posts.length,
        itemBuilder: (context, index) {
          final post = _posts[index];
          return _buildPostCard(post);
        },
      ),
    );
  }

  // ─── SEARCH TAB ────────────────────────────────────────────────────
  Widget _buildSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Cari user...',
              hintStyle: TextStyle(color: Colors.white54),
              prefixIcon: const Icon(Icons.search_rounded, color: Colors.white54),
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            onChanged: _searchUsers,
          ),
        ),
        Expanded(
          child: _searchResults.isEmpty
              ? const Center(
                  child: Text('Tidak ada user ditemukan', style: TextStyle(color: Colors.white54)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    final user = _searchResults[index];
                    final isFollowing = _isFollowing(user.id);
                    final isOwner = user.id == widget.username;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF0800),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.fromBorderSide(BorderSide(color: const Color(0xFFFF0800))),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 20,
                            backgroundColor: const Color(0xFFFF0800).withOpacity(0.2),
                            child: Text(
                              user.username.isNotEmpty ? user.username.substring(1, 2).toUpperCase() : 'U',
                              style: const TextStyle(color: Color(0xFFFF0800), fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  user.username,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  user.name,
                                  style: TextStyle(color: Colors.white54, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          if (!isOwner)
                            GestureDetector(
                              onTap: () => _toggleFollow(user.id),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  gradient: isFollowing
                                      ? null
                                      : const LinearGradient(
                                          colors: [Color(0xFFFF0800), Color(0xFFCC0000)],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                  color: isFollowing ? Colors.white24 : null,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: isFollowing ? Colors.white54 : Colors.transparent,
                                    width: 0.5,
                                  ),
                                ),
                                child: Text(
                                  isFollowing ? 'Unfollow' : 'Follow',
                                  style: TextStyle(
                                    color: isFollowing ? Colors.white54 : Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  // ─── UPLOAD TAB ────────────────────────────────────────────────────
  Widget _buildUploadTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // VIDEO PREVIEW
          GestureDetector(
            onTap: _pickVideo,
            child: Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFFF0800),
                borderRadius: BorderRadius.circular(16),
                border: Border.fromBorderSide(BorderSide(color: const Color(0xFFFF0800))),
              ),
              child: _selectedVideoPath != null
                  ? Stack(
                      fit: StackFit.expand,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.file(
                            File(_selectedVideoPath!),
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.transparent, Colors.black.withOpacity(0.5)],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.play_circle_filled,
                              color: Colors.white,
                              size: 50,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 8,
                          right: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              'TAP GANTI',
                              style: TextStyle(color: Colors.white54, fontSize: 10),
                            ),
                          ),
                        ),
                      ],
                    )
                  : const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.video_library_rounded, color: Colors.white24, size: 50),
                          SizedBox(height: 8),
                          Text(
                            'TAP AMBIL VIDEO',
                            style: TextStyle(color: Colors.white54, fontSize: 14),
                          ),
                          Text(
                            'Dari Galeri',
                            style: TextStyle(color: Colors.white24, fontSize: 10),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 16),

          // CAPTION
          TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Tulis caption... (opsional)',
              hintStyle: TextStyle(color: Colors.white54),
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            maxLines: 3,
            onChanged: (value) => _postCaption = value,
          ),
          const SizedBox(height: 16),

          // UPLOAD BUTTON
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isUploading ? null : _uploadVideo,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF0800),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _isUploading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: Colors.black,
                        strokeWidth: 2,
                      ),
                    )
                  : const Text(
                      'UPLOAD VIDEO',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFF0800),
              borderRadius: BorderRadius.circular(12),
              border: Border.fromBorderSide(BorderSide(color: const Color(0xFFFF0800))),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: Color(0xFFFF0800), size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Video akan muncul di feed semua user! 😈',
                    style: TextStyle(color: Colors.white54, fontSize: 11),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── PROFILE TAB ──────────────────────────────────────────────────
  Widget _buildProfileTab() {
    final user = _getCurrentUser();
    if (user == null) {
      return const Center(child: Text('User tidak ditemukan', style: TextStyle(color: Colors.white54)));
    }

    final userPosts = _posts.where((p) => p.userId == user.id).toList();

    return RefreshIndicator(
      onRefresh: () => _fetchUserPosts(user.id),
      color: const Color(0xFFFF0800),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // PROFILE HEADER
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFFF0800),
                borderRadius: BorderRadius.circular(16),
                border: Border.fromBorderSide(BorderSide(color: const Color(0xFFFF0800))),
              ),
              child: Column(
                children: [
                  // PP
                  GestureDetector(
                    onTap: _pickAndUploadImage,
                    child: Stack(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFFFF0800), width: 2),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Icon(
                                    Icons.person_rounded,
                                    color: Colors.white54,
                                    size: 40,
                                  ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFF0800),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt_rounded,
                              color: Colors.black,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    user.username,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    user.name,
                    style: TextStyle(color: Colors.white54, fontSize: 14),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildProfileStat('Posts', userPosts.length.toString()),
                      _buildProfileStat('Followers', user.followers.length.toString()),
                      _buildProfileStat('Following', user.following.length.toString()),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // USER POSTS
            if (userPosts.isEmpty)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 40),
                alignment: Alignment.center,
                child: const Text(
                  'Belum ada postingan',
                  style: TextStyle(color: Colors.white54),
                ),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemCount: userPosts.length > 9 ? 9 : userPosts.length,
                itemBuilder: (context, index) {
                  final post = userPosts[index];
                  return Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF0800),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.fromBorderSide(BorderSide(color: const Color(0xFFFF0800))),
                    ),
                    child: post.videoUrl != null && post.videoUrl!.isNotEmpty
                        ? const Icon(Icons.video_library_rounded, color: Colors.white24)
                        : const Icon(Icons.image_rounded, color: Colors.white24),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileStat(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
      ],
    );
  }
}