import 'dart:async';
import 'dart:convert';
import 'dart:math' as dart_math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';

import 'owner_page.dart';
import 'login_page.dart';
import 'device_dashboard.dart';
import 'chat.dart';
import 'profile_page.dart';
import 'profile_image_widget.dart';
import 'app_theme.dart';
import 'background_notifier.dart';
import 'background_settings_page.dart';
import 'background_widget.dart';
import 'tqto.dart';
import 'spotify_player.dart';

// ─── ENHANCED GLASS CARD ──────────────────────────────────────────
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? borderColor;
  final Color? bgColor;
  final List<Color>? gradient;
  final bool hasShadow;
  final VoidCallback? onTap;

  const _GlassCard({
    required this.child,
    this.padding,
    this.radius = 24,
    this.borderColor,
    this.bgColor,
    this.gradient,
    this.hasShadow = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget container = Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: gradient != null
            ? LinearGradient(colors: gradient!, begin: Alignment.topLeft, end: Alignment.bottomRight)
            : LinearGradient(
                colors: [AppColors.surface2, AppColors.surface],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        border: Border.all(
          color: borderColor ?? AppColors.silver2.withOpacity(0.15),
          width: 0.5,
        ),
        boxShadow: hasShadow ? ShadowUtils.card : null,
      ),
      child: child,
    );
    
    if (onTap != null) {
      return _AnimatedCard(
        onTap: onTap!,
        child: container,
      );
    }
    
    return container;
  }
}

class _AnimatedCard extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;

  const _AnimatedCard({required this.child, required this.onTap});

  @override
  State<_AnimatedCard> createState() => _AnimatedCardState();
}

class _AnimatedCardState extends State<_AnimatedCard> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.98 : 1.0,
        child: widget.child,
      ),
    );
  }
}

// ─── ENHANCED HEXAGON BACKGROUND ───────────────────────────────────
class _HexBackground extends StatelessWidget {
  final Widget child;
  const _HexBackground({required this.child});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _HexPainter(),
      child: child,
    );
  }
}

class _HexPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [AppColors.silver2.withOpacity(0.08), AppColors.gray2.withOpacity(0.03), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset.zero, radius: size.width * 0.6));
    canvas.drawCircle(Offset.zero, size.width * 0.6, glowPaint);
    
    final glowPaint2 = Paint()
      ..shader = RadialGradient(
        colors: [AppColors.gray1.withOpacity(0.05), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset(size.width, size.height), radius: size.width * 0.5));
    canvas.drawCircle(Offset(size.width, size.height), size.width * 0.5, glowPaint2);
    
    final hexWidth = 60.0;
    final hexHeight = hexWidth * dart_math.sqrt(3) / 2;
    final cols = (size.width / hexWidth).ceil() + 2;
    final rows = (size.height / hexHeight).ceil() + 2;
    
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5
      ..color = AppColors.silver2.withOpacity(0.02);
    
    for (int row = -1; row < rows; row++) {
      for (int col = -1; col < cols; col++) {
        final x = col * hexWidth + (row % 2) * hexWidth / 2;
        final y = row * hexHeight * 0.75;
        
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = i * dart_math.pi * 2 / 6;
          final px = x + hexWidth / 2 + dart_math.cos(angle) * hexWidth / 2;
          final py = y + hexHeight / 2 + dart_math.sin(angle) * hexHeight / 2;
          if (i == 0) path.moveTo(px, py);
          else path.lineTo(px, py);
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── PULSE DOT ────────────────────────────────────────────────────
class _PulseDot extends StatefulWidget {
  final Color color;
  const _PulseDot({required this.color});
  @override State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation: _a,
    builder: (_, __) => Container(
      width: 8, height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: widget.color.withOpacity(_a.value),
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.5), blurRadius: 6)],
      ),
    ),
  );
}

// ─── VIDEO BANNER WIDGET ──────────────────────────────────────────
class _VideoBanner extends StatefulWidget {
  final String videoPath;
  const _VideoBanner({required this.videoPath});

  @override
  State<_VideoBanner> createState() => _VideoBannerState();
}

class _VideoBannerState extends State<_VideoBanner> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset(widget.videoPath)
      ..initialize().then((_) {
        setState(() {
          _isInitialized = true;
        });
        _controller.setLooping(true);
        _controller.play();
      }).catchError((error) {
        debugPrint('Error loading video: $error');
        setState(() {
          _isInitialized = true;
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.silver2.withOpacity(0.4),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.silver2.withOpacity(0.15),
            blurRadius: 25,
            spreadRadius: 3,
          ),
          BoxShadow(
            color: AppColors.gray2.withOpacity(0.1),
            blurRadius: 15,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: _isInitialized && _controller.value.isInitialized
              ? VideoPlayer(_controller)
              : Container(
                  color: AppColors.surface2,
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: AppColors.silver2,
                        ),
                        SizedBox(height: 12),
                        Text(
                          'Loading video...',
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

// ─── PROFILE INFO CIRCLES ──────────────────────────────────────────

/// Circle kiri: Baterai HP dari device yang terpasang
class _BatteryCircle extends StatelessWidget {
  final int? batteryPercent; // null = loading
  const _BatteryCircle({this.batteryPercent});

  Color get _color {
    if (batteryPercent == null) return Colors.white38;
    if (batteryPercent! > 50) return const Color(0xFF4CAF50); // hijau
    if (batteryPercent! > 20) return const Color(0xFFFFEB3B); // kuning
    return const Color(0xFFF44336); // merah
  }

  @override
  Widget build(BuildContext context) {
    return _InfoCircle(
      borderColor: _color,
      child: batteryPercent == null
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.battery_unknown_rounded, color: Colors.white38, size: 16),
                Text('?', style: TextStyle(color: Colors.white38, fontSize: 9, fontWeight: FontWeight.bold)),
              ],
            )
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  batteryPercent! > 80
                      ? Icons.battery_full_rounded
                      : batteryPercent! > 50
                          ? Icons.battery_5_bar_rounded
                          : batteryPercent! > 20
                              ? Icons.battery_2_bar_rounded
                              : Icons.battery_alert_rounded,
                  color: _color,
                  size: 16,
                ),
                Text(
                  '$batteryPercent%',
                  style: TextStyle(
                    color: _color,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
    );
  }
}

/// Circle tengah: Total akun di database
class _DeviceCountCircle extends StatelessWidget {
  final int deviceCount;
  const _DeviceCountCircle({required this.deviceCount});

  @override
  Widget build(BuildContext context) {
    return _InfoCircle(
      borderColor: AppColors.silver2,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.people_alt_rounded, color: AppColors.silver2, size: 14),
          const SizedBox(height: 2),
          Text(
            '$deviceCount',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

/// Circle kanan: Cuaca di lokasi user
class _WeatherCircle extends StatelessWidget {
  final Map<String, dynamic>? weather; // null = loading
  const _WeatherCircle({this.weather});

  @override
  Widget build(BuildContext context) {
    if (weather == null) {
      return _InfoCircle(
        borderColor: Colors.white24,
        child: const SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white38),
        ),
      );
    }

    final code = (weather!['weathercode'] as int?) ?? 0;
    final isDay = (weather!['is_day'] as int?) ?? 1;
    final temp = weather!['temperature_2m'];

    // Tentukan ikon cuaca berdasarkan WMO weather code
    IconData icon;
    Color color;
    if (code == 0 || code == 1) {
      // Clear sky
      if (isDay == 1) {
        icon = Icons.wb_sunny_rounded;
        color = const Color(0xFFFFD600);
      } else {
        icon = Icons.nightlight_round;
        color = const Color(0xFFB0BEC5);
      }
    } else if (code <= 3) {
      // Partly cloudy
      icon = Icons.wb_cloudy_rounded;
      color = const Color(0xFFB0BEC5);
    } else if (code <= 49) {
      // Foggy/drizzle
      icon = Icons.cloud_rounded;
      color = const Color(0xFF90A4AE);
    } else if (code <= 67) {
      // Rain
      icon = Icons.umbrella_rounded;
      color = const Color(0xFF42A5F5);
    } else if (code <= 77) {
      // Snow
      icon = Icons.ac_unit_rounded;
      color = Colors.white;
    } else if (code <= 82) {
      // Rain showers
      icon = Icons.grain_rounded;
      color = const Color(0xFF1E88E5);
    } else {
      // Thunderstorm
      icon = Icons.thunderstorm_rounded;
      color = const Color(0xFFFFA726);
    }

    return _InfoCircle(
      borderColor: color,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 16),
          if (temp != null)
            Text(
              '${temp.round()}°',
              style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
        ],
      ),
    );
  }
}

/// Base lingkaran container
class _InfoCircle extends StatelessWidget {
  final Widget child;
  final Color borderColor;
  const _InfoCircle({required this.child, required this.borderColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withOpacity(0.45),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: [
          BoxShadow(color: borderColor.withOpacity(0.3), blurRadius: 8),
        ],
      ),
      child: Center(child: child),
    );
  }
}

// ─── PROFILE CARD WIDGET (FIXED) ──────────────────────────────────
class _ProfileCardWidget extends StatefulWidget {
  final String username;
  final String displayName;
  final String bio;
  final String expiredDate;
  final String role;
  final String password;
  final String sessionKey;
  final String ratId;
  final VoidCallback? onProfileSaved;

  const _ProfileCardWidget({
    required this.username,
    required this.displayName,
    required this.bio,
    required this.expiredDate,
    required this.role,
    required this.password,
    required this.sessionKey,
    required this.ratId,
    this.onProfileSaved,
  });

  @override
  State<_ProfileCardWidget> createState() => _ProfileCardWidgetState();
}

class _ProfileCardWidgetState extends State<_ProfileCardWidget> {
  int? _batteryPercent;
  int _deviceCount = 0;
  Map<String, dynamic>? _weather;
  final _battery = Battery();
  StreamSubscription<BatteryState>? _batterySub;

  // ── Live clock ──
  late DateTime _now;
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
    _loadDeviceInfo();
    _loadWeather();
    _loadLocalBattery();
  }

  Future<void> _loadLocalBattery() async {
    try {
      final level = await _battery.batteryLevel;
      if (mounted) setState(() => _batteryPercent = level);
      // Update otomatis kalau state baterai berubah (charge/discharge)
      _batterySub = _battery.onBatteryStateChanged.listen((_) async {
        try {
          final lvl = await _battery.batteryLevel;
          if (mounted) setState(() => _batteryPercent = lvl);
        } catch (_) {}
      });
    } catch (_) {
      // Kalau gagal (misalnya emulator), biarkan null → tampil '?'
    }
  }

  @override
  void dispose() {
    _batterySub?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadDeviceInfo() async {
    try {
      // Ambil baterai dari device pertama yang punya field battery valid
      // Ambil total akun dari database
      final accRes = await http.get(
        Uri.parse('$_kBase/api/user/totalAccounts?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (accRes.statusCode == 200) {
        final accBody = jsonDecode(accRes.body);
        if (accBody['valid'] == true && mounted) {
          setState(() => _deviceCount = (accBody['total'] as int?) ?? 0);
        }
      }
    } catch (e) {
      debugPrint('Error loading device info for circles: $e');
    }
  }

  Future<void> _loadWeather() async {
    try {
      // Step 1: Dapatkan koordinat dari ip-api.com (gratis, tanpa key)
      final locRes = await http.get(
        Uri.parse('http://ip-api.com/json/?fields=lat,lon,status'),
      ).timeout(const Duration(seconds: 8));

      double lat = -6.2; // default Jakarta
      double lon = 106.8;

      if (locRes.statusCode == 200) {
        final loc = jsonDecode(locRes.body);
        if (loc['status'] == 'success') {
          lat = (loc['lat'] as num).toDouble();
          lon = (loc['lon'] as num).toDouble();
        }
      }

      // Step 2: Ambil cuaca dari Open-Meteo (gratis, tanpa key)
      final weatherRes = await http.get(
        Uri.parse(
          'https://api.open-meteo.com/v1/forecast'
          '?latitude=$lat&longitude=$lon'
          '&current=temperature_2m,weathercode,is_day'
          '&forecast_days=1',
        ),
      ).timeout(const Duration(seconds: 10));

      if (weatherRes.statusCode == 200) {
        final data = jsonDecode(weatherRes.body);
        final current = data['current'] as Map<String, dynamic>?;
        if (current != null && mounted) {
          setState(() => _weather = current);
        }
      }
    } catch (e) {
      debugPrint('Error loading weather: $e');
    }
  }

  Color _getRoleColor(String role) {
    final lowerRole = role.toLowerCase();
    if (lowerRole == 'owner') return AppColors.error;
    if (lowerRole == 'reseller' || lowerRole == 'admin') return AppColors.success;
    return const Color(0xFF2196F3);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProfilePage(
              username: widget.username,
              password: widget.password,
              role: widget.role,
              expiredDate: widget.expiredDate,
              sessionKey: widget.sessionKey,
              ratId: widget.ratId,
            ),
          ),
        ).then((_) {
          widget.onProfileSaved?.call();
        });
      },
      child: Container(
        height: 230,
        decoration: BoxDecoration(
          image: const DecorationImage(
            image: AssetImage('assets/images/xp.png'),
            fit: BoxFit.cover,
            alignment: Alignment.topCenter,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppColors.silver2.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: ShadowUtils.card,
        ),
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.70)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  // ── Baris atas: Avatar + Info + Role badge ──
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ProfileImageWidget(
                        size: 76,
                        assetFallback: 'assets/images/a.jpg',
                        borderColor: Colors.white,
                        borderWidth: 2,
                        backgroundColor: AppColors.surface2,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.displayName.isNotEmpty ? widget.displayName : widget.username,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (widget.bio.isNotEmpty)
                              Text(
                                widget.bio,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 11,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            Text(
                              'Expired: ${widget.expiredDate}',
                              style: const TextStyle(
                                color: Colors.white54,
                                fontSize: 9,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getRoleColor(widget.role).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: _getRoleColor(widget.role).withOpacity(0.4),
                            width: 1,
                          ),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: TextStyle(
                            color: _getRoleColor(widget.role),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // ── Live Clock ──────────────────────────────────
                  _LiveClockBar(now: _now),

                  const SizedBox(height: 12),
                  // ── Baris bawah: 3 lingkaran info ──
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Lingkaran kiri: Baterai HP
                        Column(
                          children: [
                            _BatteryCircle(batteryPercent: _batteryPercent),
                            const SizedBox(height: 4),
                            const Text(
                              'Baterai',
                              style: TextStyle(color: Colors.white54, fontSize: 8),
                            ),
                          ],
                        ),
                        // Lingkaran tengah: Total akun
                        Column(
                          children: [
                            _DeviceCountCircle(deviceCount: _deviceCount),
                            const SizedBox(height: 4),
                            const Text(
                              'Akun',
                              style: TextStyle(color: Colors.white54, fontSize: 8),
                            ),
                          ],
                        ),
                        // Lingkaran kanan: Cuaca
                        Column(
                          children: [
                            _WeatherCircle(weather: _weather),
                            const SizedBox(height: 4),
                            const Text(
                              'Cuaca',
                              style: TextStyle(color: Colors.white54, fontSize: 8),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── LIVE CLOCK BAR ────────────────────────────────────────────────
class _LiveClockBar extends StatelessWidget {
  final DateTime now;
  const _LiveClockBar({required this.now});

  String _twoDigit(int n) => n.toString().padLeft(2, '0');

  String get _timeStr =>
      '${_twoDigit(now.hour)}:${_twoDigit(now.minute)}:${_twoDigit(now.second)}';

  String get _dateStr {
    const days = [
      'Sunday', 'Monday', 'Tuesday', 'Wednesday',
      'Thursday', 'Friday', 'Saturday'
    ];
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return '${days[now.weekday % 7]}, ${now.day} ${months[now.month - 1]} ${now.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFFD600).withOpacity(0.25),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFFD600).withOpacity(0.08),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.access_time_rounded,
            color: const Color(0xFFFFD600).withOpacity(0.8),
            size: 13,
          ),
          const SizedBox(width: 8),
          Text(
            '$_timeStr  •  $_dateStr',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── DEVICE STATUS CARD ────────────────────────────────────────────
class _DeviceStatusCard extends StatelessWidget {
  final int count;
  final bool isOnline;

  const _DeviceStatusCard({
    required this.count,
    required this.isOnline,
  });

  @override
  Widget build(BuildContext context) {
    final bgColor = isOnline ? AppColors.success : AppColors.error;
    
    return Expanded(
      child: Container(
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: bgColor.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: ShadowUtils.soft,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.surface2.withOpacity(0.6),
              AppColors.surface.withOpacity(0.8),
            ],
          ),
        ),
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.05),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.1),
                  width: 0.5,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    isOnline ? 'DEVICE ONLINE' : 'DEVICE OFFLINE',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              bgColor.withOpacity(0.3),
                              bgColor.withOpacity(0.1),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: bgColor.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          isOnline ? Icons.check_circle_rounded : Icons.cancel_rounded,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '$count',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(
                        isOnline ? FontAwesomeIcons.signal : FontAwesomeIcons.powerOff,
                        color: bgColor,
                        size: 12,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        isOnline ? 'Aktif & Terhubung' : 'Tidak Terhubung',
                        style: TextStyle(
                          color: bgColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── MAIN DASHBOARD PAGE ───────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({super.key, required this.username, required this.password, required this.role,
    required this.expiredDate, required this.listBug, required this.listDoos, required this.sessionKey, required this.news});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

const String _kBase = 'http://rizqy.smasnug.web.id:10003';

Route _createRoute(Widget page) {
  return PageRouteBuilder(
    transitionDuration: const Duration(milliseconds: 400),
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const curve = Curves.easeOutCubic;
      var tween = Tween(begin: const Offset(0.03, 0.0), end: Offset.zero)
          .chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);
      var fadeTween = Tween(begin: 0.0, end: 1.0)
          .chain(CurveTween(curve: curve));
      var fadeAnimation = animation.drive(fadeTween);
      return FadeTransition(
        opacity: fadeAnimation,
        child: SlideTransition(
          position: offsetAnimation,
          child: child,
        ),
      );
    },
  );
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late WebSocketChannel channel;
  late String sessionKey, username, role, expiredDate;
  late String password; // ✅ TAMBAHKAN
  String androidId = "unknown";
  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();
  int _onlineDevices = 0;
  int _offlineDevices = 0;
  
  // Pairing ID
  String _pairId = '';
  bool _isLoadingPairId = false;

  // Display Name & Bio (from server)
  String _displayName = '';
  String _bio = '';

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password; // ✅ TAMBAHKAN
    role = widget.role;
    expiredDate = widget.expiredDate;
    
    _fadeCtrl = AnimationController(duration: const Duration(milliseconds: 500), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    _fadeCtrl.forward();
    
    _selectedPage = _buildDashboardHome();
    _initAndroidIdAndConnect();
    _loadDeviceStats();
    _loadPairId();
    _loadDisplayProfile();

    // Load lagu Spotify dari API server setelah login
    WidgetsBinding.instance.addPostFrameCallback((_) {
      SpotifyScope.of(context).loadTrendingFromApi();
    });
  }

  Future<void> _loadPairId() async {
    if (_isLoadingPairId) return;
    setState(() => _isLoadingPairId = true);
    try {
      final response = await http
          .get(Uri.parse('$_kBase/rat/pairid?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['pairId'] != null) {
          if (mounted) setState(() => _pairId = data['pairId'].toString());
        }
      }
    } catch (e) {
      debugPrint('Error loading pairId: $e');
    } finally {
      if (mounted) setState(() => _isLoadingPairId = false);
    }
  }

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.silver2,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            Icon(Icons.copy_rounded, color: Colors.white, size: 18),
            SizedBox(width: 8),
            Text('ID Pairing berhasil disalin!'),
          ],
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _loadDisplayProfile() async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/user/profile?key=$sessionKey'), // same endpoint as profile_page.dart's _kBaseUrl/profile
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true && data['profile'] != null) {
        final p = data['profile'] as Map<String, dynamic>;
        if (mounted) {
          setState(() {
            _displayName = (p['displayName'] ?? '').toString();
            _bio = (p['bio'] ?? '').toString();
            _selectedPage = _buildDashboardHome();
          });
        }
      }
    } catch (_) {/* keep defaults */}
  }

  Future<void> _loadDeviceStats() async {
    try {
      final response = await http.get(
        Uri.parse('$_kBase/rat/my-devices?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (body['valid'] == true) {
          List<dynamic> devices = body['devices'] ?? [];
          int online = 0, offline = 0;
          
          for (var d in devices) {
            try {
              final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
              if (DateTime.now().difference(seen).inSeconds < 30) {
                online++;
              } else {
                offline++;
              }
            } catch (_) {
              offline++;
            }
          }
          
          if (mounted) {
            setState(() {
              _onlineDevices = online;
              _offlineDevices = offline;
            });
          }
        }
      }
    } catch (e) {
      debugPrint('Error loading device stats: $e');
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectWebSocket();
  }

  void _connectWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws:privatesrvrenn.sano.biz.id:10831'));
    channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) _showSessionExpired();
    });
  }

  void _showSessionExpired() async {
    await SharedPreferences.getInstance().then((p) => p.clear());
    if (!mounted) return;
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(radius: 24,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.error, AppColors.error]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(Icons.warning_amber_rounded, color: Colors.white, size: 24),
            ),
            const SizedBox(height: 12),
            const Text("Session Expired", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            Text("Silakan login kembali", style: TextStyle(color: AppColors.textSec)),
            const SizedBox(height: 16),
            _AnimatedDialogButton(
              text: "OK",
              onTap: () => Navigator.pushAndRemoveUntil(context, _createRoute(const LoginPage()), (r) => false),
            ),
          ]),
        ),
      ),
    );
  }

  void _onNavTapped(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildDashboardHome();
      } else if (index == 1) {
        _selectedPage = ChatPage(
          username: username,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = DeviceDashboardPage(username: username, role: role, sessionKey: sessionKey);
      }
    });
  }

  void _navigateToOwner() => Navigator.push(context, _createRoute(BackgroundWrapper(child: OwnerPage(sessionKey: sessionKey, username: username))));
  
  void _navigateToBackgroundSettings() {
    Navigator.push(
      context,
      _createRoute(BackgroundWrapper(
        child: BackgroundSettingsPage(
          onBackgroundChanged: () {},
        ),
      )),
    );
  }
  
  // ✅ SHOW ACCOUNT SHEET → NAVIGASI KE PROFILE PAGE (FIXED)
  void _showAccountSheet() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          ratId: _pairId,
        ),
      ),
    ).then((_) {
      _loadDisplayProfile();
    });
  }

  void _showNotificationSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: ShadowUtils.heavy,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
              borderRadius: BorderRadius.circular(2),
            )),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.surface2, AppColors.surfaceLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppColors.silver2.withOpacity(0.2),
                  width: 0.5,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.surface2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: AppColors.silver2.withOpacity(0.2),
                        width: 0.5,
                      ),
                    ),
                    child: Icon(Icons.mail_outline_rounded, color: AppColors.silver2, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Inbox Pesan',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Kalau Ada Error Bisa Hubungi @rizqynst2011',
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _showComingSoonToast() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Feature Coming Soon'),
        backgroundColor: AppColors.gray1,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildDashboardHome() {
    return _HexBackground(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
        physics: const BouncingScrollPhysics(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const _VideoBanner(videoPath: 'assets/videos/flux.mp4'),
          const SizedBox(height: 2),
          _ProfileCardWidget(
            username: username,
            displayName: _displayName,
            bio: _bio,
            expiredDate: expiredDate,
            role: role,
            password: password, // ✅ TAMBAHKAN
            sessionKey: sessionKey, // ✅ TAMBAHKAN
            ratId: _pairId, // ✅ TAMBAHKAN
            onProfileSaved: _loadDisplayProfile,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _DeviceStatusCard(count: _onlineDevices, isOnline: true),
              const SizedBox(width: 12),
              _DeviceStatusCard(count: _offlineDevices, isOnline: false),
            ],
          ),
          const SizedBox(height: 14),
          _ThanksToButton(
            onTap: () => Navigator.push(
              context,
              _createRoute(BackgroundWrapper(child: const ThanksToPage())),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildBottomNav() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppColors.silver2.withOpacity(0.25),
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.silver2.withOpacity(0.12),
                blurRadius: 24,
                spreadRadius: 2,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              _FloatingNavItem(
                icon: Icons.grid_view_rounded,
                label: 'Utama',
                isActive: _bottomNavIndex == 0,
                onTap: () => _onNavTapped(0),
              ),
              _FloatingNavItem(
                icon: Icons.chat_bubble_outline_rounded,
                activeIcon: Icons.chat_bubble_rounded,
                label: 'Chat',
                isActive: _bottomNavIndex == 1,
                onTap: () => _onNavTapped(1),
              ),
              _FloatingNavItem(
                icon: Icons.devices_outlined,
                activeIcon: Icons.devices_rounded,
                label: 'Device',
                isActive: _bottomNavIndex == 2,
                onTap: () => _onNavTapped(2),
              ),
            ],
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      toolbarHeight: 60,
      titleSpacing: 0,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Builder(
          builder: (ctx) => IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.silver2.withOpacity(0.2), width: 0.5),
              ),
              child: Icon(FontAwesomeIcons.bars, color: AppColors.silver2, size: 14),
            ),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
      ),
      title: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'ALICIA',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  TextSpan(
                    text: 'XRAT',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF808080),
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Row(
            children: [
              const SpotifyHeadsetButton(),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _showNotificationSheet,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.silver2.withOpacity(0.2), width: 0.5),
                  ),
                  child: Icon(Icons.notifications_outlined, color: AppColors.silver2, size: 16),
                ),
              ),
              const SizedBox(width: 8),
              _ProfileAvatar(onTap: _showAccountSheet),
              const SizedBox(width: 4),
            ],
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.transparent, AppColors.silver2, Colors.transparent],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: AppColors.surface,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(children: [
        Container(
          height: 200,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppColors.silver2, AppColors.gray2], begin: Alignment.topLeft, end: Alignment.bottomRight),
            border: Border(bottom: BorderSide(color: AppColors.silver2.withOpacity(0.2))),
          ),
          child: Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              TweenAnimationBuilder(
                duration: const Duration(milliseconds: 500),
                tween: Tween<double>(begin: 0.8, end: 1.0),
                curve: Curves.easeOutBack,
                builder: (context, value, child) => Transform.scale(scale: value, child: child),
                child: ProfileImageWidget(
                  size: 80,
                  assetFallback: 'assets/images/logo.png',
                  borderColor: Colors.white.withOpacity(0.3),
                  borderWidth: 2,
                  backgroundColor: Colors.white.withOpacity(0.1),
                ),
              ),
              const SizedBox(height: 8),
              Text(_displayName.isNotEmpty ? _displayName : username, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.silver2.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.silver2.withOpacity(0.3)),
                ),
                child: Text(role.toUpperCase(), style: TextStyle(color: AppColors.silver2, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ]),
          ),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            if (role.toLowerCase() == 'owner')
              _DrawerItem(
                icon: Icons.storefront_rounded, 
                title: 'Owner Panel', 
                onTap: () { Navigator.pop(context); _navigateToOwner(); },
              ),
            
            // ✅ PROFILE MENU DI DRAWER (FIXED)
            _DrawerItem(
              icon: Icons.person_rounded,
              title: 'Profile',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfilePage(
                      username: username,
                      password: password,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                      ratId: _pairId,
                    ),
                  ),
                ).then((_) {
                  _loadDisplayProfile();
                });
              },
            ),
            
            const SizedBox(height: 4),
            _DrawerItem(
              icon: Icons.link_rounded,
              title: 'Pairing ID',
              onTap: () {
                Navigator.pop(context);
                if (_pairId.isNotEmpty) {
                  _copyPairId();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Memuat Pairing ID...'),
                      backgroundColor: AppColors.gray1,
                      duration: const Duration(seconds: 2),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  );
                  _loadPairId();
                }
              },
            ),
            if (_pairId.isNotEmpty) ...[
              const SizedBox(height: 2),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: AppColors.silver2.withOpacity(0.2),
                      width: 0.5,
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _pairId,
                          style: TextStyle(
                            color: AppColors.silver2,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _copyPairId,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: AppColors.silver2.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: AppColors.silver2.withOpacity(0.3),
                              width: 0.5,
                            ),
                          ),
                          child: Icon(
                            Icons.copy_rounded,
                            color: AppColors.silver2,
                            size: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            if (_isLoadingPairId) ...[
              const SizedBox(height: 2),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.silver2,
                    ),
                  ),
                ),
              ),
            ],
            
            const SizedBox(height: 8),
            Divider(color: AppColors.surface2),
            const SizedBox(height: 8),
            _DrawerItem(
              icon: Icons.wallpaper_rounded, 
              title: 'Background Settings', 
              color: AppColors.silver2, 
              onTap: () { Navigator.pop(context); _navigateToBackgroundSettings(); },
            ),
            const SizedBox(height: 8),
            _DrawerItem(
              icon: Icons.brush_rounded,
              title: 'Ganti Warna',
              color: AppColors.silver2,
              onTap: () { Navigator.pop(context); showColorPickerSheet(context); },
            ),
            const SizedBox(height: 8),
            _DrawerItem(
              icon: Icons.logout_rounded, 
              title: 'Logout', 
              color: AppColors.error, 
              onTap: () { Navigator.pop(context); _showLogoutDialog(); },
            ),
            const SizedBox(height: 20),
            Center(child: Text("ULAR BY SNAKE", style: TextStyle(color: AppColors.textMuted, fontSize: 9, letterSpacing: 2))),
          ]),
        ),
      ]),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(radius: 24,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 60,
              height: 60,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.warning, AppColors.error]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Image.asset(
                'assets/images/logo.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.logout_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text("Konfirmasi Logout", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            Text("Yakin ingin logout?", style: TextStyle(color: AppColors.textSec)),
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal", style: TextStyle(color: Colors.grey))),
              const SizedBox(width: 8),
              _AnimatedDialogButton(
                text: "Logout",
                onTap: () async {
                  Navigator.pop(context);
                  // Reset background ke foto default
                  final bgNotifier = BackgroundScope.of(context);
                  await bgNotifier.reset();
                  // Reset warna ke kuning/gold default
                  final themeNotifier = ThemeScope.of(context);
                  await themeNotifier.reset();
                  // Bersihkan semua sesi
                  await SharedPreferences.getInstance().then((p) => p.clear());
                  if (mounted) Navigator.pushAndRemoveUntil(
                    context, _createRoute(const LoginPage()), (r) => false);
                },
                isError: true,
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  @override Widget build(BuildContext context) {
    // React to theme changes
    final themeNotifier = ThemeScope.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) => Scaffold(
        backgroundColor: Colors.transparent,
        drawer: _buildDrawer(),
        appBar: _buildAppBar(),
        extendBody: true,
        body: FadeTransition(opacity: _fadeAnim, child: _selectedPage),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  @override void dispose() {
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    super.dispose();
  }
}

// ─── FLOATING NAV ITEM ──────────────────────────────────────────────
class _FloatingNavItem extends StatefulWidget {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _FloatingNavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  State<_FloatingNavItem> createState() => _FloatingNavItemState();
}

class _FloatingNavItemState extends State<_FloatingNavItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTapDown: (_) => setState(() => _isPressed = true),
        onTapUp: (_) => setState(() => _isPressed = false),
        onTapCancel: () => setState(() => _isPressed = false),
        onTap: () {
          HapticFeedback.lightImpact();
          widget.onTap();
        },
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _isPressed ? 0.94 : 1.0,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              decoration: widget.isActive
                  ? BoxDecoration(
                      color: AppColors.surface2.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: AppColors.silver2.withOpacity(0.5),
                        width: 1.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.silver2.withOpacity(0.2),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                    ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                child: Row(
                  mainAxisAlignment: widget.isActive
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: Icon(
                        widget.isActive
                            ? (widget.activeIcon ?? widget.icon)
                            : widget.icon,
                        key: ValueKey(widget.isActive),
                        color: widget.isActive
                            ? AppColors.silver2
                            : AppColors.textMuted,
                        size: 20,
                      ),
                    ),
                    if (widget.isActive) ...[
                      const SizedBox(width: 8),
                      AnimatedOpacity(
                        duration: const Duration(milliseconds: 200),
                        opacity: widget.isActive ? 1.0 : 0.0,
                        child: Text(
                          widget.label,
                          style: TextStyle(
                            color: AppColors.silver2,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ProfileAvatar extends StatefulWidget {
  final VoidCallback onTap;

  const _ProfileAvatar({required this.onTap});

  @override
  State<_ProfileAvatar> createState() => _ProfileAvatarState();
}

class _ProfileAvatarState extends State<_ProfileAvatar> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.92 : 1.0,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
            boxShadow: ShadowUtils.soft,
            border: Border.all(color: AppColors.silver2.withOpacity(0.3), width: 1),
          ),
          child: const CircleAvatar(
            radius: 16,
            backgroundColor: Colors.transparent,
            child: Icon(Icons.person_outline, color: Colors.white, size: 16),
          ),
        ),
      ),
    );
  }
}

// ─── DRAWER ITEM ────────────────────────────────────────────────────
class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String title;
  final Color? color;
  final VoidCallback onTap;
  final bool useLogo;

  const _DrawerItem({
    required this.icon,
    required this.title,
    this.color,
    required this.onTap,
    this.useLogo = false,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.98 : 1.0,
        child: ListTile(
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
            ),
            child: widget.useLogo
                ? Image.asset(
                    'assets/images/logo.png',
                    width: 18,
                    height: 18,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      widget.icon,
                      color: widget.color ?? AppColors.silver2,
                      size: 18,
                    ),
                  )
                : Icon(
                    widget.icon,
                    color: widget.color ?? AppColors.silver2,
                    size: 18,
                  ),
          ),
          title: Text(
            widget.title,
            style: TextStyle(
              color: widget.color ?? Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

// ─── ANIMATED DIALOG BUTTON ─────────────────────────────────────────
class _AnimatedDialogButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final bool isError;

  const _AnimatedDialogButton({
    required this.text,
    required this.onTap,
    this.isError = false,
  });

  @override
  State<_AnimatedDialogButton> createState() => _AnimatedDialogButtonState();
}

class _AnimatedDialogButtonState extends State<_AnimatedDialogButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.95 : 1.0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          decoration: BoxDecoration(
            gradient: widget.isError
                ? LinearGradient(colors: [AppColors.error, AppColors.error])
                : LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
          ),
          child: Text(
            widget.text,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}

// ─── ACCOUNT BOTTOM SHEET ───────────────────────────────────────────
class _AccountSheet extends StatelessWidget {
  final String username, role, expiredDate;
  final VoidCallback onLogout;
  const _AccountSheet({required this.username, required this.role, required this.expiredDate, required this.onLogout});

  @override Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: ShadowUtils.heavy,
        border: Border(top: BorderSide(color: AppColors.silver2.withOpacity(0.2))),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(
          gradient: LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
          borderRadius: BorderRadius.circular(2),
        )),
        const SizedBox(height: 16),
        TweenAnimationBuilder(
          duration: const Duration(milliseconds: 400),
          tween: Tween<double>(begin: 0.8, end: 1.0),
          curve: Curves.easeOutBack,
          builder: (context, value, child) => Transform.scale(scale: value, child: child),
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
              boxShadow: ShadowUtils.medium,
              border: Border.all(color: AppColors.silver2.withOpacity(0.3), width: 2),
            ),
            child: const CircleAvatar(
              radius: 35,
              backgroundColor: Colors.transparent,
              child: Icon(Icons.person_outline, color: Colors.white, size: 35),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(username, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
          decoration: BoxDecoration(
            color: AppColors.silver2.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.silver2.withOpacity(0.3)),
          ),
          child: Text(role.toUpperCase(), style: TextStyle(color: AppColors.silver2, fontSize: 9, fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text("Tutup", style: TextStyle(color: Colors.grey)))),
          Expanded(
            child: _AnimatedSheetButton(
              text: "Logout",
              onTap: () { Navigator.pop(context); onLogout(); },
              isError: true,
            ),
          ),
        ]),
      ]),
    );
  }
}

class _AnimatedSheetButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final bool isError;

  const _AnimatedSheetButton({
    required this.text,
    required this.onTap,
    this.isError = false,
  });

  @override
  State<_AnimatedSheetButton> createState() => _AnimatedSheetButtonState();
}

class _AnimatedSheetButtonState extends State<_AnimatedSheetButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _isPressed ? 0.97 : 1.0,
        child: Container(
          decoration: BoxDecoration(
            gradient: widget.isError
                ? LinearGradient(colors: [AppColors.error, AppColors.error])
                : LinearGradient(colors: [AppColors.silver2, AppColors.gray2]),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
          ),
          child: TextButton(
            onPressed: null,
            child: Text(
              widget.text,
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }
}
// ─── THANKS TO BUTTON ────────────────────────────────────────────────────────
class _ThanksToButton extends StatefulWidget {
  final VoidCallback onTap;
  const _ThanksToButton({required this.onTap});

  @override
  State<_ThanksToButton> createState() => _ThanksToButtonState();
}

class _ThanksToButtonState extends State<_ThanksToButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _pressed ? 0.97 : 1.0,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(16, 15, 8, 15),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppColors.silver2.withOpacity(0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.silver2.withOpacity(0.08),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Icon lingkaran gradient
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.silver2, AppColors.gray2],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.silver2.withOpacity(0.25),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.people_rounded,
                  color: Colors.white,
                  size: 17,
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'SPECIAL THANKS TO',
                    style: TextStyle(
                      color: AppColors.silver2,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.4,
                    ),
                  ),
                  Text(
                    'Lihat daftar kontributor',
                    style: TextStyle(
                      color: AppColors.silver2.withOpacity(0.55),
                      fontSize: 10,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Icon(
                Icons.chevron_right_rounded,
                color: AppColors.silver2.withOpacity(0.5),
                size: 22,
              ),
              const SizedBox(width: 4),
            ],
          ),
        ),
      ),
    );
  }
}
