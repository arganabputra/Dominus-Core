// ============================================================
// DASHBOARD_PAGE.FULL.RED.THEME.WITH.TQTO.AVATAR.DART
// ============================================================
// WARNA MERAH SEPERTI FOTO PERTAMA - FULL CODE + TQTO FOTO
// ============================================================

import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:ui';
import 'package:image_picker/image_picker.dart';

// Halaman lain
import 'marketing_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'chat_page.dart';
import 'list_harga.dart';
import 'public_page.dart';
import 'weather_page.dart';
import 'tqto.dart';

// ─── SOSIAL MEDIA ─────────────────────────────────────────────────────
import 'social_media_button.dart';
import 'social_media_page.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';

// ─── KONFIGURASI ─────────────────────────────────────────────────────
const String wsUrl = 'ws://princesszahra.hostingvvip.web.id:4156';

// ─── WARNA (MERAH THEME SEPERTI FOTO PERTAMA) ──────────────────
const Color kBg      = Color(0xB31A0505);
const Color kCard    = Color(0xFFFF0800);
const Color kCardAlt = Color(0x29B30000);
const Border kBorder = Border.fromBorderSide(BorderSide(color: Color(0xFFFF0800)));
const Color kCyan    = Color(0xFFFF0800);      // MERAH
const Color kGreen   = Color(0xFF00FFCC);
const Color kPink    = Color(0xFFFF007F);
const Color kOrange  = Color(0xFFFF6600);
const Color kBlue    = Color(0xFF0055FF);
const Color kPurple  = Color(0xFF9900FF);
const Color kYellow  = Color(0xFFFFD700);
const Color kWhite   = Colors.white;
const Color kWhite70 = Colors.white70;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

// ─── PRAYER TIME SERVICE ───────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city,
      'country': 'ID',
      'method': '11',
      'day': '${now.day}',
      'month': '${now.month}',
      'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── ROLE HELPERS ──────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'staf':     return const Color(0xFFFF0800);
    case 'exec':     return const Color(0xFFFF4500);
    case 'vvip':     return const Color(0xFFFF1493);
    case 'svip':     return const Color(0xFFFF6347);
    case 'owner':    return const Color(0xFFFFD700);
    case 'ceo':      return const Color(0xFFFF8C00);
    case 'mod':      return const Color(0xFFFF4500);
    case 'pt':       return const Color(0xFF32CD32);
    case 'reseller': return const Color(0xFFFF0800);
    case 'full up':  return const Color(0xFF9E9E9E);
    case 'creator':  return const Color(0xFF00FFAA);
    case 'developer':return const Color(0xFFAA00FF);
    default:         return const Color(0xFFFF0800);
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'staf':     return Icons.people_rounded;
    case 'exec':     return Icons.work_rounded;
    case 'vvip':     return Icons.star_rounded;
    case 'svip':     return Icons.star_half_rounded;
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'ceo':      return Icons.business_center_rounded;
    case 'mod':      return Icons.gavel_rounded;
    case 'pt':       return Icons.settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'full up':  return Icons.person_rounded;
    case 'creator':  return Icons.create_rounded;
    case 'developer':return Icons.code_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ─────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── RGB BORDER PAINTER ──────────────────────────────────────────────
class _RgbBorderPainter extends CustomPainter {
  final double rotationValue;
  _RgbBorderPainter({required this.rotationValue});
  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(rect, const Radius.circular(20));
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..shader = SweepGradient(
        transform: GradientRotation(rotationValue),
        colors: const [
          Color(0xFFFF0800),
          Color(0xFFD10000),
          Color(0xFF800000),
          Color(0x00000000),
          Color(0xFF800000),
          Color(0xFFFF0800),
        ],
        stops: const [0.0, 0.2, 0.4, 0.5, 0.8, 1.0],
      ).createShader(rect);
    canvas.drawRRect(rrect, paint);
  }
  @override
  bool shouldRepaint(covariant _RgbBorderPainter oldDelegate) {
    return oldDelegate.rotationValue != rotationValue;
  }
}

// ─── DASHBOARD PAGE ──────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _rgbBannerCtrl;

  Timer? _statsTimer;
  Timer? _newsAutoScrollTimer;

  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  late PageController _horizontalNewsPageCtrl;
  int _horizontalNewsIndex = 0;

  bool _locationLoading = false;
  bool _locationGranted = false;

  String _prayerCity = 'makassar';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;
  String _selectedTimeZone = 'WITA';

  // ─── CREDITS TYPING ────────────────────────────────────────────────
  String _creditsDisplay = "";
  Timer? _creditsTimer;
  int _creditsIndex = 0;
  bool _creditsDeleting = false;
  final String _creditsFullText = "Credits By @Chs_Caze";

  // ─── TITLE TYPING ──────────────────────────────────────────────────
  String _titleDisplay = "";
  Timer? _titleTimer;
  int _titleIndex = 0;
  bool _titleDeleting = false;
  final String _titleFullText = "DarkMega";

  final List<Map<String, String>> _mockNewsData = [
    {
      'title': 'DarkMega',
      'image': 'https://ganga--link--ghhzdp9sv8hk.code.run/i/cum7ivuy.jpg',
      'source': 'DarkMega',
      'date': '20 Juni 2026'
    },
    {
      'title': 'Metro TV Raih Penghargaan Media Penyiaran Terinovatif Digital',
      'image': 'https://picsum.photos/id/2/720/540',
      'source': 'Metro TV',
      'date': '20 Juni 2026'
    },
    {
      'title': 'Pasar Gadget Indonesia Melonjak Tajam Menjelang Akhir Kuartal',
      'image': 'https://picsum.photos/id/3/720/540',
      'source': 'Agunt',
      'date': '19 Juni 2026'
    },
    {
      'title': 'Live Report: Kondisi Lalu Lintas Ibu Kota Terpantau Ramai Lancar',
      'image': 'https://picsum.photos/id/4/720/540',
      'source': 'Metro TV',
      'date': '19 Juni 2026'
    },
    {
      'title': 'Startup Cyber Security Lokal Dapatkan Pendanaan Seri A',
      'image': 'https://picsum.photos/id/5/720/540',
      'source': 'Kumparan',
      'date': '18 Juni 2026'
    },
    {
      'title': 'Bedah Teknologi Jaringan 6G Bersama Pakar IT Nasional',
      'image': 'https://picsum.photos/id/6/720/540',
      'source': 'Metro TV',
      'date': '18 Juni 2026'
    },
    {
      'title': 'Rekomendasi Laptop Programmer Terbaik untuk Mahasiswa',
      'image': 'https://picsum.photos/id/7/720/540',
      'source': 'Kumparan',
      'date': '17 Juni 2026'
    },
    {
      'title': 'Wawancara Eksklusif: Masa Depan Open Source di Asia Tenggara',
      'image': 'https://picsum.photos/id/8/720/540',
      'source': 'Metro TV',
      'date': '17 Juni 2026'
    },
    {
      'title': 'Tips Mengamankan Akun Digital Dari Serangan Phishing',
      'image': 'https://picsum.photos/id/9/720/540',
      'source': 'Kumparan',
      'date': '16 Juni 2026'
    },
    {
      'title': 'Peluncuran Satelit Komunikasi Baru Sukses Dilaksanakan',
      'image': 'https://picsum.photos/id/11/720/540',
      'source': 'Metro TV',
      'date': '15 Juni 2026'
    },
  ];

  // ─── TQTO LIST DENGAN AVATAR ──────────────────────────────────────
  final List<Map<String, dynamic>> _tqtoList = [
    {'name': 'AGUNG', 'role': 'FOUNDER', 'avatar': 'https://files.catbox.moe/eqpoka.jpg'},
    {'name': 'DEFFAX', 'role': 'CREATOR', 'avatar': 'https://files.catbox.moe/5lqjop.jpg'},
    {'name': 'AGF', 'role': 'PT FUNCT', 'avatar': 'https://files.catbox.moe/flr1rx.jpg'},
    {'name': 'MONTIS', 'role': 'CEO', 'avatar': 'https://files.catbox.moe/dkydz3.jpg'},
    {'name': 'FIDZKAL', 'role': 'CREATOR', 'avatar': 'https://files.catbox.moe/avatar5.jpg'},
    {'name': 'REZX', 'role': 'CREATOR', 'avatar': 'https://files.catbox.moe/avatar6.jpg'},
  ];

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _rgbBannerCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))
      ..repeat();

    _newsPageCtrl = PageController(viewportFraction: 0.86, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _horizontalNewsPageCtrl = PageController(viewportFraction: 0.90, initialPage: 0);
    _startNewsAutoScroll();
    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer();

    _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), _updateCredits);
    _titleTimer = Timer.periodic(const Duration(milliseconds: 120), _updateTitle);
  }

  void _updateCredits(Timer timer) {
    if (!mounted) return;
    if (!_creditsDeleting) {
      if (_creditsIndex < _creditsFullText.length) {
        _creditsIndex++;
        setState(() {
          _creditsDisplay = _creditsFullText.substring(0, _creditsIndex);
        });
      } else {
        _creditsDeleting = true;
        _creditsTimer?.cancel();
        _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), (t) {
          if (_creditsIndex > 0) {
            _creditsIndex--;
            setState(() {
              _creditsDisplay = _creditsFullText.substring(0, _creditsIndex);
            });
          } else {
            _creditsDeleting = false;
            _creditsTimer?.cancel();
            _creditsTimer = Timer.periodic(const Duration(milliseconds: 120), _updateCredits);
          }
        });
        Future.delayed(const Duration(seconds: 3), () {});
      }
    }
  }

  void _updateTitle(Timer timer) {
    if (!mounted) return;
    if (!_titleDeleting) {
      if (_titleIndex < _titleFullText.length) {
        _titleIndex++;
        setState(() {
          _titleDisplay = _titleFullText.substring(0, _titleIndex);
        });
      } else {
        _titleDeleting = true;
        _titleTimer?.cancel();
        _titleTimer = Timer.periodic(const Duration(milliseconds: 120), (t) {
          if (_titleIndex > 0) {
            _titleIndex--;
            setState(() {
              _titleDisplay = _titleFullText.substring(0, _titleIndex);
            });
          } else {
            _titleDeleting = false;
            _titleTimer?.cancel();
            _titleTimer = Timer.periodic(const Duration(milliseconds: 120), _updateTitle);
          }
        });
        Future.delayed(const Duration(seconds: 3), () {});
      }
    }
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _newsAutoScrollTimer?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _rgbBannerCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    _horizontalNewsPageCtrl.dispose();
    _creditsTimer?.cancel();
    _titleTimer?.cancel();
    super.dispose();
  }

  void _startNewsAutoScroll() {
    _newsAutoScrollTimer?.cancel();
    _newsAutoScrollTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (newsList.isNotEmpty && _newsPageCtrl.hasClients) {
        int nextPage = _newsPageCtrl.page!.round() + 1;
        if (nextPage >= newsList.length) {
          nextPage = 0;
        }
        _newsPageCtrl.animateToPage(
          nextPage,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOutCubic,
        );
      }
    });
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(10);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('WebSocket URL tidak valid: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) _connectWS();
      });
      return;
    }

    channel!.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel!.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel!.sink.add(jsonEncode({'type': 'stats'}));
      }

      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConns = data['activeConnections'] ?? 0;
        });
      }

      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }

      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel?.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  String _adjustTimeByZone(String baseTime, String zone) {
    if (baseTime == '--:--') return baseTime;
    final parts = baseTime.split(':');
    if (parts.length < 2) return baseTime;

    int hour = int.tryParse(parts[0]) ?? 0;
    int minute = int.tryParse(parts[1]) ?? 0;

    if (zone == 'WITA') {
      hour = (hour + 1) % 24;
    } else if (zone == 'WIT') {
      hour = (hour + 2) % 24;
    }

    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};

      final Map<String, String> times = {
        'Subuh'  : _adjustTimeByZone(timings['Fajr']    ?? '--:--', _selectedTimeZone),
        'Dzuhur' : _adjustTimeByZone(timings['Dhuhr']   ?? '--:--', _selectedTimeZone),
        'Ashar'  : _adjustTimeByZone(timings['Asr']     ?? '--:--', _selectedTimeZone),
        'Maghrib': _adjustTimeByZone(timings['Maghrib'] ?? '--:--', _selectedTimeZone),
        'Isya'   : _adjustTimeByZone(timings['Isha']    ?? '--:--', _selectedTimeZone),
      };

      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen.withOpacity(0.8),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xEC0A0F1D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: Colors.black.withOpacity(0.24),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kCyan.withOpacity(0.8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0A0F1D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('⚠️ Session Expired', style: TextStyle(color: kWhite, fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(message, style: const TextStyle(color: kWhite54)),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
                child: const Text('OK', style: TextStyle(color: kCyan)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onNavTap(int index) {
    if (index >= 0 && index <= 3) {
      setState(() => _navIndex = index);
    }
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3:
        page = OwnerPage(
          sessionKey: sessionKey,
          username: username,
        );
        break;
      case 4:
        page = const TqtoPage();
        break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        );
      case 2:
        return PublicChatPage(username: username);
      case 3:
        return ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      case 5:
        return DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        );
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ─── CREDITS WIDGET ──────────────────────────────────────────────
  Widget _buildCreditsWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [kCyan, kPink, kPurple],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ).createShader(bounds),
            child: Text(
              _creditsDisplay.isEmpty ? ' ' : _creditsDisplay,
              style: TextStyle(
                color: kWhite,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
                shadows: [
                  Shadow(color: kCyan.withOpacity(0.6), blurRadius: 10),
                  Shadow(color: kPink.withOpacity(0.6), blurRadius: 10),
                  Shadow(color: kPurple.withOpacity(0.4), blurRadius: 6),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── WELCOME CARD ──────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.5),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kCyan.withOpacity(0.3)),
          boxShadow: [BoxShadow(color: kCyan.withOpacity(0.1), blurRadius: 12, spreadRadius: 2)],
        ),
        child: Row(
          children: [
            Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kCyan.withOpacity(0.15),
                border: Border.all(color: kCyan.withOpacity(0.5)),
              ),
              child: Center(
                child: Text(
                  username.isNotEmpty ? username[0].toUpperCase() : 'U',
                  style: const TextStyle(color: kWhite, fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome Back,',
                    style: TextStyle(color: kWhite54, fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 0.5),
                  ),
                  Text(
                    username,
                    style: const TextStyle(
                      color: kWhite,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                        decoration: BoxDecoration(
                          color: _roleColor(role).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(_roleIcon(role), color: _roleColor(role), size: 12),
                            const SizedBox(width: 4),
                            Text(
                              role.toUpperCase(),
                              style: TextStyle(color: _roleColor(role), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        'Session: ${sessionKey.length > 8 ? sessionKey.substring(0, 8) : sessionKey}',
                        style: TextStyle(color: kWhite54, fontSize: 10, fontFamily: 'ShareTechMono'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'EXPIRED',
                  style: TextStyle(color: kWhite54, fontSize: 8, fontFamily: 'Orbitron', letterSpacing: 0.5),
                ),
                Text(
                  expiredDate,
                  style: TextStyle(
                    color: kPink,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUTTON BUY PANEL ──────────────────────────────────────────────
  Widget _buildBuyButton() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: GestureDetector(
          onTap: () {
            _openUrl('https://t.me/botbotbot');
          },
          child: Container(
            height: 60,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset(
                    'assets/images/pterodactyl.png',
                    width: 32,
                    height: 32,
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'PROMO',
                        style: TextStyle(
                          color: Color(0xFFFF0800),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'SF Pro Text',
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Pterodactyl Panel',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'SF Pro Text',
                        ),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        'Beli server bot pribadi kamu sekarang',
                        style: TextStyle(
                          color: Color(0xFFA5B4C2),
                          fontSize: 11,
                          fontFamily: 'SF Pro Text',
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    color: Color(0xFFA5B4C2),
                    size: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── TQTO SECTION DENGAN FOTO ──────────────────────────────────────
  Widget _buildTqtoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded, color: kCyan, size: 20),
              const SizedBox(width: 8),
              const Text(
                'THANK TO',
                style: TextStyle(
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: kCyan.withOpacity(0.1),
                  border: Border.all(color: kCyan.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.people_rounded, color: kCyan, size: 12),
                    const SizedBox(width: 4),
                    Text(
                      '${_tqtoList.length}',
                      style: TextStyle(
                        color: kCyan,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 90,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: _tqtoList.length,
            itemBuilder: (context, index) {
              final item = _tqtoList[index];
              final String name = item['name'] as String;
              final String role2 = item['role'] as String;
              final String avatar = item['avatar'] as String;
              final bool isCreator = role2 == 'FOUNDER' || role2 == 'CREATOR' || role2 == 'CEO';
              
              return Container(
                width: 85,
                margin: const EdgeInsets.only(right: 12),
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: isCreator 
                      ? kCyan.withOpacity(0.08)
                      : Colors.white.withOpacity(0.02),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isCreator 
                        ? kCyan.withOpacity(0.25)
                        : kCyan.withOpacity(0.06),
                    width: isCreator ? 1 : 0.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isCreator 
                          ? kCyan.withOpacity(0.05)
                          : Colors.transparent,
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // ===== FOTO PROFIL =====
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isCreator 
                            ? kCyan.withOpacity(0.1)
                            : Colors.white.withOpacity(0.02),
                        border: Border.all(
                          color: isCreator 
                              ? kCyan.withOpacity(0.3)
                              : kCyan.withOpacity(0.08),
                          width: isCreator ? 1.2 : 0.6,
                        ),
                      ),
                      child: ClipOval(
                        child: avatar.isNotEmpty
                            ? Image.network(
                                avatar,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  color: isCreator 
                                      ? kCyan.withOpacity(0.1)
                                      : Colors.white.withOpacity(0.02),
                                  child: Center(
                                    child: Text(
                                      name.substring(0, 1),
                                      style: TextStyle(
                                        color: isCreator ? kCyan : Colors.white.withOpacity(0.3),
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : Container(
                                color: isCreator 
                                    ? kCyan.withOpacity(0.1)
                                    : Colors.white.withOpacity(0.02),
                                child: Center(
                                  child: Text(
                                    name.substring(0, 1),
                                    style: TextStyle(
                                      color: isCreator ? kCyan : Colors.white.withOpacity(0.3),
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 3),
                    // Name
                    Text(
                      name,
                      style: TextStyle(
                        color: isCreator ? kWhite : Colors.white.withOpacity(0.4),
                        fontWeight: FontWeight.w600,
                        fontSize: 8,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                    ),
                    // Role
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                      decoration: BoxDecoration(
                        color: isCreator 
                            ? kCyan.withOpacity(0.06)
                            : Colors.white.withOpacity(0.02),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        role2,
                        style: TextStyle(
                          color: isCreator 
                              ? kCyan.withOpacity(0.5)
                              : Colors.white.withOpacity(0.15),
                          fontSize: 5,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        // Tombol Lihat Semua
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                _slideRoute(const TqtoPage()),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: kCyan.withOpacity(0.03),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: kCyan.withOpacity(0.06),
                  width: 0.5,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.arrow_forward_rounded,
                    color: kCyan.withOpacity(0.3),
                    size: 10,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'LIHAT SEMUA KONTRIBUTOR',
                    style: TextStyle(
                      color: kCyan.withOpacity(0.3),
                      fontSize: 7,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    Icons.arrow_forward_rounded,
                    color: kCyan.withOpacity(0.3),
                    size: 10,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ─── UTAMA: HOMEPAGE ──────────────────────────────────────────────
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Container(
              color: Colors.transparent,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCreditsWidget(),
                  const SizedBox(height: 6),
                  _buildWelcomeCard(),
                  const SizedBox(height: 14),
                  _buildBannerVideo(),
                  const SizedBox(height: 10),
                  _buildBuyButton(),
                  const SizedBox(height: 14),
                  _buildLatestUpdates(),
                  const SizedBox(height: 14),
                  _buildTqtoSection(),
                  const SizedBox(height: 14),
                  _buildQuickActionsSection(),
                  const SizedBox(height: 14),
                  // ─── SOSIAL MEDIA BUTTON ───
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: SocialMediaButton(
                      username: username,
                      sessionKey: sessionKey,
                      role: role,
                      expiredDate: expiredDate,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _buildNewsSection(),
                  const SizedBox(height: 24),
                  Center(
                    child: Text('DarkMega',
                      style: TextStyle(
                        color: kCyan.withOpacity(0.25),
                        fontSize: 13, letterSpacing: 4,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── WIDGET BANNER VIDEO ──────────────────────────────────────────
  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: AnimatedBuilder(
        animation: _rgbBannerCtrl,
        builder: (context, child) {
          return CustomPaint(
            painter: _RgbBorderPainter(rotationValue: _rgbBannerCtrl.value * 2 * math.pi),
            child: Padding(
              padding: const EdgeInsets.all(2.5),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: AspectRatio(
                  aspectRatio: 16 / 9,
                  child: Container(
                    color: Colors.transparent,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                          FittedBox(
                            fit: BoxFit.cover,
                            child: SizedBox(
                              width: _menuVideoCtrl!.value.size.width,
                              height: _menuVideoCtrl!.value.size.height,
                              child: VideoPlayer(_menuVideoCtrl!),
                            ),
                          )
                        else
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [kBlue.withOpacity(0.2), kCyan.withOpacity(0.2)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                          ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.black.withOpacity(0.4),
                                Colors.transparent,
                                Colors.black.withOpacity(0.2),
                              ],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── LATEST UPDATES ──────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: kOrange, size: 22),
              const SizedBox(width: 8),
              const Text('LATEST UPDATES',
                  style: TextStyle(
                      color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                      fontFamily: 'Orbitron', letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kOrange.withOpacity(0.1),
                    border: Border.all(color: kOrange.withOpacity(0.2)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kOrange, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 140,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: PageView.builder(
                  key: ValueKey(_newsPageViewKey),
                  controller: _newsPageCtrl,
                  itemCount: newsList.length,
                  physics: const BouncingScrollPhysics(),
                  itemBuilder: (ctx, i) {
                    return Listener(
                      onPointerDown: (_) => _newsAutoScrollTimer?.cancel(),
                      onPointerUp: (_) => _startNewsAutoScroll(),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: _buildNewsCardHorizontal(newsList[i]),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 140,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: kBorder),
              child: const Center(
                  child: Text('No updates available', style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Stack(
        fit: StackFit.expand,
        children: [
          imgUrl.isNotEmpty
              ? Image.network(
                  imgUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                      child: Icon(Icons.image_not_supported, color: kWhite54, size: 40)),
                )
              : Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [kOrange.withOpacity(0.15), kCyan.withOpacity(0.05)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: const Center(child: Icon(Icons.article_rounded, color: kWhite24, size: 45)),
                ),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black87,
                  Colors.black45,
                  Colors.transparent,
                ],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),
          Positioned(
            top: 14,
            right: 14,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.black.withOpacity(0.4),
                    border: Border.all(color: kOrange.withOpacity(0.6), width: 1),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.circle, color: kOrange, size: 6),
                      SizedBox(width: 5),
                      Text(
                        'NEW',
                        style: TextStyle(
                          color: kOrange,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: kWhite,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      height: 1.3,
                      letterSpacing: 0.5,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.calendar_today_rounded, color: kWhite54, size: 11),
                          const SizedBox(width: 5),
                          Text(
                            date.length > 10 ? date.substring(0, 10) : (date.isNotEmpty ? date : 'Recent'),
                            style: const TextStyle(color: kWhite54, fontSize: 11),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kOrange.withOpacity(0.2),
                          border: Border.all(color: kOrange.withOpacity(0.4)),
                        ),
                        child: const Icon(Icons.arrow_forward_ios_rounded, color: kOrange, size: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── QUICK ACTIONS SECTION ────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: Icons.build_circle_outlined,
        bgIcon: Icons.terminal_rounded,
        title: 'Tools Gateway',
        subtitle: 'Security, OSINT & DDoS Control',
        gradient: [const Color(0xFFFF0800).withOpacity(0.6), const Color(0xFF800000).withOpacity(0.4)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos,
          )),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp as IconData,
        bgIcon: FontAwesomeIcons.whatsapp as IconData,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [kBlue.withOpacity(0.5), kPurple.withOpacity(0.5)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: Icons.storefront_rounded,
        bgIcon: Icons.shopping_bag_outlined,
        title: 'Marketplace',
        subtitle: 'Marketing tools & product center',
        gradient: [const Color(0xFFFF0800).withOpacity(0.6), const Color(0xFF800000).withOpacity(0.4)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(MarketingPage(sessionKey: sessionKey, role: role)),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.video as IconData,
        bgIcon: FontAwesomeIcons.video as IconData,
        title: 'Social Media',
        subtitle: 'Follow & Upload Video',
        gradient: [const Color(0xFFFF0800).withOpacity(0.6), const Color(0xFF800000).withOpacity(0.4)],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SocialMediaPage(
              username: username,
              sessionKey: sessionKey,
              role: role,
              expiredDate: expiredDate,
            ),
          ),
        ),
      ),
      _QuickActionData(
        icon: Icons.forum_rounded,
        bgIcon: Icons.chat_bubble_outline_rounded,
        title: 'Chat Private',
        subtitle: 'Global cyber community chat',
        gradient: [kPink.withOpacity(0.5), kPurple.withOpacity(0.5)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(ChatPage(sessionKey: sessionKey)),
        ),
      ),
      _QuickActionData(
        icon: Icons.public_rounded,
        bgIcon: Icons.language_rounded,
        title: 'Chat Public',
        subtitle: 'Global free public chat server',
        gradient: [const Color(0xFFFF0800).withOpacity(0.5), const Color(0xFF800000).withOpacity(0.4)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(PublicChatPage(username: username)),
        ),
      ),
      _QuickActionData(
        icon: Icons.shopping_bag_rounded,
        bgIcon: Icons.monetization_on_outlined,
        title: 'buy account',
        subtitle: 'Premium pricing & account levels',
        gradient: [kPurple.withOpacity(0.6), kPink.withOpacity(0.4)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(const BuyAccountPage()),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram as IconData,
        bgIcon: FontAwesomeIcons.telegram as IconData,
        title: 'Join Channel',
        subtitle: 'DarkMega Info Channel',
        gradient: [kCyan.withOpacity(0.5), kBlue.withOpacity(0.5)],
        onTap: () => _openUrl('https://t.me/AgungPride16'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran as IconData,
        bgIcon: FontAwesomeIcons.bookQuran as IconData,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran',
        gradient: [kPurple.withOpacity(0.5), const Color(0xFF001025).withOpacity(0.5)],
        onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv as IconData,
        bgIcon: FontAwesomeIcons.tv as IconData,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [kBlue.withOpacity(0.5), const Color(0xFF0A192F).withOpacity(0.5)],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
      _QuickActionData(
        icon: Icons.phone_android_rounded,
        bgIcon: Icons.phone_android_rounded,
        title: 'RAT Control',
        subtitle: 'Remote Device Manager',
        gradient: const [Color(0xFFFF8F00), Color(0xFFFFB300)],
        onTap: () => Navigator.push(context, _slideRoute(DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        ))),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: kYellow.withOpacity(0.12),
                  border: Border.all(color: kYellow.withOpacity(0.2)),
                ),
                child: const Icon(Icons.bolt_rounded, color: kYellow, size: 22),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('QUICK ACTIONS',
                      style: TextStyle(
                          color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                          fontFamily: 'Orbitron', letterSpacing: 1)),
                  Text('Beberapa Menu Tambahan',
                      style: TextStyle(color: kWhite54, fontSize: 12)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: kYellow.withOpacity(0.1),
                  border: Border.all(color: kYellow.withOpacity(0.2)),
                ),
                child: Row(children: [
                  Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: kYellow)),
                  const SizedBox(width: 5),
                  const Text('DarkMega',
                      style: TextStyle(color: kYellow, fontSize: 11, fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? kYellow : Colors.white12,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(
                colors: action.gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -12, bottom: -12,
                child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.05), size: 110),
              ),
              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 50, height: 50,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: Colors.white.withOpacity(0.15)),
                      child: Icon(action.icon, color: kWhite, size: 24),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                        onTap: action.onTap,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white.withOpacity(0.15)),
                          child: const Text('Tap →',
                              style: TextStyle(color: kWhite, fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(action.title,
                        style: const TextStyle(
                            color: kWhite, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
                    const SizedBox(height: 4),
                    Text(action.subtitle,
                        style: TextStyle(color: kWhite.withOpacity(0.7), fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── NEWS SECTION ──────────────────────────────────────────────────
  Widget _buildNewsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 190,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Container(
                color: const Color(0xFF1A0000),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFFFF0800).withOpacity(0.08),
                      Colors.transparent,
                      const Color(0xFFFF0800).withOpacity(0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 32, height: 32,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: kCyan.withOpacity(0.15),
                              ),
                              child: const Center(child: Icon(Icons.newspaper_rounded, color: kCyan, size: 18)),
                            ),
                            const SizedBox(width: 8),
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'BERITA UTAMA',
                                  style: TextStyle(
                                    color: kWhite,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  '10 Berita Terkini',
                                  style: TextStyle(color: kWhite54, fontSize: 9),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.black26,
                            border: Border.all(color: kCyan.withOpacity(0.3)),
                          ),
                          child: Text(
                            '${_horizontalNewsIndex + 1} / ${_mockNewsData.length}',
                            style: const TextStyle(
                              color: kCyan,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: PageView.builder(
                        controller: _horizontalNewsPageCtrl,
                        itemCount: _mockNewsData.length,
                        onPageChanged: (index) {
                          setState(() { _horizontalNewsIndex = index; });
                        },
                        itemBuilder: (context, index) {
                          final currentNews = _mockNewsData[index];
                          return Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.network(
                                    currentNews['image']!,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      color: Colors.white10,
                                      child: const Icon(Icons.broken_image_rounded, color: kWhite24, size: 30),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [Colors.black.withOpacity(0.7), Colors.black38, Colors.transparent],
                                        begin: Alignment.bottomCenter,
                                        end: Alignment.topCenter,
                                        stops: const [0.0, 0.5, 0.9],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 6,
                                    left: 6,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(12),
                                        color: currentNews['source'] == 'Metro TV' 
                                            ? const Color(0xFFFF0800).withOpacity(0.8) 
                                            : const Color(0xFF800000).withOpacity(0.8),
                                      ),
                                      child: Text(
                                        currentNews['source']!,
                                        style: const TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 6,
                                    left: 8,
                                    right: 8,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          currentNews['title']!,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                            shadows: [Shadow(color: Colors.black, blurRadius: 4)]
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          currentNews['date']!,
                                          style: const TextStyle(color: Colors.white70, fontSize: 8),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_mockNewsData.length, (index) {
                        final isCurrent = _horizontalNewsIndex == index;
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          height: 3,
                          width: isCurrent ? 12 : 4,
                          decoration: BoxDecoration(
                            color: isCurrent ? kCyan : Colors.white24,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/logo.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            color: Colors.black.withOpacity(0.3),
          ),
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 0.8,
                colors: [
                  Color(0xFFFF0800),
                  Colors.transparent,
                ],
              ),
            ),
          ),
          SafeArea(
            bottom: false,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 350),
              transitionBuilder: (child, anim) =>
                  FadeTransition(opacity: anim, child: child),
              child: KeyedSubtree(
                key: ValueKey(_navIndex),
                child: _buildCurrentPage(),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black.withOpacity(0.2),
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      titleSpacing: 0,
      flexibleSpace: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: kCyan.withOpacity(0.15))),
            ),
          ),
        ),
      ),
      title: Center(
        child: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [
              Color(0xFFFF0800),
              Color(0xFFFF4444),
              Color(0xFFFF8888),
              Color(0xFFFF0800),
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            _titleDisplay.isEmpty ? ' ' : _titleDisplay,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2.0,
              shadows: [
                Shadow(color: Color(0xFFFF0800), blurRadius: 15),
                Shadow(color: Color(0xFFFF4444), blurRadius: 25),
              ],
            ),
          ),
        ),
      ),
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ).then((_) {
            if (mounted && _newsPageCtrl.hasClients) {
              setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
              _newsPageCtrl.jumpToPage(0);
            }
          }),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(username,
                  style: const TextStyle(
                      color: kWhite, fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: kCyan.withOpacity(0.4), width: 1.5),
              color: kCyan.withOpacity(0.1),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(Icons.person_rounded, color: kCyan, size: 18),
            ),
          ),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => _openUrl('https://t.me/AgungPride16'),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── BOTTOM NAVIGATION BAR ────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: FontAwesomeIcons.whatsapp as IconData, label: 'Bug'),
      _NavItem(icon: Icons.public_rounded, label: 'Public'),
      _NavItem(icon: Icons.build_circle_outlined, label: 'Tools'),
    ];

    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(28),
        topRight: Radius.circular(28),
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          height: 72,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            border: Border(
              top: BorderSide(
                color: Colors.white.withOpacity(0.06),
                width: 0.8,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(items.length, (i) {
              final isActive = _navIndex == i;
              final activeColor = kCyan;
              return GestureDetector(
                onTap: () => _onNavTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: isActive
                        ? activeColor.withOpacity(0.15)
                        : Colors.transparent,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        items[i].icon,
                        color: isActive ? activeColor : Colors.white.withOpacity(0.35),
                        size: isActive ? 24 : 22,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        items[i].label,
                        style: TextStyle(
                          color: isActive ? activeColor : Colors.white.withOpacity(0.35),
                          fontSize: 10,
                          fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ─── DRAWER ─────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    final allowedRolesToOwnerPage = [
      'creator', 'developer', 'staf', 'exec', 'vvip', 'svip', 'owner', 'ceo', 'mod', 'pt'
    ];
    final bool hasOwnerPageAccess = allowedRolesToOwnerPage.contains(role.toLowerCase());

    return Drawer(
      backgroundColor: const Color(0xEA0A0F1D),
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black.withOpacity(0.24),
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.2), Colors.black.withOpacity(0.7)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kCyan.withOpacity(0.5), width: 2.0),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(Icons.person_rounded, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kCyan, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 16),
              children: [
                if (role == 'reseller')
                  _buildDrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      onTap: () => _onDrawerNav(1)),
                if (role == 'admin')
                  _buildDrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: 'Admin Page',
                      onTap: () => _onDrawerNav(2)),
                if (hasOwnerPageAccess)
                  _buildDrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Page',
                      onTap: () => _onDrawerNav(3)),
                _buildDrawerItem(
                  icon: Icons.cloud_queue_rounded,
                  label: 'Cek Cuaca',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      _slideRoute(WeatherPage(
                        sessionKey: sessionKey,
                        username: username,
                      )),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.history_rounded,
                  label: 'Riwayat Aktivitas',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                      if (mounted && _newsPageCtrl.hasClients) {
                        setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                        _newsPageCtrl.jumpToPage(0);
                      }
                    });
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.lock_outline_rounded,
                  label: 'Ganti Password',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: Icons.favorite_rounded,
                  label: 'TQTO',
                  onTap: () => _onDrawerNav(4),
                ),
                const SizedBox(height: 16),
                _buildDrawerItem(
                  icon: Icons.logout_rounded,
                  label: 'Keluar',
                  isLogout: true,
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                  },
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: kCyan.withOpacity(0.15))),
              color: Colors.black12,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.code_rounded, color: kCyan, size: 14),
                    SizedBox(width: 6),
                    Text(
                      'THANK TO',
                      style: TextStyle(
                        color: kWhite70,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _buildCreditRow('@Chs_caze', 'creator'),
                const SizedBox(height: 4),
                _buildCreditRow('@_-', 'ceo'),
                const SizedBox(height: 4),
                _buildCreditRow('@_-', 'ceo'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreditRow(String name, String roleLabel) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          name,
          style: const TextStyle(color: kWhite54, fontSize: 12, fontWeight: FontWeight.w500),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: roleLabel == 'ceo' ? kYellow.withOpacity(0.15) : kCyan.withOpacity(0.1),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: roleLabel == 'ceo' ? kYellow.withOpacity(0.4) : kCyan.withOpacity(0.3),
              width: 0.8,
            ),
          ),
          child: Text(
            roleLabel.toUpperCase(),
            style: TextStyle(
              color: roleLabel == 'ceo' ? kYellow : kCyan,
              fontSize: 8,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.1) : kCyan.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.2) : kCyan.withOpacity(0.2)),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : kCyan, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}