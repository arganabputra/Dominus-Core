// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_page.dart';
import 'profile_utils.dart';
import 'background_widget.dart';
import 'background_notifier.dart';
import 'app_theme.dart';

// ─── Palette (yellow-themed, mengikuti AppColors) ────────────────────────
class _C {
  static Color get bg          => AppColors.bg;
  static Color get bg2         => AppColors.cardDark;
  static Color get card        => AppColors.surface;
  static Color get card2       => AppColors.surfaceLight;
  static Color get border      => AppColors.accent3;
  static Color get purple      => AppColors.accent1;      // kuning utama
  static Color get purpleSoft  => AppColors.accent2;      // kuning medium
  static Color get purpleGlow  => AppColors.accent1;      // kuning terang
  static Color get purpleLight => AppColors.accent1;      // kuning muda
  static Color get text        => AppColors.textPrimary;
  static Color get textDim     => AppColors.textSec;
  static Color get textMute    => AppColors.textMuted;
  static const danger    = Color(0xFFFF5C7A);
  static const ok        = Color(0xFF6BE3A8);
  static const warn      = Color(0xFFFFC857);
  static const infoBlue  = Color(0xFF29B6F6);

  // Palet warna ikon field
  static const fieldColor1 = Color(0xFFFF4D8D); // pink
  static const fieldColor2 = Color(0xFFFFA726); // orange
  static const fieldColor3 = Color(0xFF4CAF50); // hijau
  static const fieldColor4 = Color(0xFFFFD600); // kuning (updated)
}

const String _kBaseUrl = 'http://rizqy.smasnug.web.id:10003/api/user';

// ─── ProfilePage ─────────────────────────────────────────────────────────
class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String ratId;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.ratId,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  late final AnimationController _bgCtrl;
  late final AnimationController _entryCtrl;
  late final AnimationController _glowCtrl;

  bool _showPassword = false;

  // Stats
  int  _deviceOnline  = 0;
  int  _userOnline    = 0;
  bool _statsLoading  = true;

  // Profile Image (local storage)
  File? _selectedProfileImage;
  bool  _isLoadingProfileImage = false;

  // Identity (from server)
  final _displayCtrl = TextEditingController();
  final _emailCtrl   = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _bioCtrl     = TextEditingController();

  // Security (change password)
  final _oldPassCtrl     = TextEditingController();
  final _newPassCtrl     = TextEditingController();
  final _confirmPassCtrl = TextEditingController();

  bool _showOld = false, _showNew = false, _showConfirm = false;
  int  _strength = 0;

  // Remote avatar (from server profile API)
  String? _remoteAvatarUrl;

  bool _loadingProfile = true;
  bool _savingProfile  = false;
  bool _changingPass   = false;

  @override
  void initState() {
    super.initState();
    _bgCtrl    = AnimationController(vsync: this, duration: const Duration(seconds: 30))..repeat();
    _entryCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _glowCtrl  = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);

    _newPassCtrl.addListener(() {
      setState(() => _strength = _scorePassword(_newPassCtrl.text));
    });

    _fetchStats();
    _loadLocalProfileImage();
    _loadServerProfile();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entryCtrl.dispose();
    _glowCtrl.dispose();
    _displayCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _bioCtrl.dispose();
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  // ── API calls ─────────────────────────────────────────────────────────
  Future<void> _fetchStats() async {
    setState(() => _statsLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBaseUrl/profileStats?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _deviceOnline  = (data['deviceOnline']  as num?)?.toInt() ?? 0;
          _userOnline    = (data['userOnline']     as num?)?.toInt() ?? 0;
          _statsLoading  = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _statsLoading = false);
    }
  }

  Future<void> _loadServerProfile() async {
    setState(() => _loadingProfile = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBaseUrl/profile?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true && data['profile'] != null) {
        final p = data['profile'] as Map<String, dynamic>;
        _displayCtrl.text = (p['displayName'] ?? '').toString();
        _emailCtrl.text   = (p['email']       ?? '').toString();
        _phoneCtrl.text   = (p['phone']       ?? '').toString();
        _bioCtrl.text     = (p['bio']         ?? '').toString();
        _remoteAvatarUrl  = p['avatarUrl'] as String?;
      }
    } catch (_) {/* keep blank */}
    if (mounted) setState(() => _loadingProfile = false);
  }

  Future<void> _loadLocalProfileImage() async {
    try {
      final imageFile = await ProfileImageUtils.getProfileImageFile();
      if (imageFile != null && mounted) {
        setState(() => _selectedProfileImage = imageFile);
      }
    } catch (e) {
      debugPrint('Error loading profile image: $e');
    }
  }

  Future<void> _saveProfile() async {
    setState(() => _savingProfile = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$_kBaseUrl/profile'))
        ..fields['key']         = widget.sessionKey
        ..fields['username']    = widget.username
        ..fields['displayName'] = _displayCtrl.text.trim()
        ..fields['bio']         = _bioCtrl.text.trim();

      if (_selectedProfileImage != null) {
        req.files.add(await http.MultipartFile.fromPath('avatar', _selectedProfileImage!.path));
      }

      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['success'] == true) {
        if (data['profile']?['avatarUrl'] != null) {
          setState(() => _remoteAvatarUrl = data['profile']['avatarUrl'] as String);
        }
        _toast('Profil berhasil disimpan ✅');
      } else {
        _toast((data['message'] ?? 'Gagal menyimpan').toString(), err: true);
      }
    } catch (e) {
      _toast('Error jaringan', err: true);
    } finally {
      if (mounted) setState(() => _savingProfile = false);
    }
  }

  Future<void> _changePassword() async {
    final oldP = _oldPassCtrl.text.trim();
    final newP = _newPassCtrl.text.trim();
    final cnf  = _confirmPassCtrl.text.trim();

    if (oldP.isEmpty || newP.isEmpty || cnf.isEmpty) {
      _toast('Semua field password harus diisi', err: true);
      return;
    }
    if (newP != cnf) {
      _toast('Password baru tidak cocok', err: true);
      return;
    }
    if (newP == oldP) {
      _toast('Password baru harus berbeda', err: true);
      return;
    }
    if (_strength < 3) {
      final ok = await _confirmWeakPassword();
      if (!ok) return;
    }

    setState(() => _changingPass = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBaseUrl/changepass'),
        body: {
          'username': widget.username,
          'oldPass':  oldP,
          'newPass':  newP,
          'key':      widget.sessionKey,
        },
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        _oldPassCtrl.clear();
        _newPassCtrl.clear();
        _confirmPassCtrl.clear();
        _toast('Password berhasil diubah ✅');
      } else {
        _toast((data['message'] ?? 'Gagal mengubah password').toString(), err: true);
      }
    } catch (e) {
      _toast('Error jaringan', err: true);
    } finally {
      if (mounted) setState(() => _changingPass = false);
    }
  }

  Future<bool> _confirmWeakPassword() async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _WeakPasswordSheet(),
    );
    return r == true;
  }

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ConfirmDialog(
        title: 'Keluar',
        message: 'Yakin mau keluar dari akun ini?',
        confirmLabel: 'Keluar',
        confirmColor: _C.danger,
        icon: Icons.logout_rounded,
      ),
    );
    if (confirm != true) return;
    // Reset theme (warna, slider, dll) ke default sebelum logout
    if (mounted) {
      final themeNotifier = ThemeScope.of(context);
      final bgNotifier    = BackgroundScope.of(context);
      await themeNotifier.reset();
      await bgNotifier.reset();
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (r) => false,
    );
  }

  // ── Profile image ─────────────────────────────────────────────────────
  void _showChangeProfileImageDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 32),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: _C.card.withOpacity(0.97),
                border: Border.all(color: _C.purpleGlow.withOpacity(0.4)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.purpleGlow.withOpacity(0.12),
                      border: Border.all(color: _C.purpleGlow.withOpacity(0.4)),
                    ),
                    child: Icon(Icons.image_rounded, color: _C.purpleGlow, size: 28),
                  ),
                  SizedBox(height: 16),
                  Text('GANTI FOTO PROFIL',
                    style: TextStyle(color: _C.text, fontSize: 15,
                        fontWeight: FontWeight.w900, letterSpacing: 2)),
                  SizedBox(height: 8),
                  Text('Pilih sumber untuk foto profil baru',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: _C.textDim.withOpacity(0.8), fontSize: 13)),
                  SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(child: _dialogBtn('GALERI', _C.purpleGlow, () {
                        Navigator.pop(context);
                        _pickAndSaveProfileImage(ImageSource.gallery);
                      })),
                      SizedBox(width: 12),
                      Expanded(child: _dialogBtn('KAMERA', _C.purpleGlow, () {
                        Navigator.pop(context);
                        _pickAndSaveProfileImage(ImageSource.camera);
                      })),
                    ],
                  ),
                  if (_selectedProfileImage != null) ...[
                    const SizedBox(height: 12),
                    _dialogBtn('HAPUS FOTO', _C.danger, () {
                      Navigator.pop(context);
                      _deleteProfileImage();
                    }, color: _C.danger),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _dialogBtn(String label, Color borderColor, VoidCallback onTap, {Color? color}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: (color ?? borderColor).withOpacity(0.15),
          border: Border.all(color: (color ?? borderColor).withOpacity(0.5)),
        ),
        child: Center(
          child: Text(label, style: TextStyle(
            color: color ?? borderColor,
            fontWeight: FontWeight.w900,
            fontSize: 13, letterSpacing: 1,
          )),
        ),
      ),
    );
  }

  Future<void> _pickAndSaveProfileImage(ImageSource source) async {
    try {
      setState(() => _isLoadingProfileImage = true);
      final imageFile = await ProfileImageUtils.pickProfileImage(source: source);
      if (imageFile != null) {
        final saved = await ProfileImageUtils.saveProfileImage(imageFile);
        if (saved && mounted) {
          setState(() {
            _selectedProfileImage = imageFile;
            _isLoadingProfileImage = false;
          });
          HapticFeedback.selectionClick();
          _toast('Foto profil berhasil diubah ✅');
        }
      } else {
        if (mounted) setState(() => _isLoadingProfileImage = false);
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
      if (mounted) {
        setState(() => _isLoadingProfileImage = false);
        _toast('Gagal mengubah foto profil', err: true);
      }
    }
  }

  Future<void> _deleteProfileImage() async {
    try {
      final deleted = await ProfileImageUtils.deleteProfileImage();
      if (deleted && mounted) {
        setState(() => _selectedProfileImage = null);
        HapticFeedback.selectionClick();
        _toast('Foto profil dihapus');
      }
    } catch (e) {
      debugPrint('Error deleting image: $e');
    }
  }

  void _copyRatId() {
    Clipboard.setData(ClipboardData(text: widget.ratId));
    HapticFeedback.lightImpact();
    _toast('RAT ID disalin!');
  }

  // ── Helpers ──────────────────────────────────────────────────────────
  Color _roleColor() {
    switch (widget.role.toLowerCase()) {
      case 'owner':    return const Color(0xFF5A5A62);
      case 'vip':      return const Color(0xFF4A4A52);
      case 'reseller': return const Color(0xFF3A3A42);
      default:         return const Color(0xFF2A2A30);
    }
  }

  String _roleTitle() {
    switch (widget.role.toLowerCase()) {
      case 'owner':    return 'Owner';
      case 'vip':      return 'VIP';
      case 'reseller': return 'Reseller';
      default:         return 'Member';
    }
  }

  int _scorePassword(String p) {
    if (p.isEmpty) return 0;
    int s = 0;
    if (p.length >= 8)                        s++;
    if (p.length >= 12)                       s++;
    if (RegExp(r'[A-Z]').hasMatch(p))         s++;
    if (RegExp(r'[0-9]').hasMatch(p))         s++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(p)) s++;
    return s.clamp(0, 5);
  }

  String _strengthLabel() => switch (_strength) {
    0 => '—', 1 => 'SANGAT LEMAH', 2 => 'LEMAH',
    3 => 'CUKUP', 4 => 'KUAT', _ => 'SANGAT KUAT',
  };

  Color _strengthColor() => switch (_strength) {
    0 || 1 => _C.danger,
    2      => Colors.orange,
    3      => _C.warn,
    4      => _C.ok,
    _      => _C.purpleLight,
  };

  void _toast(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: err ? _C.danger.withOpacity(0.9) : _C.card,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: (err ? _C.danger : _C.border).withOpacity(0.5)),
      ),
      content: Text(msg, style: TextStyle(color: err ? Colors.white : _C.text, fontSize: 13)),
      duration: const Duration(seconds: 2),
    ));
  }

  Widget _slide(int idx, Widget child) {
    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, __) {
        final stagger = (idx * 0.08).clamp(0.0, 0.6);
        final raw = ((_entryCtrl.value - stagger) / (1 - stagger)).clamp(0.0, 1.0);
        final t = Curves.easeOutCubic.transform(raw);
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, (1 - t) * 20), child: child),
        );
      },
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: BackgroundWrapper(
        child: Stack(
          children: [
            // Animated purple background orbs
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _bgCtrl,
                builder: (_, __) => CustomPaint(painter: _BgPainter(t: _bgCtrl.value)),
              ),
            ),
            // Dark overlay
            Positioned.fill(
              child: Container(color: Colors.black.withOpacity(0.5)),
            ),
            // Content
            SafeArea(
              child: FadeTransition(
                opacity: _entryCtrl,
                child: Column(
                  children: [
                    _buildTopBar(),
                    Expanded(
                      child: _loadingProfile
                          ? Center(child: CircularProgressIndicator(color: _C.purpleLight))
                          : SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                              child: Column(
                                children: [
                                  _slide(0, _buildAvatar()),
                                  const SizedBox(height: 20),
                                  _slide(1, _buildStatsCard()),
                                  const SizedBox(height: 16),
                                  _slide(2, _buildInfoCard()),
                                  const SizedBox(height: 16),
                                  _slide(3, _identityCard()),
                                  const SizedBox(height: 12),
                                  _slide(4, _saveProfileBtn()),
                                  const SizedBox(height: 24),
                                  _slide(5, _securityCard()),
                                  const SizedBox(height: 12),
                                  _slide(6, _changePassBtn()),
                                  const SizedBox(height: 16),
                                  _slide(7, _buildBottomActions()),
                                  const SizedBox(height: 32),
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Top bar ──────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.08),
                border: Border.all(color: Colors.white.withOpacity(0.2)),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded, color: _C.text, size: 16),
            ),
          ),
          const Spacer(),
          const Text('PROFILE • SETTINGS',
            style: TextStyle(color: Colors.white, fontSize: 13,
                fontWeight: FontWeight.w900, letterSpacing: 3)),
          const Spacer(),
          const SizedBox(width: 40),
        ],
      ),
    );
  }

  // ── Avatar ───────────────────────────────────────────────────────────
  Widget _buildAvatar() {
    final roleColor = _roleColor();
    return Column(
      children: [
        AnimatedBuilder(
          animation: _glowCtrl,
          builder: (_, child) => Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: SweepGradient(
                colors: [roleColor, roleColor.withOpacity(0.4), roleColor],
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.purpleGlow.withOpacity(0.20 + _glowCtrl.value * 0.20),
                  blurRadius: 24 + _glowCtrl.value * 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: child,
          ),
          child: GestureDetector(
            onTap: _isLoadingProfileImage ? null : _showChangeProfileImageDialog,
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                Container(
                  width: 110, height: 110,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: _C.card),
                  clipBehavior: Clip.antiAlias,
                  child: _isLoadingProfileImage
                      ? Center(child: CircularProgressIndicator(color: _C.purpleGlow, strokeWidth: 2))
                      : (_selectedProfileImage != null)
                          ? Image.file(_selectedProfileImage!, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(Icons.person_rounded, color: _C.textMute, size: 48))
                          : (_remoteAvatarUrl != null && _remoteAvatarUrl!.isNotEmpty)
                              ? Image.network(_remoteAvatarUrl!, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Icon(Icons.person_rounded, color: _C.textMute, size: 48))
                              : Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Icon(Icons.person_rounded, color: _C.textMute, size: 48)),
                ),
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [_C.purple, _C.purpleGlow]),
                    border: Border.all(color: _C.bg, width: 2),
                    boxShadow: [BoxShadow(color: _C.purpleGlow.withOpacity(0.5), blurRadius: 8)],
                  ),
                  child: const Icon(Icons.camera_alt, color: Colors.white, size: 16),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 14),
        Text(
          _displayCtrl.text.trim().isEmpty ? widget.username : _displayCtrl.text.trim(),
          style: TextStyle(color: _C.text, fontSize: 20,
              fontWeight: FontWeight.w900, letterSpacing: 1.5),
        ),
        SizedBox(height: 4),
        Text('@${widget.username}',
          style: TextStyle(color: _C.textMute, fontSize: 12, fontFamily: 'monospace')),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: roleColor.withOpacity(0.12),
            border: Border.all(color: roleColor.withOpacity(0.5)),
          ),
          child: Text(_roleTitle().toUpperCase(),
            style: TextStyle(color: roleColor, fontSize: 10,
                fontWeight: FontWeight.w900, letterSpacing: 2)),
        ),
      ],
    );
  }

  // ── Stats card ────────────────────────────────────────────────────────
  Widget _buildStatsCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white.withOpacity(0.05),
            border: Border.all(color: _C.border.withOpacity(0.6)),
          ),
          child: _statsLoading
              ? Center(child: SizedBox(height: 32, width: 32,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _C.purpleGlow)))
              : Row(children: [
                  Expanded(child: _statItem(
                    value: _deviceOnline.toString(),
                    label: 'DEVICE', sublabel: 'ONLINE',
                    color: const Color(0xFF22E07A), icon: Icons.phone_android_rounded,
                  )),
                  _statDivider(),
                  Expanded(child: _statItem(
                    value: _userOnline.toString(),
                    label: 'USER', sublabel: 'ONLINE',
                    color: const Color(0xFF29B6F6), icon: Icons.people_rounded,
                  )),
                ]),
        ),
      ),
    );
  }

  Widget _statItem({required String value, required String label,
      required String sublabel, required Color color, required IconData icon}) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(0.12),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Icon(icon, color: color, size: 16),
      ),
      SizedBox(height: 8),
      Text(value, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w900)),
      Text('$label\n$sublabel', textAlign: TextAlign.center,
        style: TextStyle(color: _C.textMute, fontSize: 9, letterSpacing: 1.2, height: 1.3)),
    ]);
  }

  Widget _statDivider() {
    return Container(
      width: 1, height: 60,
      color: _C.border.withOpacity(0.5),
      margin: const EdgeInsets.symmetric(horizontal: 4),
    );
  }

  // ── Account Info card ─────────────────────────────────────────────────
  Widget _buildInfoCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white.withOpacity(0.07),
            border: Border.all(color: Colors.white.withOpacity(0.13)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _C.infoBlue.withOpacity(0.2),
                  border: Border.all(color: _C.infoBlue.withOpacity(0.4)),
                ),
                child: const Icon(Icons.info_outline_rounded, color: _C.infoBlue, size: 16),
              ),
              const SizedBox(width: 10),
              const Text('INFORMASI AKUN', style: TextStyle(
                color: Colors.white, fontSize: 12, letterSpacing: 1.8, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 16),
            _infoRow(icon: Icons.alternate_email_rounded,
                iconColor: const Color(0xFFFF6B6B), label: 'Username', value: widget.username),
            const SizedBox(height: 10),
            _passwordRow(),
            const SizedBox(height: 10),
            _ratIdRow(),
          ]),
        ),
      ),
    );
  }

  Widget _infoRow({required IconData icon, required Color iconColor,
      required String label, required String value}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),
              color: iconColor.withOpacity(0.15)),
          child: Icon(icon, color: iconColor, size: 16),
        ),
        SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: _C.textMute, fontSize: 10, letterSpacing: 1)),
          SizedBox(height: 2),
          Text(value, style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w700)),
        ])),
      ]),
    );
  }

  Widget _passwordRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),
              color: const Color(0xFF22E07A).withOpacity(0.15)),
          child: Icon(Icons.lock_outline_rounded, color: Color(0xFF22E07A), size: 16),
        ),
        SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Password', style: TextStyle(color: _C.textMute, fontSize: 10, letterSpacing: 1)),
          SizedBox(height: 2),
          Text(_showPassword ? widget.password : '••••••••',
              style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w700)),
        ])),
        GestureDetector(
          onTap: () { HapticFeedback.selectionClick(); setState(() => _showPassword = !_showPassword); },
          child: Container(
            width: 32, height: 32,
            decoration: BoxDecoration(shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.06),
                border: Border.all(color: _C.border.withOpacity(0.4))),
            child: Icon(_showPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                color: _C.textMute, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _ratIdRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),
              color: _C.purpleGlow.withOpacity(0.15)),
          child: Icon(Icons.fingerprint_rounded, color: _C.purpleGlow, size: 16),
        ),
        SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('RAT ID', style: TextStyle(color: _C.textMute, fontSize: 10, letterSpacing: 1)),
          SizedBox(height: 2),
          Text(widget.ratId.isEmpty ? 'N/A' : widget.ratId,
              style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w700),
              overflow: TextOverflow.ellipsis),
        ])),
        GestureDetector(
          onTap: _copyRatId,
          child: Container(
            width: 32, height: 32,
            decoration: BoxDecoration(shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.06),
                border: Border.all(color: _C.border.withOpacity(0.4))),
            child: Icon(Icons.copy_rounded, color: _C.textMute, size: 15),
          ),
        ),
      ]),
    );
  }

  // ── Identity card (edit profile) ──────────────────────────────────────
  Widget _identityCard() {
    return _glassCard(
      icon: Icons.badge_outlined,
      title: 'IDENTITY',
      child: Column(children: [
        _field(label: 'Display Name', hint: 'Nama yang tampil ke orang lain',
            icon: Icons.person_outline, controller: _displayCtrl,
            iconColor: _C.fieldColor1,
            boxedIcon: true,
            onChanged: (_) => setState(() {})),
        const SizedBox(height: 14),
        _field(label: 'Bio', hint: 'Deskripsi singkat tentang kamu',
            icon: Icons.short_text, controller: _bioCtrl, maxLines: 3,
            iconColor: _C.fieldColor4,
            boxedIcon: true),
      ]),
    );
  }

  Widget _saveProfileBtn() {
    return _GradientButton(
      label: _savingProfile ? 'MENYIMPAN…' : 'SIMPAN PROFIL',
      icon: _savingProfile ? null : Icons.save_outlined,
      busy: _savingProfile,
      onTap: _savingProfile ? null : _saveProfile,
    );
  }

  // ── Security card (change password) ───────────────────────────────────
  Widget _securityCard() {
    return _glassCard(
      icon: Icons.lock_outline,
      title: 'UBAH PASSWORD',
      child: Column(children: [
        _field(label: 'Password Lama', hint: 'Masukkan password saat ini',
            icon: Icons.lock_clock_outlined, controller: _oldPassCtrl,
            obscure: !_showOld,
            iconColor: _C.fieldColor1,
            boxedIcon: true,
            suffix: IconButton(
              icon: Icon(_showOld ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showOld = !_showOld),
            )),
        const SizedBox(height: 14),
        _field(label: 'Password Baru', hint: 'Minimal 8 karakter',
            icon: Icons.password_outlined, controller: _newPassCtrl,
            obscure: !_showNew,
            iconColor: _C.fieldColor2,
            boxedIcon: true,
            suffix: IconButton(
              icon: Icon(_showNew ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showNew = !_showNew),
            )),
        if (_newPassCtrl.text.isNotEmpty) ...[
          const SizedBox(height: 10),
          _strengthMeter(),
        ],
        const SizedBox(height: 14),
        _field(label: 'Konfirmasi Password', hint: 'Ulangi password baru',
            icon: Icons.check_circle_outline, controller: _confirmPassCtrl,
            obscure: !_showConfirm,
            iconColor: _C.fieldColor3,
            boxedIcon: true,
            suffix: IconButton(
              icon: Icon(_showConfirm ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showConfirm = !_showConfirm),
            )),
        if (_newPassCtrl.text.isNotEmpty &&
            _confirmPassCtrl.text.isNotEmpty &&
            _newPassCtrl.text != _confirmPassCtrl.text) ...[
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.error_outline, color: _C.danger, size: 14),
            const SizedBox(width: 6),
            Text('Password tidak cocok', style: TextStyle(color: _C.danger, fontSize: 11)),
          ]),
        ],
      ]),
    );
  }

  Widget _strengthMeter() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: List.generate(5, (i) {
        final filled = i < _strength;
        return Expanded(child: Container(
          margin: EdgeInsets.only(right: i == 4 ? 0 : 4),
          height: 4,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(2),
            color: filled ? _strengthColor() : _C.border.withOpacity(0.4),
          ),
        ));
      })),
      SizedBox(height: 6),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('KEKUATAN', style: TextStyle(color: _C.textMute, fontSize: 9.5, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
        Text(_strengthLabel(), style: TextStyle(color: _strengthColor(), fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.w800)),
      ]),
    ]);
  }

  Widget _changePassBtn() {
    return _GradientButton(
      label: _changingPass ? 'MENGUBAH…' : 'UBAH PASSWORD',
      icon: _changingPass ? null : Icons.shield_outlined,
      busy: _changingPass,
      onTap: _changingPass ? null : _changePassword,
    );
  }

  // ── Bottom action buttons ─────────────────────────────────────────────
  Widget _buildBottomActions() {
    return Row(children: [
      Expanded(child: _actionButton(
        icon: Icons.home_rounded, label: 'Dashboard',
        onTap: () => Navigator.pop(context),
        color: _C.text, bgColor: Colors.white.withOpacity(0.07),
        borderColor: _C.border.withOpacity(0.5),
      )),
      const SizedBox(width: 10),
      Expanded(child: _actionButton(
        icon: Icons.logout_rounded, label: 'Keluar',
        onTap: _logout,
        color: _C.danger, bgColor: _C.danger.withOpacity(0.08),
        borderColor: _C.danger.withOpacity(0.4),
      )),
    ]);
  }

  Widget _actionButton({
    required IconData icon, required String label,
    required VoidCallback onTap, required Color color,
    required Color bgColor, required Color borderColor,
  }) {
    return GestureDetector(
      onTap: () { HapticFeedback.selectionClick(); onTap(); },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: Container(
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: bgColor,
              border: Border.all(color: borderColor),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 8),
              Text(label, style: TextStyle(color: color, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1)),
            ]),
          ),
        ),
      ),
    );
  }

  // ── Shared widgets ────────────────────────────────────────────────────
  Widget _glassCard({required IconData icon, required String title, required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white.withOpacity(0.07),
            border: Border.all(color: Colors.white.withOpacity(0.13)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _C.infoBlue.withOpacity(0.2),
                  border: Border.all(color: _C.infoBlue.withOpacity(0.4)),
                ),
                child: Icon(icon, color: _C.infoBlue, size: 16),
              ),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 12,
                  letterSpacing: 1.8, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 16),
            child,
          ]),
        ),
      ),
    );
  }

  Widget _field({
    required String label, required String hint,
    required IconData icon, required TextEditingController controller,
    bool obscure = false, int maxLines = 1,
    TextInputType? keyboardType, Widget? suffix,
    void Function(String)? onChanged,
    Color? iconColor,
    bool boxedIcon = false,
  }) {
    final resolvedIconColor = iconColor ?? _C.purpleGlow;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 6),
        child: Text(label.toUpperCase(),
            style: TextStyle(color: _C.textDim, fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.w600)),
      ),
      TextField(
        controller: controller,
        obscureText: obscure,
        maxLines: obscure ? 1 : maxLines,
        keyboardType: keyboardType,
        onChanged: onChanged,
        style: TextStyle(color: _C.text, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: _C.textMute, fontSize: 13),
          prefixIcon: boxedIcon
              ? Padding(
                  padding: const EdgeInsets.all(9),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: resolvedIconColor.withOpacity(0.18),
                      border: Border.all(color: resolvedIconColor.withOpacity(0.4)),
                    ),
                    child: Icon(icon, color: resolvedIconColor, size: 16),
                  ),
                )
              : Icon(icon, color: resolvedIconColor, size: 18),
          suffixIcon: suffix,
          filled: true,
          fillColor: Colors.white.withOpacity(0.06),
          contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.10))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.10))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: resolvedIconColor.withOpacity(0.7), width: 1.4)),
        ),
      ),
    ]);
  }
}

// ─── Gradient Button ──────────────────────────────────────────────────────
class _GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool busy;
  final VoidCallback? onTap;
  const _GradientButton({required this.label, required this.icon,
      required this.busy, required this.onTap  super.key,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: Colors.white.withOpacity(0.07),
              border: Border.all(
                color: Colors.white.withOpacity(enabled ? 0.16 : 0.10),
              ),
            ),
            child: Center(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                if (busy)
                  const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                else if (icon != null)
                  Icon(icon, color: Colors.white, size: 18),
                const SizedBox(width: 10),
                Text(label, style: const TextStyle(color: Colors.white, fontSize: 13,
                    letterSpacing: 1.6, fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Weak Password Sheet ──────────────────────────────────────────────────
class _WeakPasswordSheet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: _C.purpleSoft, width: 0.6)),
      ),
      child: SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 38, height: 4,
            decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.warn.withOpacity(0.12),
            border: Border.all(color: _C.warn.withOpacity(0.5)),
          ),
          child: Icon(Icons.warning_amber_rounded, color: _C.warn, size: 32),
        ),
        SizedBox(height: 14),
        Text('PASSWORD LEMAH', style: TextStyle(color: _C.text, fontSize: 14,
            letterSpacing: 1.8, fontWeight: FontWeight.w800)),
        SizedBox(height: 8),
        Text('Password barumu mudah ditebak. Tambah panjang, campuran huruf, angka, dan simbol.',
            textAlign: TextAlign.center,
            style: TextStyle(color: _C.textDim, fontSize: 12.5, height: 1.5)),
        const SizedBox(height: 22),
        Row(children: [
          Expanded(child: GestureDetector(
            onTap: () => Navigator.pop(context, false),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.border), color: _C.bg2),
              child: Center(child: Text('BATAL', style: TextStyle(
                  color: _C.textDim, fontWeight: FontWeight.w700, letterSpacing: 1.4, fontSize: 12))),
            ),
          )),
          const SizedBox(width: 10),
          Expanded(child: GestureDetector(
            onTap: () => Navigator.pop(context, true),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
                  gradient: LinearGradient(colors: [_C.purpleSoft, _C.purpleGlow])),
              child: const Center(child: Text('LANJUT', style: TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1.4, fontSize: 12))),
            ),
          )),
        ]),
      ])),
    );
  }
}

// ─── Confirm Dialog ───────────────────────────────────────────────────────
class _ConfirmDialog extends StatelessWidget {
  final String title, message, confirmLabel;
  final Color confirmColor;
  final IconData icon;
  const _ConfirmDialog({required this.title, required this.message,
      required this.confirmLabel, required this.confirmColor, required this.icon  super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 32),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _C.card.withOpacity(0.95),
              border: Border.all(color: confirmColor.withOpacity(0.4)),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(shape: BoxShape.circle,
                    color: confirmColor.withOpacity(0.12),
                    border: Border.all(color: confirmColor.withOpacity(0.4))),
                child: Icon(icon, color: confirmColor, size: 28),
              ),
              SizedBox(height: 16),
              Text(title.toUpperCase(), style: TextStyle(color: _C.text,
                  fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 2)),
              SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center,
                  style: TextStyle(color: _C.textDim.withOpacity(0.8), fontSize: 13)),
              const SizedBox(height: 22),
              Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.pop(context, false),
                  child: Container(height: 44,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
                        color: Colors.white.withOpacity(0.06),
                        border: Border.all(color: _C.border.withOpacity(0.5))),
                    child: Center(child: Text('Batal', style: TextStyle(
                        color: _C.text, fontWeight: FontWeight.w700, fontSize: 13))),
                  ),
                )),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.pop(context, true),
                  child: Container(height: 44,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
                        color: confirmColor.withOpacity(0.15),
                        border: Border.all(color: confirmColor.withOpacity(0.5))),
                    child: Center(child: Text(confirmLabel, style: TextStyle(
                        color: confirmColor, fontWeight: FontWeight.w900,
                        fontSize: 13, letterSpacing: 1))),
                  ),
                )),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── Animated Background Painter ─────────────────────────────────────────
class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter({required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(7);
    for (int i = 0; i < 4; i++) {
      final cx = (rng.nextDouble() + math.sin((t + i * 0.3) * 6.28) * 0.15) * size.width;
      final cy = (rng.nextDouble() + math.cos((t + i * 0.5) * 6.28) * 0.15) * size.height;
      final r  = 80 + rng.nextDouble() * 80;
      final p = Paint()
        ..shader = RadialGradient(colors: [
          _C.purpleSoft.withOpacity(0.15),
          _C.purpleSoft.withOpacity(0),
        ]).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r));
      canvas.drawCircle(Offset(cx, cy), r, p);
    }
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) => old.t != t;
}
