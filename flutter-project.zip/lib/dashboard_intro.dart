import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'app_theme.dart';
import 'background_widget.dart';
import 'background_notifier.dart';
import 'dashboard_page.dart';

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
// Sama persis seperti di kode yang dikirim (GridPatternPainter)
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;

  const _GridPatternPainter({
    required this.gridColor,
    required this.lineColor,
    required this.spacing,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 0.5;

    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 0.3;

    // Garis horizontal
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    // Garis vertikal
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), linePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPatternPainter old) =>
      old.gridColor != gridColor ||
      old.lineColor != lineColor ||
      old.spacing != spacing;
}

// ─── DASHBOARD WITH INTRO ─────────────────────────────────────────────────────
// Wrapper: tampilkan intro splash dulu, lalu navigate ke DashboardPage.
// Gunakan class ini di router / login_page sebagai pengganti DashboardPage.
class DashboardWithIntro extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardWithIntro({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardWithIntro> createState() => _DashboardWithIntroState();
}

class _DashboardWithIntroState extends State<DashboardWithIntro>
    with SingleTickerProviderStateMixin {
  // ── State intro ────────────────────────────────────────────────────────────
  bool _introDone = false;

  // ── Animasi ────────────────────────────────────────────────────────────────
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();

    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic);
    _scaleAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack),
    );

    _ctrl.forward();

    // Auto lanjut ke dashboard setelah 2.8 detik
    Future.delayed(const Duration(milliseconds: 2800), _goToDashboard);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  // ── Transisi ke dashboard ──────────────────────────────────────────────────
  void _goToDashboard() {
    if (!mounted || _introDone) return;
    _ctrl.reverse().then((_) {
      if (mounted) setState(() => _introDone = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    // Kalau intro sudah selesai → langsung render DashboardPage
    if (_introDone) {
      return BackgroundWrapper(
        child: DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      );
    }

    // Saat intro: pakai BackgroundWrapper agar ikut background + tema user
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackgroundWrapper(
        child: _buildIntroBody(context),
      ),
    );
  }

  // ─── INTRO BODY ──────────────────────────────────────────────────────────────
  Widget _buildIntroBody(BuildContext context) {
    // Warna dari ThemeNotifier (kuning default, ganti ikut tema)
    // Teks tetap putih
    return AnimatedBuilder(
      animation: ThemeScope.of(context),
      builder: (ctx, _) {
        final accent = AppColors.accent1; // Kuning default → ikut tema user

        return Stack(
          children: [
            // ── Dark overlay ───────────────────────────────────────────────
            Container(color: const Color(0x8816213E)),

            // ── Grid pattern overlay (dari kode asli user) ─────────────────
            CustomPaint(
              size: Size.infinite,
              painter: _GridPatternPainter(
                gridColor: accent.withOpacity(0.18),
                lineColor: accent.withOpacity(0.08),
                spacing: 30,
              ),
            ),

            // ── Blur layer ─────────────────────────────────────────────────
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 1.5, sigmaY: 1.5),
                child: Container(color: Colors.transparent),
              ),
            ),

            // ── Konten intro ───────────────────────────────────────────────
            GestureDetector(
              onTap: _goToDashboard, // Tap untuk skip
              behavior: HitTestBehavior.opaque,
              child: Center(
                child: FadeTransition(
                  opacity: _fadeAnim,
                  child: ScaleTransition(
                    scale: _scaleAnim,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ── Logo lingkaran dengan ikon skull ──────────────
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0x4416213E),
                            border: Border.all(
                              color: accent.withOpacity(0.8),
                              width: 3,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.45),
                                blurRadius: 30,
                                spreadRadius: 10,
                              ),
                            ],
                          ),
                          child: FaIcon(
                            FontAwesomeIcons.skull,
                            size: 54,
                            color: accent, // Ikut warna tema
                          ),
                        ),
                        const SizedBox(height: 24),

                        // ── "WELCOME TO" ───────────────────────────────────
                        const Text(
                          'WELCOME TO',
                          style: TextStyle(
                            color: Colors.white70, // Teks tetap putih
                            fontSize: 14,
                            letterSpacing: 4,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 8),

                        // ── "ALICIA" dengan gradient warna tema ────────────
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [
                              accent,
                              accent.withOpacity(0.75),
                              accent.withOpacity(0.9),
                            ],
                          ).createShader(bounds),
                          child: const Text(
                            'ALICIA',
                            style: TextStyle(
                              color: Colors.white, // ShaderMask override warna
                              fontSize: 40,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 6,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ── Badge "RIZQY AND ALICIA" ───────────────────────
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: accent.withOpacity(0.35),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.code_rounded,
                                color: accent, // Ikut warna tema
                                size: 14,
                              ),
                              const SizedBox(width: 6),
                              const Text(
                                'RIZQY AND ALICIA',
                                style: TextStyle(
                                  color: Colors.white70, // Teks tetap putih
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 48),

                        // ── TAP TO SKIP hint ───────────────────────────────
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.touch_app_rounded,
                              color: Colors.white30,
                              size: 14,
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              'TAP TO SKIP',
                              style: TextStyle(
                                color: Colors.white30,
                                fontSize: 10,
                                letterSpacing: 3,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
