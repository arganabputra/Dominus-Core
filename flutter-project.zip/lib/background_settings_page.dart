import 'dart:io';
import 'package:flutter/material.dart';
import 'background_notifier.dart';
import 'app_theme.dart';

class BackgroundSettingsPage extends StatefulWidget {
  final VoidCallback? onBackgroundChanged;

  const BackgroundSettingsPage({
    Key? key,
    this.onBackgroundChanged,
  }) : super(key: key);

  @override
  State<BackgroundSettingsPage> createState() => _BackgroundSettingsPageState();
}

class _BackgroundSettingsPageState extends State<BackgroundSettingsPage> {
  bool _isLoading = false;

  Future<void> _pickAndSetImage() async {
    setState(() => _isLoading = true);
    try {
      final imageFile = await BackgroundNotifier.pickImage();
      if (imageFile != null && mounted) {
        final bgNotifier = BackgroundScope.of(context);
        final success = await bgNotifier.setImageBackground(imageFile);
        if (success && mounted) {
          widget.onBackgroundChanged?.call();
          _showSnack('✅ Background berhasil diubah ke Foto', AppColors.success);
        }
      }
    } catch (e) {
      if (mounted) _showSnack('❌ Error: $e', AppColors.error);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _pickAndSetVideo() async {
    setState(() => _isLoading = true);
    try {
      final videoFile = await BackgroundNotifier.pickVideo();
      if (videoFile != null && mounted) {
        final bgNotifier = BackgroundScope.of(context);
        final success = await bgNotifier.setVideoBackground(videoFile);
        if (success && mounted) {
          widget.onBackgroundChanged?.call();
          _showSnack('✅ Background berhasil diubah ke Video', AppColors.success);
        }
      }
    } catch (e) {
      if (mounted) _showSnack('❌ Error: $e', AppColors.error);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _resetToDefault() async {
    setState(() => _isLoading = true);
    try {
      final bgNotifier = BackgroundScope.of(context);
      await bgNotifier.reset();
      if (mounted) {
        widget.onBackgroundChanged?.call();
        _showSnack('✅ Background direset ke Default', AppColors.success);
      }
    } catch (e) {
      if (mounted) _showSnack('❌ Error: $e', AppColors.error);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    // Dengarkan notifier supaya status aktif update realtime
    final bgNotifier = BackgroundScope.of(context);

    return AnimatedBuilder(
      animation: bgNotifier,
      builder: (ctx, _) {
        final currentType = bgNotifier.bgType;

        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
            title: const Text(
              'GANTI FOTO / VIDEO',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.2),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status background saat ini
                _GlassCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Background Saat Ini',
                          style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppColors.surface2.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
                        ),
                        child: Text(
                          currentType == 'default'
                              ? '🖼️ Foto Default (Preset)'
                              : currentType == 'image'
                                  ? '📸 Custom Foto'
                                  : '🎬 Custom Video',
                          style: TextStyle(
                              color: AppColors.silver2, fontSize: 13, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                const Text('Pilih Background',
                    style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),

                // Pilihan: Foto
                _BgOption(
                  icon: Icons.photo_library_rounded,
                  title: 'Dari Foto',
                  description: 'Pilih foto dari galeri sebagai background',
                  isLoading: _isLoading,
                  isActive: currentType == 'image',
                  onTap: _pickAndSetImage,
                ),
                const SizedBox(height: 12),

                // Pilihan: Video
                _BgOption(
                  icon: Icons.video_library_rounded,
                  title: 'Dari Video',
                  description: 'Pilih video dari galeri sebagai background',
                  isLoading: _isLoading,
                  isActive: currentType == 'video',
                  onTap: _pickAndSetVideo,
                ),
                const SizedBox(height: 12),

                // Pilihan: Default
                _BgOption(
                  icon: Icons.refresh_rounded,
                  title: 'Foto Default',
                  description: 'Kembalikan ke foto background preset',
                  isLoading: _isLoading,
                  isActive: currentType == 'default',
                  onTap: _resetToDefault,
                ),
                const SizedBox(height: 32),

                // Info
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface2.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.info_outline, color: AppColors.silver2, size: 18),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Background diterapkan di seluruh halaman secara langsung.\n'
                          'Saat logout, background otomatis kembali ke foto default.',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 12, height: 1.6),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ─── GLASS CARD ───────────────────────────────────────────────────────────────
class _GlassCard extends StatelessWidget {
  final Widget child;
  const _GlassCard({required this.child  super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: [AppColors.surface2, AppColors.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: AppColors.silver2.withOpacity(0.15), width: 0.5),
        boxShadow: [
          BoxShadow(color: AppColors.silver2.withOpacity(0.1), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: child,
    );
  }
}

// ─── BACKGROUND OPTION CARD ───────────────────────────────────────────────────
class _BgOption extends StatefulWidget {
  final IconData icon;
  final String title;
  final String description;
  final bool isLoading;
  final bool isActive;
  final VoidCallback onTap;

  const _BgOption({
    required this.icon,
    required this.title,
    required this.description,
    required this.isLoading,
    required this.isActive,
    required this.onTap,
    super.key,
  });

  @override
  State<_BgOption> createState() => _BgOptionState();
}

class _BgOptionState extends State<_BgOption> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) { if (!widget.isLoading) setState(() => _pressed = true); },
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.isLoading ? null : widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _pressed ? 0.98 : 1.0,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: widget.isActive
                  ? [AppColors.silver2.withOpacity(0.2), AppColors.silver2.withOpacity(0.1)]
                  : [AppColors.surface2, AppColors.surface],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: widget.isActive
                  ? AppColors.silver2.withOpacity(0.5)
                  : AppColors.silver2.withOpacity(0.15),
              width: widget.isActive ? 1.5 : 0.5,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.silver2.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.silver2.withOpacity(0.2)),
                ),
                child: Icon(widget.icon, color: AppColors.silver2, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.title,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(widget.description,
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              if (widget.isLoading)
                SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.silver2),
                )
              else if (widget.isActive)
                Container(
                  width: 20, height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                        colors: [AppColors.silver2, AppColors.gray2]),
                  ),
                  child: const Icon(Icons.check, color: Colors.white, size: 12),
                )
              else
                Icon(Icons.arrow_forward_ios,
                    color: AppColors.silver2.withOpacity(0.5), size: 16),
            ],
          ),
        ),
      ),
    );
  }
}
