import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'background_notifier.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'landing.dart';
import 'control_panel.dart';
import 'device_dashboard.dart';
import 'splash.dart';
import 'owner_page.dart';
import 'background_widget.dart';
import 'spotify_player.dart';

void main() {
  runApp(const _ThemeRoot());
}

class _ThemeRoot extends StatefulWidget {
  const _ThemeRoot();
  @override State<_ThemeRoot> createState() => _ThemeRootState();
}

class _ThemeRootState extends State<_ThemeRoot> {
  final _notifier        = ThemeNotifier();
  final _bgNotifier      = BackgroundNotifier();
  final _spotifyNotifier = SpotifyNotifier();

  @override
  void dispose() {
    _notifier.dispose();
    _bgNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // SpotifyScope → BackgroundScope → ThemeScope → MaterialApp
    // Urutan ini memastikan semua halaman bisa akses spotify & background
    return SpotifyScope(
      notifier: _spotifyNotifier,
      child: BackgroundScope(
        notifier: _bgNotifier,
        child: ThemeScope(
          notifier: _notifier,
          child: AnimatedBuilder(
            animation: _notifier,
            builder: (context, _) => MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'ALICIA',
              theme: _notifier.materialTheme.copyWith(
                pageTransitionsTheme: PageTransitionsTheme(
                  builders: {
                    TargetPlatform.android: _CustomTransitionBuilder(),
                    TargetPlatform.iOS:     _CustomTransitionBuilder(),
                  },
                ),
              ),
              initialRoute: '/',
              onGenerateRoute: _onGenerateRoute,
            ),
          ),
        ),
      ),
    );
  }

  Route _onGenerateRoute(RouteSettings settings) {
    Widget page;
    switch (settings.name) {
      case '/':
        page = const LandingPage();
        break;
      case '/login':
        page = const LoginPage();
        break;
      case '/dashboard':
        final args = settings.arguments as Map<String, dynamic>;
        page = DashboardPage(
          username:    args['username'],
          password:    args['password'],
          role:        (args['role'] ?? '').toString(),
          sessionKey:  args['key'],
          expiredDate: args['expiredDate'],
          listBug:     List<Map<String, dynamic>>.from(args['listBug']  ?? []),
          listDoos:    List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
          news:        List<Map<String, dynamic>>.from(args['news']     ?? []),
        );
        break;
      case '/owner':
        final args = settings.arguments as Map<String, dynamic>;
        page = OwnerPage(
          sessionKey: args['sessionKey'] ?? args['keyToken'] ?? '',
          username:   args['username'] ?? '',
        );
        break;
      case '/control-center':
        final args = settings.arguments as Map<String, dynamic>;
        page = ControlCenterPage(targetDevice: args['targetDevice'], role: args['role'] ?? 'member');
        break;
      case '/device-dashboard':
        final args = settings.arguments as Map<String, dynamic>;
        page = DeviceDashboardPage(username: args['username'], role: args['role'], sessionKey: args['sessionKey']);
        break;
      default:
        page = const Scaffold(body: Center(child: Text("404 - Page Not Found")));
    }
    return _createRoute(page);
  }
}

Route _createRoute(Widget page) {
  return PageRouteBuilder(
    transitionDuration:        const Duration(milliseconds: 400),
    reverseTransitionDuration: const Duration(milliseconds: 400),
    pageBuilder: (context, animation, secondaryAnimation) => BackgroundWrapper(
      child: _WithMiniPlayer(child: page),
    ),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const curve = Curves.easeOutCubic;
      final offset = animation.drive(
        Tween(begin: const Offset(0.05, 0.0), end: Offset.zero).chain(CurveTween(curve: curve)));
      final fade = animation.drive(
        Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: curve)));
      return FadeTransition(opacity: fade, child: SlideTransition(position: offset, child: child));
    },
  );
}

// ─── WRAPPER MINI PLAYER ──────────────────────────────────────────────────────
// Membungkus setiap halaman dengan SpotifyMiniPlayer di bagian bawah
class _WithMiniPlayer extends StatelessWidget {
  final Widget child;
  const _WithMiniPlayer({required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        // Mini player mengambang di atas konten, di atas bottom nav
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: AnimatedBuilder(
            animation: SpotifyScope.of(context),
            builder: (ctx, _) {
              final sp = SpotifyScope.of(ctx);
              // Hanya tampil jika sedang play atau sudah ada lagu yang dipilih
              if (!sp.isPlaying && sp.position == Duration.zero) {
                return const SizedBox.shrink();
              }
              return const SpotifyMiniPlayer();
            },
          ),
        ),
      ],
    );
  }
}

class _CustomTransitionBuilder extends PageTransitionsBuilder {
  @override
  Widget buildTransitions<T>(PageRoute<T> route, BuildContext context,
      Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    const curve = Curves.easeOutCubic;
    final offset = animation.drive(
        Tween(begin: const Offset(0.03, 0.0), end: Offset.zero).chain(CurveTween(curve: curve)));
    final fade = animation.drive(
        Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: curve)));
    return FadeTransition(opacity: fade, child: SlideTransition(position: offset, child: child));
  }
}
