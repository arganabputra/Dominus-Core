// profile_settings_page.dart
//
// Modern profile + security settings page (replaces ChangePasswordPage).
//
// Features:
//   - Animated purple-tinted dark background
//   - Tap-to-change avatar (gallery picker)
//   - Identity fields: display name, email, phone, bio
//   - Change-password section with live strength meter
//   - Staggered entrance animations
//   - Save Profile + Change Password as separate actions (safer flow)
//
// REQUIRED PACKAGES (add to pubspec.yaml):
//   image_picker: ^1.1.2
//   http:         ^1.2.0
//
// REQUIRED BACKEND ENDPOINTS:
//   GET  /api/user/profile?key=KEY
//        → { success, profile: { displayName, email, phone, bio, avatarUrl } }
//
//   POST /api/user/profile          (multipart/form-data)
//        fields: key, username, displayName, email, phone, bio
//        file:   avatar (optional)
//        → { success, profile, message? }
//
//   POST /api/user/changepass       (existing — kept compatible)
//        body: username, oldPass, newPass, key
//        → { success, message? }

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'background_notifier.dart';
import 'app_theme.dart';

// ───────────────────────────────────────────────────────────────────────────
//  PALETTE  (purple/black, modernized)
// ───────────────────────────────────────────────────────────────────────────
class _C {
  static Color get bg          => AppColors.bg;
  static Color get bg2         => AppColors.cardDark;
  static Color get card        => AppColors.surface;
  static Color get card2       => AppColors.surfaceLight;
  static Color get border      => AppColors.accent3;
  static Color get purple      => AppColors.accent1;      // kuning utama
  static Color get purpleSoft  => AppColors.accent2;      // kuning medium
  static Color get purpleGlow  => AppColors.accent1;      // kuning terang
  static Color get purpleLight => AppColors.accent1;      // kuning muda
  static Color get text        => AppColors.textPrimary;
  static Color get textDim     => AppColors.textSec;
  static Color get textMute    => AppColors.textMuted;
  static const danger      = Color(0xFFFF5C7A);
  static const ok          = Color(0xFF6BE3A8);
  static const warn        = Color(0xFFFFC857);
}

const String _kBaseUrl = 'http://rizqy.smasnug.web.id:10003/api/user';

// ───────────────────────────────────────────────────────────────────────────
//  PAGE
// ───────────────────────────────────────────────────────────────────────────
class ProfileSettingsPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ProfileSettingsPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ProfileSettingsPage> createState() => _ProfileSettingsPageState();
}

class _ProfileSettingsPageState extends State<ProfileSettingsPage>
    with TickerProviderStateMixin {
  late final AnimationController _entryCtrl;
  late final AnimationController _glowCtrl;

  // identity
  final _displayCtrl = TextEditingController();
  final _emailCtrl   = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _bioCtrl     = TextEditingController();

  // security
  final _oldPassCtrl     = TextEditingController();
  final _newPassCtrl     = TextEditingController();
  final _confirmPassCtrl = TextEditingController();

  bool _showOld = false, _showNew = false, _showConfirm = false;
  int  _strength = 0; // 0..5

  // avatar
  String? _remoteAvatarUrl;
  File? _pickedAvatar;

  bool _loadingProfile = true;
  bool _savingProfile  = false;
  bool _changingPass   = false;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _glowCtrl  = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _newPassCtrl.addListener(() {
      setState(() => _strength = _scorePassword(_newPassCtrl.text));
    });
    _loadProfile();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _glowCtrl.dispose();
    _displayCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _bioCtrl.dispose();
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  // ─── api ───────────────────────────────────────────────────────────────
  Future<void> _loadProfile() async {
    setState(() => _loadingProfile = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBaseUrl/profile?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true && data['profile'] != null) {
        final p = data['profile'] as Map<String, dynamic>;
        _displayCtrl.text = (p['displayName'] ?? '').toString();
        _emailCtrl.text   = (p['email']       ?? '').toString();
        _phoneCtrl.text   = (p['phone']       ?? '').toString();
        _bioCtrl.text     = (p['bio']         ?? '').toString();
        _remoteAvatarUrl  = p['avatarUrl'] as String?;
      }
    } catch (_) {/* keep blank */}
    if (mounted) setState(() => _loadingProfile = false);
  }

  Future<void> _pickAvatar() async {
    try {
      final picker = ImagePicker();
      final x = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 1024,
      );
      if (x != null) setState(() => _pickedAvatar = File(x.path));
    } catch (e) {
      _toast('Could not open gallery: $e', err: true);
    }
  }

  Future<void> _saveProfile() async {
    if (_emailCtrl.text.trim().isNotEmpty &&
        !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(_emailCtrl.text.trim())) {
      _toast('Email format invalid', err: true);
      return;
    }
    setState(() => _savingProfile = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$_kBaseUrl/profile'))
        ..fields['key']         = widget.sessionKey
        ..fields['username']    = widget.username
        ..fields['displayName'] = _displayCtrl.text.trim()
        ..fields['email']       = _emailCtrl.text.trim()
        ..fields['phone']       = _phoneCtrl.text.trim()
        ..fields['bio']         = _bioCtrl.text.trim();

      if (_pickedAvatar != null) {
        req.files.add(await http.MultipartFile.fromPath('avatar', _pickedAvatar!.path));
      }

      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['success'] == true) {
        if (data['profile']?['avatarUrl'] != null) {
          setState(() {
            _remoteAvatarUrl = data['profile']['avatarUrl'] as String;
            _pickedAvatar = null;
          });
        }
        _toast('Profile saved');
      } else {
        _toast((data['message'] ?? 'Save failed').toString(), err: true);
      }
    } catch (e) {
      _toast('Network error', err: true);
    } finally {
      if (mounted) setState(() => _savingProfile = false);
    }
  }

  Future<void> _changePassword() async {
    final oldP = _oldPassCtrl.text.trim();
    final newP = _newPassCtrl.text.trim();
    final cnf  = _confirmPassCtrl.text.trim();

    if (oldP.isEmpty || newP.isEmpty || cnf.isEmpty) {
      _toast('All password fields are required', err: true);
      return;
    }
    if (newP != cnf) {
      _toast("New password doesn't match confirmation", err: true);
      return;
    }
    if (newP == oldP) {
      _toast('New password must differ from current', err: true);
      return;
    }
    if (_strength < 3) {
      final ok = await _confirmWeakPassword();
      if (!ok) return;
    }

    setState(() => _changingPass = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBaseUrl/changepass'),
        body: {
          'username': widget.username,
          'oldPass':  oldP,
          'newPass':  newP,
          'key':      widget.sessionKey,
        },
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        _oldPassCtrl.clear();
        _newPassCtrl.clear();
        _confirmPassCtrl.clear();
        _toast('Password changed');
      } else {
        _toast((data['message'] ?? 'Change failed').toString(), err: true);
      }
    } catch (e) {
      _toast('Network error', err: true);
    } finally {
      if (mounted) setState(() => _changingPass = false);
    }
  }

  Future<bool> _confirmWeakPassword() async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => const _WeakPasswordSheet(),
    );
    return r == true;
  }

  // ─── helpers ───────────────────────────────────────────────────────────
  int _scorePassword(String p) {
    if (p.isEmpty) return 0;
    int s = 0;
    if (p.length >= 8)                  s++;
    if (p.length >= 12)                 s++;
    if (RegExp(r'[A-Z]').hasMatch(p))   s++;
    if (RegExp(r'[0-9]').hasMatch(p))   s++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(p)) s++;
    return s.clamp(0, 5);
  }

  String _strengthLabel() => switch (_strength) {
        0 => '—',
        1 => 'VERY WEAK',
        2 => 'WEAK',
        3 => 'FAIR',
        4 => 'STRONG',
        _ => 'EXCELLENT',
      };

  Color _strengthColor() => switch (_strength) {
        0 || 1 => _C.danger,
        2      => Colors.orange,
        3      => _C.warn,
        4      => _C.ok,
        _      => _C.purpleLight,
      };

  void _toast(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: err ? _C.danger.withValues(alpha: 0.9) : _C.card,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: (err ? _C.danger : _C.border).withValues(alpha: 0.5)),
        ),
        content: Text(
          msg,
          style: TextStyle(color: err ? Colors.white : _C.text),
        ),
      ),
    );
  }

  // ─── build ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: _appBar(),
      body: Stack(
        children: [
          // === BACKGROUND IMAGE ===
          Positioned.fill(
            child: Image.asset(
              kDefaultBgAsset,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),
          // === DARK OVERLAY ===
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),
          SafeArea(
            child: _loadingProfile
                ? Center(child: CircularProgressIndicator(color: _C.purpleLight))
                : ListView(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                    children: [
                      _slide(0, _avatarHero()),
                      const SizedBox(height: 22),
                      _slide(1, _identityCard()),
                      const SizedBox(height: 16),
                      _slide(2, _saveProfileBtn()),
                      const SizedBox(height: 28),
                      _slide(3, _securityCard()),
                      const SizedBox(height: 16),
                      _slide(4, _changePassBtn()),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      iconTheme: IconThemeData(color: _C.purpleLight),
      title: ShaderMask(
        shaderCallback: (r) => const LinearGradient(
          colors: [_C.purpleLight, _C.purpleGlow, _C.purple, _C.purpleGlow, _C.purpleLight],
          stops:  [0, 0.3, 0.5, 0.7, 1],
        ).createShader(r),
        child: const Text(
          'PROFILE • SETTINGS',
          style: TextStyle(
            color: Colors.white,
            fontSize: 14,
            letterSpacing: 3,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _slide(int idx, Widget child) {
    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, __) {
        final stagger = (idx * 0.10).clamp(0.0, 0.6);
        final raw = ((_entryCtrl.value - stagger) / (1 - stagger)).clamp(0.0, 1.0);
        final t = Curves.easeOutCubic.transform(raw);
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, (1 - t) * 22), child: child),
        );
      },
    );
  }

  // ─── avatar hero ───────────────────────────────────────────────────────
  Widget _avatarHero() {
    final hasLocal  = _pickedAvatar != null;
    final hasRemote = _remoteAvatarUrl != null && _remoteAvatarUrl!.isNotEmpty;

    return Column(
      children: [
        AnimatedBuilder(
          animation: _glowCtrl,
          builder: (_, child) {
            return Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const SweepGradient(
                  colors: [_C.purpleSoft, _C.purpleGlow, _C.purpleLight, _C.purpleSoft],
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.purpleGlow.withValues(alpha: 0.25 + _glowCtrl.value * 0.25),
                    blurRadius: 26 + _glowCtrl.value * 14,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: child,
            );
          },
          child: GestureDetector(
            onTap: _pickAvatar,
            child: Container(
              width: 130, height: 130,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.card,
                border: Border.all(color: _C.bg, width: 3),
              ),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (hasLocal)
                    Image.file(_pickedAvatar!, fit: BoxFit.cover)
                  else if (hasRemote)
                    Image.network(
                      _remoteAvatarUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _avatarPlaceholder(),
                    )
                  else
                    _avatarPlaceholder(),
                  Positioned(
                    right: 0, bottom: 0,
                    child: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        color: _C.purple,
                        shape: BoxShape.circle,
                        border: Border.all(color: _C.bg, width: 3),
                      ),
                      child: const Icon(Icons.camera_alt, color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          _displayCtrl.text.trim().isEmpty ? widget.username : _displayCtrl.text.trim(),
          style: const TextStyle(
            color: _C.text,
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.4,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          '@${widget.username}',
          style: TextStyle(color: _C.textMute, fontSize: 12, fontFamily: 'monospace'),
        ),
        if (_pickedAvatar != null) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: _C.warn.withValues(alpha: 0.12),
              border: Border.all(color: _C.warn.withValues(alpha: 0.5)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.fiber_manual_record, color: _C.warn, size: 8),
                const SizedBox(width: 6),
                Text(
                  'Unsaved photo — tap Save Profile',
                  style: TextStyle(color: _C.warn, fontSize: 10.5, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _avatarPlaceholder() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_C.card2, _C.card],
        ),
      ),
      child: Icon(Icons.person, color: _C.purpleSoft, size: 60),
    );
  }

  // ─── identity card ─────────────────────────────────────────────────────
  Widget _identityCard() {
    return _glassCard(
      icon: Icons.badge_outlined,
      title: 'IDENTITY',
      child: Column(
        children: [
          _field(
            label: 'Display Name',
            hint: 'Your name as shown to others',
            icon: Icons.person_outline,
            controller: _displayCtrl,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Email',
            hint: 'name@domain.com',
            icon: Icons.alternate_email,
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Phone',
            hint: 'Optional',
            icon: Icons.phone_outlined,
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 14),
          _field(
            label: 'Bio',
            hint: 'A short line about you',
            icon: Icons.short_text,
            controller: _bioCtrl,
            maxLines: 3,
          ),
        ],
      ),
    );
  }

  Widget _saveProfileBtn() {
    return _GradientButton(
      label: _savingProfile ? 'SAVING…' : 'SAVE PROFILE',
      icon: _savingProfile ? null : Icons.save_outlined,
      busy: _savingProfile,
      onTap: _savingProfile ? null : _saveProfile,
    );
  }

  // ─── security card ─────────────────────────────────────────────────────
  Widget _securityCard() {
    return _glassCard(
      icon: Icons.lock_outline,
      title: 'SECURITY',
      child: Column(
        children: [
          _field(
            label: 'Current Password',
            hint: 'Enter your current password',
            icon: Icons.lock_clock_outlined,
            controller: _oldPassCtrl,
            obscure: !_showOld,
            suffix: IconButton(
              icon: Icon(_showOld ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showOld = !_showOld),
            ),
          ),
          const SizedBox(height: 14),
          _field(
            label: 'New Password',
            hint: 'At least 8 characters',
            icon: Icons.password_outlined,
            controller: _newPassCtrl,
            obscure: !_showNew,
            suffix: IconButton(
              icon: Icon(_showNew ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showNew = !_showNew),
            ),
          ),
          if (_newPassCtrl.text.isNotEmpty) ...[
            const SizedBox(height: 10),
            _strengthMeter(),
          ],
          const SizedBox(height: 14),
          _field(
            label: 'Confirm Password',
            hint: 'Re-enter new password',
            icon: Icons.check_circle_outline,
            controller: _confirmPassCtrl,
            obscure: !_showConfirm,
            suffix: IconButton(
              icon: Icon(_showConfirm ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.textMute, size: 20),
              onPressed: () => setState(() => _showConfirm = !_showConfirm),
            ),
          ),
          if (_newPassCtrl.text.isNotEmpty &&
              _confirmPassCtrl.text.isNotEmpty &&
              _newPassCtrl.text != _confirmPassCtrl.text) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.error_outline, color: _C.danger, size: 14),
                const SizedBox(width: 6),
                Text("Passwords don't match",
                    style: TextStyle(color: _C.danger, fontSize: 11)),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _strengthMeter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(5, (i) {
            final filled = i < _strength;
            return Expanded(
              child: Container(
                margin: EdgeInsets.only(right: i == 4 ? 0 : 4),
                height: 4,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2),
                  color: filled ? _strengthColor() : _C.border.withValues(alpha: 0.4),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'STRENGTH',
              style: TextStyle(
                color: _C.textMute,
                fontSize: 9.5,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              _strengthLabel(),
              style: TextStyle(
                color: _strengthColor(),
                fontSize: 10,
                letterSpacing: 1.4,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _changePassBtn() {
    return _GradientButton(
      label: _changingPass ? 'UPDATING…' : 'CHANGE PASSWORD',
      icon: _changingPass ? null : Icons.shield_outlined,
      busy: _changingPass,
      onTap: _changingPass ? null : _changePassword,
    );
  }

  // ─── small bits ────────────────────────────────────────────────────────
  Widget _glassCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _C.card.withValues(alpha: 0.92),
            _C.card2.withValues(alpha: 0.92),
          ],
        ),
        border: Border.all(color: _C.border.withValues(alpha: 0.6)),
        boxShadow: [
          BoxShadow(
            color: _C.purpleSoft.withValues(alpha: 0.08),
            blurRadius: 24,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: const LinearGradient(
                    colors: [_C.purple, _C.purpleSoft],
                  ),
                ),
                child: Icon(icon, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(
                  color: _C.text,
                  fontSize: 12,
                  letterSpacing: 1.8,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _field({
    required String label,
    required String hint,
    required IconData icon,
    required TextEditingController controller,
    bool obscure = false,
    int maxLines = 1,
    TextInputType? keyboardType,
    Widget? suffix,
    void Function(String)? onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label.toUpperCase(),
            style: TextStyle(
              color: _C.textDim,
              fontSize: 10,
              letterSpacing: 1.4,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        TextField(
          controller: controller,
          obscureText: obscure,
          maxLines: obscure ? 1 : maxLines,
          keyboardType: keyboardType,
          onChanged: onChanged,
          style: TextStyle(color: _C.text, fontSize: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: _C.textMute, fontSize: 13),
            prefixIcon: Icon(icon, color: _C.purpleGlow, size: 18),
            suffixIcon: suffix,
            filled: true,
            fillColor: _C.bg2.withValues(alpha: 0.7),
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: _C.border.withValues(alpha: 0.5)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: _C.border.withValues(alpha: 0.5)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: _C.purpleGlow, width: 1.4),
            ),
          ),
        ),
      ],
    );
  }
}

// ───────────────────────────────────────────────────────────────────────────
//  GRADIENT BUTTON
// ───────────────────────────────────────────────────────────────────────────
class _GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool busy;
  final VoidCallback? onTap;
  const _GradientButton({
    required this.label,
    required this.icon,
    required this.busy,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: enabled
              ? const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [_C.purpleSoft, _C.purple, _C.purpleGlow],
                )
              : LinearGradient(colors: [
                  _C.card2.withValues(alpha: 0.6),
                  _C.card.withValues(alpha: 0.6),
                ]),
          border: Border.all(
            color: enabled
                ? _C.purpleLight.withValues(alpha: 0.4)
                : _C.border.withValues(alpha: 0.3),
          ),
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: _C.purple.withValues(alpha: 0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (busy)
                const SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              else if (icon != null)
                Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  letterSpacing: 1.6,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────────────────────────────────────────────────────────
//  WEAK PASSWORD CONFIRM SHEET
// ───────────────────────────────────────────────────────────────────────────
class _WeakPasswordSheet extends StatelessWidget {
  const _WeakPasswordSheet();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: const BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: _C.purpleSoft, width: 0.6)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 38, height: 4,
              decoration: BoxDecoration(
                color: _C.border, borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.warn.withValues(alpha: 0.12),
                border: Border.all(color: _C.warn.withValues(alpha: 0.5)),
              ),
              child: const Icon(Icons.warning_amber_rounded, color: _C.warn, size: 32),
            ),
            const SizedBox(height: 14),
            Text(
              'WEAK PASSWORD',
              style: TextStyle(
                color: _C.text,
                fontSize: 14,
                letterSpacing: 1.8,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your new password is easy to guess. Add length, mixed case, '
              'numbers, and symbols for better security.',
              textAlign: TextAlign.center,
              style: TextStyle(color: _C.textDim, fontSize: 12.5, height: 1.5),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.border),
                        color: _C.bg2,
                      ),
                      child: Center(
                        child: Text(
                          'GO BACK',
                          style: TextStyle(
                            color: _C.textDim,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.4,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: const LinearGradient(
                          colors: [_C.purpleSoft, _C.purpleGlow],
                        ),
                      ),
                      child: const Center(
                        child: Text(
                          'USE ANYWAY',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.4,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────────────────────────────────────────────────────────
//  ANIMATED BACKGROUND
// ───────────────────────────────────────────────────────────────────────────
class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter({required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    // base radial purple haze
    final base = Paint()
      ..shader = RadialGradient(
        center: Alignment(math.cos(t * 6.28) * 0.5, -0.3 + math.sin(t * 6.28) * 0.2),
        radius: 1.2,
        colors: [_C.bg2, _C.bg],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, base);

    // floating purple orbs
    final rng = math.Random(7);
    for (int i = 0; i < 4; i++) {
      final cx = (rng.nextDouble() + math.sin((t + i * 0.3) * 6.28) * 0.15) * size.width;
      final cy = (rng.nextDouble() + math.cos((t + i * 0.5) * 6.28) * 0.15) * size.height;
      final r  = 80 + rng.nextDouble() * 80;
      final p = Paint()
        ..shader = RadialGradient(
          colors: [
            _C.purpleSoft.withValues(alpha: 0.18),
            _C.purpleSoft.withValues(alpha: 0),
          ],
        ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r));
      canvas.drawCircle(Offset(cx, cy), r, p);
    }

    // subtle grid
    final grid = Paint()
      ..color = _C.purpleSoft.withValues(alpha: 0.04)
      ..strokeWidth = 0.6;
    const step = 40.0;
    final shift = (t * step) % step;
    for (double x = -shift; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = -shift; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // top vignette
    final vign = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.center,
        colors: [
          Colors.black.withValues(alpha: 0.5),
          Colors.black.withValues(alpha: 0),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, vign);
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) => old.t != t;
}
