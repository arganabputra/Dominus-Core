import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';

// ── Color Palette (Red-Black Theme) ────────────────────────────────
class ShadowColors {
  static const bg          = Color(0xFF0A0A0A);
  static const surface     = Color(0xFF121212);
  static const red         = Color(0xFFFF0000);
  static const redBright   = Color(0xFFFF3333);
  static const redAccent   = Color(0xFFFF1A1A);
  static const redGlow     = Color(0xFFCC0000);
  static const borderGlow  = Color(0xFFFF0000);
  static const textMain    = Color(0xFFF5F5F5);
  static const textSub     = Color(0xFFB0B0B0);
  static const success     = Color(0xFF00E676);
  static const hexPattern  = Color(0xFF1A1A1A);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  final PageController _pageCtrl = PageController();
  int _currentPage = 0;

  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  late AnimationController _glowCtrl;
  late AnimationController _entranceCtrl;
  late Animation<double> _glow;
  late Animation<double> _fade;
  late Animation<Offset> _slideUp;

  @override
  void initState() {
    super.initState();

    _videoCtrl = VideoPlayerController.asset('assets/videos/landingp.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoReady = true);
          _videoCtrl.setLooping(true);
          _videoCtrl.setVolume(0);
          _videoCtrl.play();
        }
      });

    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));

    _glow = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slideUp = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));

    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _entranceCtrl.forward();
    });
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _glowCtrl.dispose();
    _entranceCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShadowColors.bg,
      body: Stack(children: [
        CustomPaint(
          painter: _HexBgPainter(),
          child: const SizedBox.expand(),
        ),
        SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slideUp,
              child: Stack(children: [
                PageView(
                  controller: _pageCtrl,
                  scrollDirection: Axis.vertical,
                  onPageChanged: (i) => setState(() => _currentPage = i),
                  children: [
                    _buildWelcomePage(),
                    _buildJapanesePage(),
                    _buildMainLanding(),
                  ],
                ),
                Positioned(
                  right: 14,
                  top: 0,
                  bottom: 0,
                  child: Center(child: _buildDotIndicator()),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildWelcomePage() {
    return Stack(fit: StackFit.expand, children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [ShadowColors.textMain, ShadowColors.redAccent],
                ).createShader(b),
                child: const Text(
                  '.WELCOME.',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ]);
  }

  Widget _buildJapanesePage() {
    return Stack(fit: StackFit.expand, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'أهلًا وسهلًا',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                color: ShadowColors.textMain,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'مرحبًا بكم! نتقدم إليكم بجزيل الشكر والترحيب لانضمامكم إلى مجتمعنا. هنا يمكنكم الاستمتاع بأحدث التقنيات والأدوات المفيدة بكل راحة وسهولة. إذا كانت لديكم أي أسئلة أو استفسارات، فلا تترددوا في التواصل مع فريق الدعم لدينا. نتمنى لكم تجربة ممتعة ومميزة!',
              style: TextStyle(
                fontSize: 14,
                color: ShadowColors.textSub,
                height: 1.7,
              ),
            ),
          ],
        ),
      ),
    ]);
  }

  Widget _buildMainLanding() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(children: [
        _buildHeroVideo(),
        _buildTitleSection(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Column(children: [
            const SizedBox(height: 18),
            _buildAboutCard(),
            const SizedBox(height: 14),
            _buildSignInButton(),
            const SizedBox(height: 10),
            _buildDevOwnerRow(),
            const SizedBox(height: 14),
            _buildFooter(),
            const SizedBox(height: 20),
          ]),
        ),
      ]),
    );
  }

  Widget _buildHeroVideo() {
    return SizedBox(
      height: 280,
      width: double.infinity,
      child: _videoReady
          ? FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoCtrl.value.size.width,
                height: _videoCtrl.value.size.height,
                child: VideoPlayer(_videoCtrl),
              ),
            )
          : Container(
              color: const Color(0xFF0A0A0A),
              child: const Center(
                child: CircularProgressIndicator(
                  color: ShadowColors.redAccent,
                  strokeWidth: 2,
                ),
              ),
            ),
    );
  }

  Widget _buildTitleSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text(
          'THE',
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 34,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            letterSpacing: 6,
            height: 1.1,
          ),
        ),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [ShadowColors.red, ShadowColors.redAccent, ShadowColors.redBright],
          ).createShader(b),
          child: const Text(
            'DarkMega',
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 34,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 4,
              height: 1.1,
            ),
          ),
        ),
        const SizedBox(height: 6),
      ]),
    );
  }

  Widget _buildAboutCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF1A1A1A).withOpacity(0.92),
        border: Border.all(color: ShadowColors.borderGlow.withOpacity(0.45), width: 1),
        boxShadow: [
          BoxShadow(color: ShadowColors.red.withOpacity(0.12), blurRadius: 18),
        ],
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          margin: const EdgeInsets.only(top: 2, right: 10),
          child: Icon(Icons.info_outline_rounded, color: ShadowColors.redAccent, size: 20),
        ),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'DarkMega',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: ShadowColors.textMain,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'DarkMega adalah platform tools yang dirancang untuk memberikan performa terbaik. Dikembangkan semaksimal mungkin oleh Anxyy dengan sepenuh hati.',
              style: TextStyle(
                fontSize: 13,
                color: ShadowColors.textSub,
                height: 1.5,
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildSignInButton() {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) => GestureDetector(
        onTap: () => Navigator.pushNamed(context, '/login'),
        child: Container(
          width: double.infinity,
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: LinearGradient(
              colors: [
                ShadowColors.red,
                ShadowColors.redBright,
                ShadowColors.redGlow,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: ShadowColors.red.withOpacity(0.5 * _glow.value),
                blurRadius: 24,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Row(children: [
                  const Icon(Icons.login_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 10),
                  const Text(
                    'Sign-in',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),
                ]),
              ),
              const Padding(
                padding: EdgeInsets.only(right: 18),
                child: Icon(Icons.chevron_right_rounded, color: Colors.white, size: 24),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDevOwnerRow() {
    return Row(children: [
      Expanded(child: _buildTelegramButton('Developer', 'https://t.me/Chs_Caze')),
      const SizedBox(width: 10),
      Expanded(child: _buildTelegramButton('Owner', 'https://t.me/Chs_Caze')),
    ]);
  }

  Widget _buildTelegramButton(String label, String url) {
    return GestureDetector(
      onTap: () => _launch(url),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: const LinearGradient(
            colors: [ShadowColors.red, ShadowColors.redBright],
          ),
          boxShadow: [
            BoxShadow(color: ShadowColors.red.withOpacity(0.3), blurRadius: 14),
          ],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const FaIcon(FontAwesomeIcons.telegram, color: Colors.white, size: 17),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              letterSpacing: 1.2,
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF1A1A1A).withOpacity(0.7),
        border: Border.all(color: ShadowColors.borderGlow.withOpacity(0.2), width: 1),
      ),
      child: Column(children: [
        const Text(
          'By: Agung',
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: ShadowColors.textMain,
            letterSpacing: 3,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          '© 2026 The King Aksel',
          style: TextStyle(
            fontSize: 11,
            color: ShadowColors.textSub,
            letterSpacing: 1,
          ),
        ),
      ]),
    );
  }

  Widget _buildDotIndicator() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final isActive = _currentPage == i;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(vertical: 3),
          width: isActive ? 10 : 8,
          height: isActive ? 10 : 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isActive
                ? ShadowColors.redBright
                : ShadowColors.textSub.withOpacity(0.4),
            boxShadow: isActive
                ? [BoxShadow(color: ShadowColors.redBright.withOpacity(0.7), blurRadius: 8)]
                : null,
          ),
        );
      }),
    );
  }
}

class _HexBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFF050505), Color(0xFF0A0A0A), Color(0xFF121212)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    final hexPaint = Paint()
      ..color = const Color(0xFF2A1A00).withOpacity(0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const hexSize = 28.0;
    final hexH = hexSize * math.sqrt(3);
    final hexW = hexSize * 2;

    for (double row = 0; row < size.height / hexH + 2; row++) {
      for (double col = 0; col < size.width / hexW + 2; col++) {
        final cx = col * hexW * 0.75 - hexSize;
        final cy = row * hexH + (col.toInt().isOdd ? hexH / 2 : 0) - hexH;
        _drawHex(canvas, hexPaint, Offset(cx, cy), hexSize);
      }
    }
  }

  void _drawHex(Canvas canvas, Paint paint, Offset center, double size) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = math.pi / 180 * (60 * i - 30);
      final x = center.dx + size * math.cos(angle);
      final y = center.dy + size * math.sin(angle);
      if (i == 0) path.moveTo(x, y);
      else path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_HexBgPainter old) => false;
}