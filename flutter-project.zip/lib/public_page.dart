import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class PublicChatPage extends StatefulWidget {
  final String username;
  const PublicChatPage({super.key, required this.username});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  // --- KONFIGURASI URL SERVER ---
  final String baseUrl = "http://manis.banditflow.my.id:2172"; 

  // Controllers
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // State
  List<dynamic> _messages = [];
  int _onlineUsers = 0;
  Timer? _refreshTimer;
  Timer? _onlineTimer;
  bool _isSending = false;
  bool _isUploadingImage = false;

  // Image picker
  final ImagePicker _picker = ImagePicker();

  // ─── CANDY APPLE RED THEME ──────────────────────────────────────────────
  static const Color _kBg         = Color(0xFF0A0404);  // Hitam kemerahan
  static const Color _kCard       = Color(0xFF1A0808);
  static const Color _kBorder     = Color(0xFF441111);
  static const Color _kCandy      = Color(0xFFFF0800);  // Candy Apple Red Utama
  static const Color _kCandyLight = Color(0xFFFF4444);
  static const Color _kCandyDark  = Color(0xFFCC0600);
  static const Color _kGreen      = Color(0xFF00FFCC);
  static const Color _kRed        = Color(0xFFFF007F);
  static const Color _bubbleMe    = Color(0xFFFF0800);  // Bubble milik sendiri merah
  static const Color _bubbleOther = Color(0xFF2A1010); // Bubble orang lain merah gelap
  static const Color _textWhite   = Color(0xFFFFFFFF);

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    _fetchOnlineUsers();
    
    // Pooling data chat setiap 2 detik
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchMessages();
    });

    // Update online users setiap 5 detik
    _onlineTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _fetchOnlineUsers();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _onlineTimer?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ─── API ───────────────────────────────────────────────────────────────────

  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(Uri.parse("$baseUrl/get-public-chat"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          List newMsgs = data['messages'];
          bool shouldScroll = newMsgs.length > _messages.length;
          if (mounted) {
            setState(() { _messages = newMsgs; });
            if (shouldScroll) _scrollToBottom();
          }
        }
      }
    } catch (e) {
      debugPrint("Gagal mengambil data chat: $e");
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final res = await http.get(Uri.parse("$baseUrl/online-users"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['online'] != null) {
          if (mounted) setState(() => _onlineUsers = data['online']);
        }
      }
    } catch (e) {
      // Jika endpoint belum tersedia, abaikan
      debugPrint("Gagal fetch online users: $e");
    }
  }

  Future<void> _sendMessage({String? imageBase64}) async {
    String text = _msgController.text.trim();
    if (text.isEmpty && imageBase64 == null) return;

    _msgController.clear();
    setState(() => _isSending = true);

    try {
      final body = {
        "username": widget.username,
        "message": text,
      };
      if (imageBase64 != null) {
        body["image"] = imageBase64;
      }

      final response = await http.post(
        Uri.parse("$baseUrl/send-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      );
      
      if (response.statusCode == 200) {
        await _fetchMessages(); 
        _scrollToBottom();
      } else {
        throw Exception("Server Error");
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Gagal mengirim pesan", style: TextStyle(color: Colors.white)), 
            backgroundColor: _kRed, 
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
        maxWidth: 1024,
      );
      if (pickedFile != null) {
        setState(() => _isUploadingImage = true);
        final bytes = await pickedFile.readAsBytes();
        final base64Image = base64Encode(bytes);
        await _sendMessage(imageBase64: base64Image);
        setState(() => _isUploadingImage = false);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Gagal memilih gambar: $e", style: const TextStyle(color: Colors.white)),
            backgroundColor: _kRed,
          ),
        );
      }
      setState(() => _isUploadingImage = false);
    }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A0808),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.camera_alt, color: _kCandy),
              title: const Text("Kamera", style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_library, color: _kCandy),
              title: const Text("Galeri", style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── UI ──────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final msg = _messages[index];
                  final isMe = msg['username'] == widget.username;
                  return _buildChatBubble(msg, isMe);
                },
              ),
            ),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: _kBg,
        border: Border(bottom: BorderSide(color: _kCandy.withOpacity(0.3))),
        boxShadow: [
          BoxShadow(color: _kCandy.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4))
        ]
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(Icons.arrow_back_rounded, color: _kCandy),
          ),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("DarkMega PUBLIC", 
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 1, fontFamily: 'Orbitron')),
              Row(
                children: [
                  Container(width: 8, height: 8, decoration: const BoxDecoration(color: _kGreen, shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Text("Live • $_onlineUsers online • ${_messages.length} messages", 
                    style: TextStyle(color: _kCandy.withOpacity(0.7), fontSize: 11)),
                ],
              )
            ],
          )
        ],
      ),
    );
  }

  Widget _buildChatBubble(dynamic msg, bool isMe) {
    final String? imageUrl = msg['image'];
    final String message = msg['message'] ?? '';

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(left: 12, bottom: 4),
                child: Text(msg['username'] ?? "Unknown", 
                  style: const TextStyle(color: _kCandyLight, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isMe ? _bubbleMe : _bubbleOther,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isMe ? 20 : 5),
                  bottomRight: Radius.circular(isMe ? 5 : 20),
                ),
                border: Border.all(color: isMe ? _kCandy : _kCandy.withOpacity(0.3)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 4, offset: const Offset(0, 2))
                ]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (imageUrl != null && imageUrl.isNotEmpty) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(
                        base64Decode(imageUrl),
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: 200,
                        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white54, size: 40),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  if (message.isNotEmpty)
                    Text(message, style: const TextStyle(color: Colors.white, fontSize: 14)),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(msg['time'] ?? "", 
                      style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10)),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0808), 
        border: Border(top: BorderSide(color: _kCandy.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          // Tombol Lampirkan Foto
          GestureDetector(
            onTap: _isUploadingImage ? null : _showImageSourceDialog,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: _isUploadingImage ? Colors.grey[800] : Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _kCandy.withOpacity(0.3)),
              ),
              child: _isUploadingImage
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: _kCandy),
                    )
                  : const Icon(Icons.photo_camera_rounded, color: _kCandy, size: 22),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _kCandy.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _msgController,
                style: const TextStyle(color: Colors.white),
                cursorColor: _kCandy,
                decoration: InputDecoration(
                  hintText: "Type a message...",
                  hintStyle: TextStyle(color: _kCandy.withOpacity(0.4)),
                  border: InputBorder.none,
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: _isSending ? null : _sendMessage,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_kCandyDark, _kCandy]),
                shape: BoxShape.circle,
                boxShadow: [
                  if (!_isSending)
                    BoxShadow(color: _kCandy.withOpacity(0.5), blurRadius: 12, spreadRadius: 2)
                ]
              ),
              child: Icon(
                _isSending ? Icons.hourglass_top_rounded : Icons.send_rounded, 
                color: Colors.white, size: 22
              ),
            ),
          )
        ],
      ),
    );
  }
}