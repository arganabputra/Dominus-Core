import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Global notifier — setiap kali foto profil berubah, nilai ini naik 1.
/// Semua widget yang pakai ValueListenableBuilder(profileImageNotifier, ...)
/// akan otomatis rebuild tanpa perlu setState() manual.
final ValueNotifier<int> profileImageNotifier = ValueNotifier<int>(0);

/// Utility class untuk manajemen profil foto pengguna
class ProfileImageUtils {
  static const String _profileImageKey     = 'user_profile_image_base64';
  static const String _profileImagePathKey = 'user_profile_image_path';

  // ─────────────────────────────────────────────────────────────
  // Crop gambar jadi kotak sempurna (center crop) lalu resize
  // ke 400×400. Dengan ini foto SELALU pas di bulatan profil,
  // tidak ada sisa putih atau overflow apapun bentuk fotonya.
  // ─────────────────────────────────────────────────────────────
  static Future<Uint8List?> _cropToSquare(Uint8List bytes) async {
    try {
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final src   = frame.image;

      final w    = src.width;
      final h    = src.height;
      final side = w < h ? w : h; // ambil sisi terpendek

      // Persegi tengah dari gambar asli
      final srcRect = Rect.fromLTWH(
        (w - side) / 2.0,
        (h - side) / 2.0,
        side.toDouble(),
        side.toDouble(),
      );

      // Output 400×400 px (cukup tajam untuk avatar)
      const int out = 400;
      final dstRect = Rect.fromLTWH(0, 0, out.toDouble(), out.toDouble());

      final recorder = ui.PictureRecorder();
      Canvas(recorder).drawImageRect(src, srcRect, dstRect, Paint());
      final picture    = recorder.endRecording();
      final cropped    = await picture.toImage(out, out);
      final byteData   = await cropped.toByteData(format: ui.ImageByteFormat.png);

      src.dispose();
      cropped.dispose();

      return byteData?.buffer.asUint8List();
    } catch (e) {
      debugPrint('Crop error: $e');
      return null; // fallback ke bytes asli
    }
  }

  /// Simpan foto profil dari file & notify semua listener
  static Future<bool> saveProfileImage(File imageFile) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw   = await imageFile.readAsBytes();

      // Crop otomatis ke kotak supaya selalu pas di foto profil bulat
      final bytes       = await _cropToSquare(raw) ?? raw;
      final base64String = base64Encode(bytes);

      final appDir     = await getApplicationDocumentsDirectory();
      final profileDir  = Directory('${appDir.path}/profile');
      if (!await profileDir.exists()) {
        await profileDir.create(recursive: true);
      }

      final profileImageFile = File('${profileDir.path}/profile_image.jpg');
      await profileImageFile.writeAsBytes(bytes);

      await prefs.setString(_profileImageKey, base64String);
      await prefs.setString(_profileImagePathKey, profileImageFile.path);

      // Evict cache lama supaya Image.file langsung tampil foto baru
      FileImage(profileImageFile).evict();

      // Notifikasi semua widget yang mendengarkan
      profileImageNotifier.value++;
      return true;
    } catch (e) {
      debugPrint('Error saving profile image: $e');
      return false;
    }
  }

  /// Ambil foto profil sebagai File
  static Future<File?> getProfileImageFile() async {
    try {
      final prefs     = await SharedPreferences.getInstance();
      final imagePath = prefs.getString(_profileImagePathKey);
      if (imagePath == null) return null;
      final imageFile = File(imagePath);
      return await imageFile.exists() ? imageFile : null;
    } catch (e) {
      debugPrint('Error getting profile image file: $e');
      return null;
    }
  }

  /// Ambil foto profil sebagai base64
  static Future<String?> getProfileImageBase64() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_profileImageKey);
    } catch (e) {
      debugPrint('Error getting profile image base64: $e');
      return null;
    }
  }

  /// Ambil foto profil sebagai MemoryImage
  static Future<MemoryImage?> getProfileImageMemory() async {
    try {
      final b64 = await getProfileImageBase64();
      if (b64 == null) return null;
      return MemoryImage(base64Decode(b64));
    } catch (e) {
      debugPrint('Error getting profile image memory: $e');
      return null;
    }
  }

  /// Pick foto dari galeri atau kamera
  static Future<File?> pickProfileImage({
    ImageSource source = ImageSource.gallery,
  }) async {
    try {
      final picker     = ImagePicker();
      final pickedFile = await picker.pickImage(
        source: source,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );
      return pickedFile != null ? File(pickedFile.path) : null;
    } catch (e) {
      debugPrint('Error picking image: $e');
      return null;
    }
  }

  /// Hapus foto profil & notify semua listener
  static Future<bool> deleteProfileImage() async {
    try {
      final prefs     = await SharedPreferences.getInstance();
      final imagePath = prefs.getString(_profileImagePathKey);
      if (imagePath != null) {
        final f = File(imagePath);
        if (await f.exists()) await f.delete();
      }
      await prefs.remove(_profileImageKey);
      await prefs.remove(_profileImagePathKey);

      profileImageNotifier.value++;
      return true;
    } catch (e) {
      debugPrint('Error deleting profile image: $e');
      return false;
    }
  }

  /// Cek apakah ada foto profil yang tersimpan
  static Future<bool> hasProfileImage() async {
    try {
      final b64 = await getProfileImageBase64();
      return b64 != null && b64.isNotEmpty;
    } catch (e) {
      return false;
    }
  }
}
