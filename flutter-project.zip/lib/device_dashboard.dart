import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'control_panel.dart';
import 'app_theme.dart';
import 'background_widget.dart';

const _kBase = 'http://rizqy.smasnug.web.id:10003';

// ============================================================================
// METALLIC GRAY THEME COLORS - dynamic via app_theme.dart
// ============================================================================
class DashboardTheme {
  static Color get bg            => AppColors.bg;
  static Color get surface       => AppColors.surface;
  static Color get surface2      => AppColors.surfaceLight;
  static Color get surface3      => AppColors.surface2;
  static Color get cardDark      => AppColors.cardDark;
  static Color get gray1         => AppColors.accent1;
  static Color get gray2         => AppColors.accent2;
  static Color get gray3         => AppColors.accent3;
  static Color get gray4         => AppColors.accent3;
  static Color get silver        => AppColors.accent1;
  static Color get chrome        => AppColors.accent1;
  static Color get accent1       => AppColors.accent1;
  static Color get accent2       => AppColors.accent2;
  static Color get accent3       => AppColors.accent3;
  static const success     = Color(0xFF4CAF50);
  static const warning     = Color(0xFFFFAB40);
  static const error       = Color(0xFFEF5350);
  static Color get textPrimary   => AppColors.textPrimary;
  static Color get textSecondary => AppColors.textSec;
  static Color get textMuted     => AppColors.textMuted;
  static const shadow      = Color(0x40000000);
  static const shadowHeavy = Color(0x80000000);
}

// ============================================================================
// SHADOW UTILITIES
// ============================================================================
class _DashShadowUtils {
  static List<BoxShadow> get soft {
    return const [
      BoxShadow(
        color: DashboardTheme.shadow,
        blurRadius: 8,
        offset: Offset(0, 2),
      ),
      BoxShadow(
        color: DashboardTheme.shadowHeavy,
        blurRadius: 2,
        offset: Offset(0, 1),
      ),
    ];
  }
  
  static List<BoxShadow> get medium {
    return const [
      BoxShadow(
        color: DashboardTheme.shadow,
        blurRadius: 16,
        offset: Offset(0, 4),
      ),
      BoxShadow(
        color: DashboardTheme.shadowHeavy,
        blurRadius: 4,
        offset: Offset(0, 2),
      ),
    ];
  }
  
  static List<BoxShadow> get heavy {
    return const [
      BoxShadow(
        color: DashboardTheme.shadow,
        blurRadius: 24,
        offset: Offset(0, 8),
      ),
      BoxShadow(
        color: DashboardTheme.shadowHeavy,
        blurRadius: 8,
        offset: Offset(0, 4),
      ),
      BoxShadow(
        color: DashboardTheme.shadowHeavy,
        blurRadius: 2,
        offset: Offset(0, 1),
      ),
    ];
  }
  
  static List<BoxShadow> get card {
    return const [
      BoxShadow(
        color: DashboardTheme.shadowHeavy,
        blurRadius: 20,
        offset: Offset(0, 10),
      ),
      BoxShadow(
        color: DashboardTheme.shadow,
        blurRadius: 6,
        offset: Offset(0, 2),
      ),
    ];
  }
}

// ============================================================================
// DEVICE LIST
// ============================================================================
class _DeviceListPage extends StatelessWidget {
  final List<dynamic> devices;
  final String role;
  final String sessionKey;
  final String username;

  const _DeviceListPage({
    required this.devices,
    required this.role,
    this.sessionKey = '',
    this.username = '',
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final activeCount = devices.where((d) => d['online'] == true).length;
    
    return Column(
      children: [
        // Stats bar - Metallic Gray
        Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [DashboardTheme.surface2, DashboardTheme.surface3],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: _DashShadowUtils.soft,
            border: Border.all(
              color: DashboardTheme.gray1.withOpacity(0.15),
              width: 0.5,
            ),
          ),
          child: Row(
            children: [
              _StatChip(
                label: 'ONLINE',
                value: '$activeCount',
                color: DashboardTheme.success,
              ),
              const SizedBox(width: 12),
              _StatChip(
                label: 'OFFLINE',
                value: '${devices.length - activeCount}',
                color: DashboardTheme.error,
              ),
              const Spacer(),
              _StatChip(
                label: 'TOTAL',
                value: '${devices.length}',
                color: DashboardTheme.gray1,
              ),
            ],
          ),
        ),
        
        // Device List
        Expanded(
          child: devices.isEmpty
              ? _EmptyDeviceWidget()
              : RefreshIndicator(
                  onRefresh: () async {
                    // Refresh will be handled by parent
                  },
                  color: DashboardTheme.gray1,
                  backgroundColor: DashboardTheme.surface2,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: devices.length,
                    itemBuilder: (ctx, i) {
                      final d = devices[i];
                      final isOnline = d['online'] == true;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _DeviceCard(
                          device: d,
                          isOnline: isOnline,
                          role: role,
                          sessionKey: sessionKey,
                          username: username,
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  
  const _StatChip({
    required this.label,
    required this.value,
    required this.color,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: color, blurRadius: 4),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(color: DashboardTheme.textMuted, fontSize: 10),
          ),
          const SizedBox(width: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _DeviceCard extends StatelessWidget {
  final dynamic device;
  final bool isOnline;
  final String role;
  final String sessionKey;
  final String username;
  
  const _DeviceCard({
    required this.device,
    required this.isOnline,
    required this.role,
    this.sessionKey = '',
    this.username = '',
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = isOnline ? DashboardTheme.success : DashboardTheme.error;
    
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BackgroundWrapper(
            child: ControlCenterPage(
              targetDevice: device,
              role: role,
              sessionKey: sessionKey,
              username: username,
            ),
          ),
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [DashboardTheme.surface2, DashboardTheme.surface3],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: _DashShadowUtils.card,
          border: Border.all(
            color: isOnline 
                ? statusColor.withOpacity(0.4) 
                : DashboardTheme.gray1.withOpacity(0.1),
            width: isOnline ? 1.5 : 0.5,
          ),
        ),
        child: Stack(
          children: [
            if (isOnline)
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    colors: [statusColor.withOpacity(0.08), Colors.transparent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  // Icon device
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isOnline 
                            ? [DashboardTheme.gray1, DashboardTheme.gray3]
                            : [DashboardTheme.surface3, DashboardTheme.surface3],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: _DashShadowUtils.soft,
                      border: Border.all(
                        color: isOnline 
                            ? DashboardTheme.silver.withOpacity(0.2)
                            : DashboardTheme.surface3,
                        width: 0.5,
                      ),
                    ),
                    child: Icon(
                      Icons.phone_android_rounded,
                      color: isOnline ? Colors.white : DashboardTheme.textMuted,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  // Info device
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device['model'] ?? 'Unknown Device',
                          style: TextStyle(
                            color: isOnline ? DashboardTheme.textPrimary : DashboardTheme.textSecondary,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          device['id'] ?? 'ID: ---',
                          style: TextStyle(
                            color: DashboardTheme.textMuted,
                            fontSize: 10,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Icon(
                              Icons.battery_charging_full_rounded,
                              color: DashboardTheme.textMuted,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${device['battery'] ?? '?'}%',
                              style: TextStyle(
                                color: isOnline ? DashboardTheme.textSecondary : DashboardTheme.textMuted,
                                fontSize: 11,
                              ),
                            ),
                            if (!isOnline && device['lastSeen'] != null) ...[
                              const SizedBox(width: 10),
                              Text(
                                _formatLastSeen(device['lastSeen']),
                                style: TextStyle(color: DashboardTheme.textMuted, fontSize: 10),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Status badge + arrow
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: statusColor.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 5,
                              height: 5,
                              decoration: BoxDecoration(
                                color: statusColor,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(color: statusColor, blurRadius: 4),
                                ],
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              isOnline ? 'ON' : 'OFF',
                              style: TextStyle(
                                color: statusColor,
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: DashboardTheme.textMuted,
                        size: 14,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  String _formatLastSeen(String? lastSeenStr) {
    if (lastSeenStr == null) return 'Never';
    try {
      final lastSeen = DateTime.parse(lastSeenStr);
      final diff = DateTime.now().difference(lastSeen);
      if (diff.inSeconds < 60) return '${diff.inSeconds}s ago';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) {
      return 'Never';
    }
  }
}

class _EmptyDeviceWidget extends StatelessWidget {
  const _EmptyDeviceWidget();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [DashboardTheme.surface2, DashboardTheme.surface3],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: _DashShadowUtils.heavy,
              border: Border.all(
                color: DashboardTheme.gray1.withOpacity(0.2),
                width: 1.5,
              ),
            ),
            child: Icon(
              Icons.phone_android_rounded,
              size: 48,
              color: DashboardTheme.textMuted,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'BELUM ADA DEVICE',
            style: TextStyle(
              color: DashboardTheme.textSecondary,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tidak ada perangkat yang terhubung',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: DashboardTheme.textMuted,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// MAIN DASHBOARD
// ============================================================================
class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });

  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      final dRes = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
      }

      if (mounted) setState(() {
        _devices = devices;
        _loading = false;
        _errorMsg = null;
      });
    } catch (e) {
      if (mounted) setState(() {
        _loading = false;
        _errorMsg = e.toString();
      });
    }
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    await _loadAll();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      body: _loading
          ? Center(
              child: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [DashboardTheme.gray1, DashboardTheme.gray3],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: _DashShadowUtils.heavy,
                  border: Border.all(
                    color: DashboardTheme.silver.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: const Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            )
          : _errorMsg != null
              ? _buildErrorView()
              : _DeviceListPage(
                  devices: _devices,
                  role: widget.role,
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                ),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [DashboardTheme.surface2, DashboardTheme.surface3],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: _DashShadowUtils.heavy,
          border: Border.all(
            color: DashboardTheme.gray1.withOpacity(0.3),
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: DashboardTheme.error.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(
                  color: DashboardTheme.error.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Icon(Icons.error_rounded, color: DashboardTheme.error, size: 48),
            ),
            const SizedBox(height: 20),
            Text(
              'TERJADI KESALAHAN',
              style: TextStyle(
                color: DashboardTheme.error,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMsg ?? 'Unknown error',
              textAlign: TextAlign.center,
              style: TextStyle(color: DashboardTheme.textMuted, fontSize: 12),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: _refresh,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [DashboardTheme.gray1, DashboardTheme.gray3],
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: _DashShadowUtils.soft,
                  border: Border.all(
                    color: DashboardTheme.silver.withOpacity(0.2),
                    width: 0.5,
                  ),
                ),
                child: const Text(
                  'COBA LAGI',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}