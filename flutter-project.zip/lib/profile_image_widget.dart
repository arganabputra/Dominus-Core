import 'dart:io';
import 'package:flutter/material.dart';
import 'profile_utils.dart';

// ─────────────────────────────────────────────────────────────
// ProfileImageWidget
// Widget yang selalu sinkron dengan foto profil user.
// FIX 1: key: ValueKey(version) → paksa FutureBuilder restart
//         setiap kali foto diganti (tidak perlu restart app)
// FIX 2: ClipOval + explicit width/height → foto mengisi
//         lingkaran sempurna, tidak ada overflow/putih
// ─────────────────────────────────────────────────────────────
class ProfileImageWidget extends StatelessWidget {
  final double size;
  final String? assetFallback;
  final Color backgroundColor;
  final Color borderColor;
  final double borderWidth;
  final BoxShape shape;
  final VoidCallback? onTap;

  const ProfileImageWidget({
    super.key,
    this.size              = 80,
    this.assetFallback     = 'assets/images/logo.png',
    this.backgroundColor   = const Color(0xFF1A1A1A),
    this.borderColor       = const Color(0xFF6B6B75),
    this.borderWidth       = 2,
    this.shape             = BoxShape.circle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: profileImageNotifier,
      builder: (context, version, __) {
        // FIX 1: key: ValueKey(version) → setiap kali notifier naik,
        // FutureBuilder di-recreate dari nol → foto langsung update
        return FutureBuilder<File?>(
          key: ValueKey(version),
          future: ProfileImageUtils.getProfileImageFile(),
          builder: (context, snapshot) {
            Widget imageChild;

            if (snapshot.connectionState == ConnectionState.waiting) {
              imageChild = Center(
                child: SizedBox(
                  width: size * 0.3,
                  height: size * 0.3,
                  child: const CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor:
                        AlwaysStoppedAnimation<Color>(Color(0xFF00D9FF)),
                  ),
                ),
              );
            } else if (snapshot.hasData && snapshot.data != null) {
              // FIX 2: tambah width & height eksplisit supaya BoxFit.cover
              // bekerja dengan benar dan mengisi seluruh area lingkaran
              imageChild = Image.file(
                snapshot.data!,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _fallback(),
              );
            } else {
              imageChild = _fallback();
            }

            // FIX 2: Pisahkan ClipOval (untuk gambar) dan Container (untuk border)
            // supaya foto mengisi lingkaran 100% tanpa sisa warna putih
            final Widget inner = Stack(
              alignment: Alignment.center,
              children: [
                // Layer 1: background + foto, di-clip jadi lingkaran sempurna
                ClipOval(
                  child: Container(
                    width: size,
                    height: size,
                    color: backgroundColor,
                    child: imageChild,
                  ),
                ),
                // Layer 2: border di atas, tidak mempengaruhi clip
                Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: borderColor,
                      width: borderWidth,
                    ),
                  ),
                ),
              ],
            );

            return onTap != null
                ? GestureDetector(onTap: onTap, child: inner)
                : inner;
          },
        );
      },
    );
  }

  Widget _fallback() {
    if (assetFallback != null) {
      return Image.asset(
        assetFallback!,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Center(
          child: Icon(Icons.person_rounded,
              size: size * 0.5, color: const Color(0xFFAFAFB8)),
        ),
      );
    }
    return Center(
      child: Icon(Icons.person_rounded,
          size: size * 0.5, color: const Color(0xFFAFAFB8)),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// ProfileAvatarWidget
// Avatar bulat di profile_page dengan gradient border sesuai role.
// FIX 1 & 2 diterapkan juga di sini.
// ─────────────────────────────────────────────────────────────
class ProfileAvatarWidget extends StatelessWidget {
  final double size;
  final String username;
  final String role;
  final VoidCallback? onTap;

  const ProfileAvatarWidget({
    super.key,
    this.size = 100,
    required this.username,
    required this.role,
    this.onTap,
  });

  Color get _roleColor {
    switch (role.toLowerCase()) {
      case 'owner':    return const Color(0xFF5A5A62);
      case 'vip':      return const Color(0xFF4A4A52);
      case 'reseller': return const Color(0xFF3A3A42);
      default:         return const Color(0xFF2A2A30);
    }
  }

  @override
  Widget build(BuildContext context) {
    final roleColor = _roleColor;

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: SweepGradient(colors: [
                roleColor,
                roleColor.withOpacity(0.4),
                roleColor,
              ]),
              boxShadow: [
                BoxShadow(
                  color: roleColor.withOpacity(0.35),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ValueListenableBuilder<int>(
              valueListenable: profileImageNotifier,
              builder: (context, version, __) {
                return FutureBuilder<File?>(
                  key: ValueKey(version),   // FIX 1
                  future: ProfileImageUtils.getProfileImageFile(),
                  builder: (context, snapshot) {
                    Widget imageWidget;
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      imageWidget = const Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                              Color(0xFF00D9FF)),
                        ),
                      );
                    } else if (snapshot.hasData && snapshot.data != null) {
                      imageWidget = Image.file(
                        snapshot.data!,
                        width: size,    // FIX 2
                        height: size,   // FIX 2
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _defaultAsset(),
                      );
                    } else {
                      imageWidget = _defaultAsset();
                    }

                    // FIX 2: ClipOval yang reliable
                    return ClipOval(
                      child: Container(
                        width: size,
                        height: size,
                        color: const Color(0xFF1A1A1A),
                        child: imageWidget,
                      ),
                    );
                  },
                );
              },
            ),
          ),
          if (onTap != null)
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF00D9FF),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF00D9FF).withOpacity(0.4),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.edit_rounded,
                  color: Color(0xFF1A1A1A), size: 14),
            ),
        ],
      ),
    );
  }

  Widget _defaultAsset() => Image.asset(
        'assets/images/logo.png',
        width: size,    // FIX 2
        height: size,   // FIX 2
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const Icon(
          Icons.person_rounded,
          color: Color(0xFFAFAFB8),
          size: 48,
        ),
      );
}
