import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

// ─── DEFAULT BACKGROUND ASSET ─────────────────────────────────────────────────
// Gambar default yang selalu dipakai saat tidak ada custom background / logout
const String kDefaultBgAsset = 'assets/images/default_bg.jpg';

// ─── BACKGROUND NOTIFIER ──────────────────────────────────────────────────────
// ChangeNotifier global → semua BackgroundWrapper/screen auto update saat ganti
class BackgroundNotifier extends ChangeNotifier {
  static const _bgPathKey = 'bg_image_path';
  static const _bgTypeKey = 'bg_type';

  String _bgType = 'default';
  String? _bgPath;

  String  get bgType => _bgType;
  String? get bgPath => _bgPath;

  BackgroundNotifier() { _load(); }

  // ── Load dari SharedPreferences saat startup ──────────────────────────────
  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _bgType = prefs.getString(_bgTypeKey) ?? 'default';
    _bgPath = prefs.getString(_bgPathKey);
    notifyListeners();
  }

  // ── Set Foto dari galeri ──────────────────────────────────────────────────
  Future<bool> setImageBackground(File imageFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final bgDir  = Directory('${appDir.path}/backgrounds');
      if (!await bgDir.exists()) await bgDir.create(recursive: true);

      final fileName = 'bg_image_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final saved    = await imageFile.copy('${bgDir.path}/$fileName');

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_bgPathKey, saved.path);
      await prefs.setString(_bgTypeKey, 'image');

      _bgType = 'image';
      _bgPath = saved.path;
      notifyListeners(); // ← semua layar langsung update
      return true;
    } catch (e) {
      debugPrint('BackgroundNotifier.setImage error: $e');
      return false;
    }
  }

  // ── Set Video dari galeri ─────────────────────────────────────────────────
  Future<bool> setVideoBackground(File videoFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final bgDir  = Directory('${appDir.path}/backgrounds');
      if (!await bgDir.exists()) await bgDir.create(recursive: true);

      final fileName = 'bg_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final saved    = await videoFile.copy('${bgDir.path}/$fileName');

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_bgPathKey, saved.path);
      await prefs.setString(_bgTypeKey, 'video');

      _bgType = 'video';
      _bgPath = saved.path;
      notifyListeners(); // ← semua layar langsung update
      return true;
    } catch (e) {
      debugPrint('BackgroundNotifier.setVideo error: $e');
      return false;
    }
  }

  // ── Reset ke default (foto preset) ───────────────────────────────────────
  // Dipanggil saat: user pilih "Default" di settings ATAU saat logout
  Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_bgPathKey);
    await prefs.setString(_bgTypeKey, 'default');
    _bgType = 'default';
    _bgPath = null;
    notifyListeners(); // ← semua layar langsung kembali ke foto default
  }

  // ── Helper: buka galeri gambar ────────────────────────────────────────────
  static Future<File?> pickImage() async {
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
      return picked != null ? File(picked.path) : null;
    } catch (e) {
      debugPrint('pickImage error: $e');
      return null;
    }
  }

  // ── Helper: buka galeri video ─────────────────────────────────────────────
  static Future<File?> pickVideo() async {
    try {
      final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
      return picked != null ? File(picked.path) : null;
    } catch (e) {
      debugPrint('pickVideo error: $e');
      return null;
    }
  }
}

// ─── BACKGROUND SCOPE ─────────────────────────────────────────────────────────
// InheritedNotifier → accessible dari semua widget di bawah MaterialApp
class BackgroundScope extends InheritedNotifier<BackgroundNotifier> {
  const BackgroundScope({
    super.key,
    required BackgroundNotifier notifier,
    required super.child,
  }) : super(notifier: notifier);

  static BackgroundNotifier of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<BackgroundScope>()!.notifier!;
  }
}
