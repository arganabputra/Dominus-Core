// role_helper.dart
import 'package:flutter/material.dart';

String _normalize(String role) {
  return role.toLowerCase().replaceAll('_', ' ');
}

/// Mendapatkan level/tingkatan dari sebuah role
int roleLevel(String role) {
  switch (_normalize(role)) {
    case 'developer':
      return 10;
    case 'all access':
      return 7;
    case 'owner vip':
      return 6;
    case 'owner':
      return 5;
    case 'tk':
      return 4;
    case 'pt':
      return 3;
    case 'admin':
      return 3;
    case 'reseller':
      return 2;
    case 'vip':
      return 1;
    case 'member':
      return 0;
    default:
      return -1;
  }
}

/// Label role untuk UI (huruf besar semua)
String roleLabel(String role) {
  switch (_normalize(role)) {
    case 'developer':
      return 'DEVELOPER';
    case 'all access':
      return 'ALL ACCESS';
    case 'owner vip':
      return 'OWNER VIP';
    case 'owner':
      return 'OWNER';
    case 'tk':
      return 'TK';
    case 'pt':
      return 'PT';
    case 'admin':
      return 'ADMIN';
    case 'reseller':
      return 'RESELLER';
    case 'vip':
      return 'VIP';
    case 'member':
      return 'MEMBER';
    default:
      return role.toUpperCase();
  }
}

/// Role yang dapat dibuat oleh currentRole (dalam bentuk normal)
List<String> creatableRoles(String currentRole) {
  switch (_normalize(currentRole)) {
    case 'developer':
      return [
        'all access',
        'owner vip',
        'owner',
        'tk',
        'pt',
        'admin',
        'reseller',
        'vip',
        'member',
      ];
    case 'all access':
      return ['owner vip', 'owner', 'tk', 'pt', 'reseller', 'vip', 'member'];
    case 'owner vip':
      return ['owner', 'tk', 'pt', 'reseller', 'vip', 'member'];
    case 'owner':
      return ['tk', 'pt', 'reseller', 'vip', 'member'];
    case 'tk':
      return ['pt', 'reseller', 'member'];
    case 'pt':
      return ['reseller', 'member'];
    case 'admin':
      return ['reseller', 'vip', 'member'];
    case 'reseller':
      return ['member'];
    default:
      return [];
  }
}

/// Cek apakah currentRole dapat membuat targetRole
bool canCreateRole(String currentRole, String targetRole) {
  final targetNorm = _normalize(targetRole);
  return creatableRoles(currentRole).contains(targetNorm);
}

/// Cek apakah currentRole dapat menghapus targetRole
bool canDeleteUser(String currentRole, String targetRole) {
  final currentLvl = roleLevel(currentRole);
  final targetLvl = roleLevel(targetRole);
  if (targetLvl >= currentLvl) return false;
  if (_normalize(currentRole) == 'developer') return true;
  return targetLvl < currentLvl;
}

/// Cek apakah currentRole dapat mengedit (extend durasi) targetRole
bool canEditUser(String currentRole, String targetRole) {
  return canDeleteUser(currentRole, targetRole);
}

/// Maksimal hari yang dapat diberikan oleh currentRole
int maxDays(String currentRole) {
  switch (_normalize(currentRole)) {
    case 'developer':
      return 9999;
    case 'all access':
      return 9999;
    case 'owner vip':
      return 365;
    case 'owner':
      return 180;
    case 'tk':
      return 90;
    case 'pt':
      return 60;
    case 'admin':
      return 60;
    case 'reseller':
      return 30;
    default:
      return 0;
  }
}

/// Daftar semua role (untuk filter dropdown)
List<String> getAllRoles() {
  return [
    'developer',
    'all access',
    'owner vip',
    'owner',
    'tk',
    'pt',
    'admin',
    'reseller',
    'vip',
    'member',
  ];
}

/// Mendapatkan role yang lebih tinggi dari role tertentu
List<String> getHigherRoles(String role) {
  final currentLvl = roleLevel(role);
  return getAllRoles().where((r) => roleLevel(r) > currentLvl).toList();
}

/// Mendapatkan role yang lebih rendah dari role tertentu
List<String> getLowerRoles(String role) {
  final currentLvl = roleLevel(role);
  return getAllRoles().where((r) => roleLevel(r) < currentLvl).toList();
}

/// Cek apakah role valid
bool isValidRole(String role) {
  return getAllRoles().contains(_normalize(role));
}

/// Warna role untuk UI
Color getRoleColor(String role) {
  switch (_normalize(role)) {
    case 'developer':
      return const Color(0xFF6A0DAD);
    case 'all access':
      return const Color(0xFFE91E63);
    case 'owner vip':
      return const Color(0xFFFFD700);
    case 'owner':
      return const Color(0xFFD4AF37);
    case 'tk':
      return const Color(0xFF3F51B5);
    case 'pt':
      return const Color(0xFF009688);
    case 'admin':
      return const Color(0xFFF44336);
    case 'reseller':
      return const Color(0xFFFF6B35);
    case 'vip':
      return const Color(0xFF4CAF50);
    case 'member':
      return const Color(0xFF9E9E9E);
    default:
      return const Color(0xFF9E9E9E);
  }
}

/// Ikon role untuk UI
IconData getRoleIcon(String role) {
  switch (_normalize(role)) {
    case 'developer':
      return Icons.code;
    case 'all access':
      return Icons.public;
    case 'owner vip':
      return Icons.star;
    case 'owner':
      return Icons.workspace_premium;
    case 'tk':
      return Icons.support_agent;
    case 'pt':
      return Icons.business_center;
    case 'admin':
      return Icons.admin_panel_settings;
    case 'reseller':
      return Icons.storefront;
    case 'vip':
      return Icons.star;
    default:
      return Icons.person;
  }
}

/// Deskripsi role
String getRoleDescription(String role) {
  switch (_normalize(role)) {
    case 'developer':
      return 'Developer - Bisa membuat SEMUA akses role';
    case 'all access':
      return 'All Access - Bisa membuat Owner VIP, Owner, TK, PT, Reseller, VIP, Member';
    case 'owner vip':
      return 'Owner VIP - Bisa membuat Owner, TK, PT, Reseller, VIP, Member';
    case 'owner':
      return 'Owner - Bisa membuat TK, PT, Reseller, VIP, Member';
    case 'tk':
      return 'TK - Bisa membuat PT, Reseller, Member';
    case 'pt':
      return 'PT - Bisa membuat Reseller dan Member';
    case 'admin':
      return 'Admin - Bisa membuat Reseller ke bawah';
    case 'reseller':
      return 'Reseller - Bisa membuat Member';
    case 'vip':
      return 'VIP - Tidak bisa membuat akun';
    case 'member':
      return 'Member - Tidak bisa membuat akun';
    default:
      return 'Role tidak dikenal';
  }
}
