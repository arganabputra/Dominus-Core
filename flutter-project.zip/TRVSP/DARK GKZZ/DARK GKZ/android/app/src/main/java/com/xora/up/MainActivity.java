package com.xora.up;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
